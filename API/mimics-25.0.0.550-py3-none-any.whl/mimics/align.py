import typing
import mimics


def align_to_coordinate_system(object, object_origin, cs_origin, object_top_vector=None, cs_top_vector=None, object_front_vector=None, cs_front_vector=None):
    """
    Aling Object to coordinate system. Object orientation is described via origin and two vectors. 
    
    Coordinate system to align with is also described via origin and two vectors. 
    
    This function moves Object's origin to CS origin. 
    
    If top_vector's for Object and CS are specified - rotates the object and aligns Object top_vector with CS top_vector. 
    
    If front_vector's for Object and CS are specified - rotates the object around top_vector to align Object's front_vector with CS front_vector
    
    All vectors are optional, but they are paired: Object top_vector cannot be used without CS top_vector, also Object front_vector cannot be used without CS front_vector, 
    
    All vectors should be non zero-length vectors. Front_vectors cannot be used without top_vectors. 
    
    To indicate valid CS, Object top_vector and Object front_vector should be non-collinear, also CS top_vector and CS front_vector should be non-collinear.
    
    :param object: The object to be aligned.
    :type object: mimics.Object
    :param object_origin: Object origin in object coordinate system. The object will be moved to align this Object origin to CS origin.
    :type object_origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param cs_origin: CS origin in world coordinate system. The object will be moved to align Object origin to this CS origin.
    :type cs_origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param object_top_vector: (optional) Object top_vector in object coordinate system. The object will be rotated in 3D-space to align this Object top_vector to CS top_vector.
    :type object_top_vector: typing.Optional[TMimicsVector]
    :param cs_top_vector: (optional) CS top_vector in world coordinate system. The object will be rotated in 3D-space to align Object top_vector to this CS top_vector.
    :type cs_top_vector: typing.Optional[TMimicsVector]
    :param object_front_vector: (optional) Object front_vector in object coordinate system. The object will be rotated around CS top_vector to align this Object front_vector to CS front_vector
    :type object_front_vector: typing.Optional[TMimicsVector]
    :param cs_front_vector: (optional) CS front_vector in world coordinate system. The object will be rotated around CS top_vector to align Object front_vector to this CS front_vector
    :type cs_front_vector: typing.Optional[TMimicsVector]
    
    :exceptions: ValueError (reason(s): ["'object_top_vector' is present and 'cs_top_vector' is missing.", "'cs_top_vector' is present and 'object_top_vector' is missing.", "'object_front_vector' is present and 'cs_front_vector' is missing.", "'cs_front_vector' is present and 'object_front_vector' is missing.", "Both 'object_top_vector' and 'cs_top_vector' are missing or invalid, while both 'object_front_vector' and 'cs_front_vector' are present.", "'object_top_vector' is a zero-length vector.", "'cs_top_vector' is a zero-length vector.", "'object_front_vector' is a zero-length vector.", "'cs_front_vector' is a zero-length vector.", "'object_top_vector' and 'object_front_vector' are collinear", "'cs_top_vector' and 'cs_front_vector' are collinear"]), RuntimeError (reason(s): ['Cannot calculate the angle between Object top_vector and CS top_vector', 'Cannot calculate the angle between Object front_vector and CS front_vector'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	p_copy = mimics.data.parts.duplicate(p)
    	
    	# just moves object to the world origin
    	mimics.align.align_to_coordinate_system(
    	  object=p_copy,
    	  object_origin=(0,0,0),
    	  cs_origin=(0,0,0))
    	
    	# moves object to the world origin
    	# then rotates it to align object top_vector(0,0,1) with world Z-axis(0,0,1)
    	mimics.align.align_to_coordinate_system(
    	  object=p_copy,
    	  object_origin=(0,0,0),
    	  cs_origin=(0,0,0),
    	  object_top_vector=(0,0,1),
    	  cs_top_vector=(0,0,1))
    	
    	# moves object to the world origin
    	# then rotates it to align object top_vector(0,0,1) with world Z-axis(0,0,1)
    	# then rotates it around world Z-axis to align object front_vector(0,1,0) with world X-axis(1,0,0)
    	mimics.align.align_to_coordinate_system(
    	  object=p_copy,
    	  object_origin=(0,0,0),
    	  cs_origin=(0,0,0),
    	  object_top_vector=(0,0,1),
    	  cs_top_vector=(0,0,1),
    	  object_front_vector=(0,1,0),
    	  cs_front_vector=(1,0,0))

    """
    pass


def orient_plane_facing_to(plane, point, opposite_direction=False, rotate_around_x_axis=True):
    """
    Flips (if necessary) the normal of the plane so that the place faces the point.
    
    :param plane: Plane to orient
    :type plane: mimics.analyze.Plane
    :param point: Point, in direction to which, face (normal) of the plane will be oriented to.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param opposite_direction: (optional) If True plane will be flipped (if necessary) in order to face the opposite direction.
    :type opposite_direction: bool
    :param rotate_around_x_axis: (optional) If True plane will be flipped (if necessary) by rotating around the X-axis of the plane, otherwise around the Y-axis.
    :type rotate_around_x_axis: bool
    
    :exceptions: ValueError (reason(s): ['the point cannot lay on the plane'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# create pointing 'down' the Z axis
    	pl = mimics.analyze.create_plane_origin_and_normal(origin=(1,2,3), normal=(0, 0, -1))
    	# then orient the plane 'pl' to face the point (20, 20, 20) 
    	# the normal will be flipped to point 'up' the Z axis
    	mimics.align.orient_plane_facing_to(plane=pl, point=(20, 20, 20))
    	print(pl.normal)  # it will print (0, 0, 1)

    """
    pass


