from enum import Enum, auto

class SegmentVesselPreset(Enum):
    """
    Presets for additional parameters for Segment Vessel algorithm.
    """
    Generic = auto()
    Aorta_all = auto()
    Aorta_main = auto()
    Cerebral = auto()
    Coronary = auto()
    Femoral = auto()
    Liver = auto()
    Pulmonary = auto()
    Renal = auto()


import typing
import mimics


class Mask(mimics.Object):
    """
    A mask is a collection of pixels on which all actions (editing, region growing, ..) and calculations (3D calculations, Part, ..) are based.
    """
    def get_voxel_buffer(self):
        """
        Returns mask copy as 3D array of bool.
        
        
        
        :returns: Memoryview of bool
        :rtype: memoryview
        """
        pass

    def set_voxel_buffer(self, pixels):
        """
        Sets mask pixels from memoryview of bool.
        
        :param pixels: Memoryview object
        :type pixels: memoryview
        
        :exceptions: ValueError (reason(s): ['Dimensions of input pixels do not coincide with mask region dimensions'])
        """
        pass

    def _get_logical_voxel_buffer(self):
        """
        Returns logical mask copy as 3D array of bool.
        
        
        
        :returns: Memoryview of bool
        :rtype: memoryview
        """
        pass

    def _set_logical_voxel_buffer(self, pixels):
        """
        Sets logical mask pixels from memoryview of bool.
        
        :param pixels: Memoryview object
        :type pixels: memoryview
        
        :exceptions: ValueError (reason(s): ['Dimensions of input pixels do not coincide with logical mask region dimensions'])
        """
        pass

    def clear(self):
        """
        Clears the mask.
        
    
        """
        pass

    @property
    def threshold_low(self):
        """
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Threshold low cannot be set to the value greater than threshold high.'])
        """
        pass
    
    @threshold_low.setter
    def threshold_low(self, value):
        """
    
        """
        pass

    @property
    def threshold_high(self):
        """
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Threshold high cannot be set to the value less than threshold low. ', 'Threshold high cannot be set to the value greater than maximum grey value.'])
        """
        pass
    
    @threshold_high.setter
    def threshold_high(self, value):
        """
    
        """
        pass

    @property
    def minimum_value(self):
        """
        Minimum grey value.
        
        :type: <class 'int'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Not possible to get minimum value, because mask is empty.'])
        """
        pass

    @property
    def maximum_value(self):
        """
        Maximum grey value.
        
        :type: <class 'int'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Not possible to get maximum value, because mask is empty.'])
        """
        pass

    @property
    def average_value(self):
        """
        :type: <class 'float'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Not possible to get average value, because mask is empty.'])
        """
        pass

    @property
    def std(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Not possible to get standard deviation, because mask is empty'])
        """
        pass

    @property
    def number_of_pixels(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def volume(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass


def _ensure_mask_is_from_active_image_data(mask):
    """
    Throws exception if provided mask does not belong to active image data.
    
    :param mask: Mask to check.
    :type mask: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Mask does not belong to active image data.'])
    """
    pass


class _Interpolate3DAppState(object):
    """
    GUI class for interactive usage of 3D Interpolate tool.
    """
    pass


class _ThresholdingAppState(object):
    """
    GUI class for interactive usage
    """
    pass


class _EditMaskAppState(object):
    """
    GUI class for interactive usage
    """
    pass


class _MultipleSliceEditAppState(object):
    """
    GUI class for interactive usage of Multiple Slice Edit tool.
    """
    pass


def activate_multiple_slice_edit(mask, operation=None, edit_type=None, view=None, edit_mode=None, hide_markings=None, enable_auto_interpolate=None):
    """
    Activates Multiple Slice Edit tool.
    
    :param mask: The input mask to be edited.
    :type mask: mimics.segment.Mask
    :param *: 
    :type *: None
    :param operation: (optional) Operation for Multiple Slice Edit. Allowed values: 'Add', 'Remove', 'Threshold'. If 'None' is given, then the previously chosen operation is taken.
    :type operation: str
    :param edit_type: (optional) Type of Mask edit. Allowed values: 'Ellipse', 'Rectangle', 'Lasso', 'FloodFill', 'LiveWire'. If 'None' is given, then the previously chosen type is taken.
    :type edit_type: str
    :param view: (optional) The 2D view on which you want to perform the markings (Axial, Coronal, or Sagittal). On resliced layouts, it is possible to specify AxialResliced, CoronalResliced, or SagittalResliced view.
    :type view: mimics.view.View
    :param edit_mode: (optional) Mode of Mask edit. Allowed values: 'Draw', 'Erase'. If 'None' is given, then the previously chosen edit mode is taken.
    :type edit_mode: str
    :param hide_markings: (optional) Specifies whether to hide all the markings or not. If 'None' is given, then the choice from the previous tool launch is taken.
    :type hide_markings: bool
    :param enable_auto_interpolate: (optional) Specifies whether to enable Auto-Interpolate or not. If 'None' is given, then the choice from the previous tool launch is taken.
    :type enable_auto_interpolate: bool
    
    :returns: The edited mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.', 'The given view is not supported.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	result_mask = mimics.segment.activate_multiple_slice_edit(
    	     mask = m, 
    	     operation = "Remove",
    	     edit_type = "Lasso", 
    	     edit_mode = "Draw",
    	     hide_markings = True,
    	     enable_auto_interpolate = False)

    """
    pass


def activate_interpolate3d(mask, operation=None, edit_type=None, edit_mode=None, hide_markings=None, enable_auto_interpolate=None):
    """
    Activates 3D Interpolate tool.
    
    :param mask: The input mask to be interpolated.
    :type mask: mimics.segment.Mask
    :param operation: (optional) Operation for 3D Interpolate. Allowed values: 'Add', 'Remove', 'Threshold'. If 'None' is given, then the previously chosen operation is taken.
    :type operation: str
    :param edit_type: (optional) Type of Mask edit. Allowed values: 'Ellipse', 'Rectangle', 'Lasso', 'FloodFill', 'LiveWire'. If 'None' is given, then the previously chosen type is taken.
    :type edit_type: str
    :param edit_mode: (optional) Mode of Mask edit. Allowed values: 'Draw', 'Erase'. If 'None' is given, then the previously chosen edit mode is taken.
    :type edit_mode: str
    :param hide_markings: (optional) Specifies whether to hide all the markings or not. If 'None' is given, then the choice from the previous tool launch is taken.
    :type hide_markings: bool
    :param enable_auto_interpolate: (optional) Specifies whether to enable Auto-Interpolate or not. If 'None' is given, then the choice from the previous tool launch is taken.
    :type enable_auto_interpolate: bool
    
    :returns: Interpolated mask.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	result_mask = mimics.segment.activate_interpolate3d(
    	     mask = m, 
    	     operation = "Remove",
    	     edit_type = "Lasso", 
    	     edit_mode = "Draw",
    	     hide_markings = True,
    	     enable_auto_interpolate = False)

    """
    pass


def smart_fill_global(mask, hole_closing_distance=2):
    """
    Automatically fills the opened and closed holes. A new mask is created in the end of the operation.
    
    :param mask: Mask to be filled.
    :type mask: mimics.segment.Mask
    :param hole_closing_distance: (optional) Parameter that defines the size of the holes that will be closed. Defined in voxels.
    :type hole_closing_distance: int
    
    :returns: Filled mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Invalid hole closing distance. Must be in 1-7 range.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	hcd = 2
    	mimics.segment.smart_fill_global(mask = m, hole_closing_distance = hcd)

    """
    pass


def activate_edit_mask(mask, edit_mode=None, edit_type=None, enable_clipping=None):
    """
    Activates Edit Masks tool.
    
    :param mask: The input mask to be edited.
    :type mask: mimics.segment.Mask
    :param edit_mode: (optional) Mode of Mask edit. Allowed values: 'Draw', 'Erase'. If 'None' is given, then the previously chosen edit mode is taken.
    :type edit_mode: str
    :param edit_type: (optional) Type of Mask edit. Allowed values: 'Ellipse', 'Rectangle', 'Lasso', 'FloodFill', 'LiveWire'. If 'None' is given, then the previously chosen type is taken.
    :type edit_type: str
    :param enable_clipping: (optional) Allows you to visualize the bounding box for the input mask. You can manually resize the bounding box if needed. The mask can only be edited within the bounding box. If 'None' is given, then the choice from the previous tool launch is taken
    :type enable_clipping: typing.Optional[bool]
    
    :returns: The edited mask.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	mimics.segment.activate_edit_mask(mask=m, edit_mode="Draw", edit_type="Lasso", enable_clipping=True)

    """
    pass


def activate_thresholding(lower_threshold=None, upper_threshold=None, fill_holes=False, keep_largest=False, mask=None):
    """
    Activates Threshold mask tool.
    
    :param lower_threshold: (optional) Lower threshold for the mask to be set.
    :type lower_threshold: int
    :param upper_threshold: (optional) Upper threshold for the mask to be set.
    :type upper_threshold: int
    :param *: 
    :type *: None
    :param fill_holes: (optional) If true, it fills the holes in the mask.
    :type fill_holes: bool
    :param keep_largest: (optional) If true, it keeps the largest part of the mask if there are several disconnected parts.
    :type keep_largest: bool
    :param mask: (optional) The input mask.
    :type mask: mimics.segment.Mask
    
    :returns: Thresholded mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Threshold low cannot be greater than threshold high.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.segment.activate_thresholding(lower_threshold=350,fill_holes=True)

    """
    pass


def segment_lung_lobes(right_lung, left_lung):
    """
    Detects fissures and cuts lungs into lobes.
    
    :param right_lung: Right lung Part.
    :type right_lung: mimics.Part
    :param left_lung: Left lung Part.
    :type left_lung: mimics.Part
    
    :returns: Parts of the lung lobes in the following order: left upper, left lower, right upper, right middle, right lower.
    :rtype: typing.Tuple[mimics.Part, mimics.Part, mimics.Part, mimics.Part, mimics.Part]
    
    
    :example:
    .. code-block:: python
    
    	 
    	lngs = mimics.segment.segment_lungs()
    	rl = lngs[0]
    	ll = lngs[1]
    	mimics.segment.segment_lung_lobes(right_lung=rl, left_lung=ll)

    """
    pass


def segment_lungs():
    """
    Detects the lungs.
    
    :returns: Parts of the lungs in the following order: right lung, left lung.
    :rtype: typing.Tuple[mimics.Part, mimics.Part]
    
    
    :example:
    .. code-block:: python
    
    	 
    	lngs = mimics.segment.segment_lungs()
    	rl = lngs[0]
    	ll = lngs[1]

    """
    pass


def calculate_mask_from_part(part, target_mask=None):
    """
    Creates a mask from a Part. The area defined by the contours of the part on each slice of the project is filled to create a mask.
    
    :param part: The Part used to create the mask.
    :type part: mimics.Part
    :param target_mask: (optional) The output mask. If None, a new mask will be created.
    :type target_mask: mimics.segment.Mask
    
    :returns: Result mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['The selected part is not solid'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	m = mimics.segment.calculate_mask_from_part(part=p)

    """
    pass


def segment_vessel(target_mask, threshold_min, threshold_max, seed_point, orientation_point, parameters=None):
    """
    Semi-automatically segments a blood vessel structure by indicating the start of the desired vessel(s). The segmented vessels are added to a provided or new mask.
    
    :param target_mask: Mask to which the segmented blood vessels are added. If no mask is provided, a new mask containing the segmented vessels is created.
    :type target_mask: typing.Optional[mimics.segment.Mask]
    :param threshold_min: The minimum value of the threshold in Grayvalues. Value range: [1,65535]
    :type threshold_min: int
    :param threshold_max: The maximum value of the threshold in Grayvalues. Value range: [1,65535]
    :type threshold_max: int
    :param seed_point: Point that indicates the origin of the blood vessel. The segmentation starts in this point.
    :type seed_point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param orientation_point: Point that indicates the direction of the blood vessel.
    :type orientation_point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param parameters: (optional) The advanced parameters for the Segment Vessel algorithm. If None is given, default advanced parameters values are used.
    :type parameters: typing.Optional[mimics.segment.SegmentVesselParameters]
    
    :returns: Mask with segmented vessels. The returned mask is merged with the input mask or created as a new mask if no input mask was provided.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['The input mask is not linked to the active image stack. Only masks linked to the active image stack can be selected.', 'Threshold low cannot be greater than threshold high.', 'Threshold value is outside the voxel intensity range of the images.', 'Point is placed outside of the active image stack boundaries. Only points within image stack boundaries are allowed.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	input_mask = mimics.data.masks[0]
    	th_min = 1249
    	th_max = 1622
    	seed = [32.9713, -124.3850, 2038.0000]
    	orientation = [32.1598, -121.9505, 2033.5000]
    	
    	output_mask = mimics.segment.segment_vessel(target_mask=input_mask, 
    	                                            threshold_min=th_min, 
    	                                            threshold_max=th_max, 
    	                                            seed_point=seed,
    	                                            orientation_point=orientation)
    	
    	#Example 2
    	par_default = mimics.segment.create_segment_vessel_parameters()
    	
    	par_default.branch_number = 3
    	par_default.branch_rotation = 75.0
    	par_default.diameter_variability = 0.5
    	par_default.max_length = 600.0
    	par_default.max_diameter = 30.0
    	par_default.min_diameter = 0.1
    	par_default.multibranch = True
    	
    	input_mask = mimics.data.masks[0]
    	th_min = 1249
    	th_max = 1622
    	seed = [32.9713, -124.3850, 2038.0000]
    	orientation = [32.1598, -121.9505, 2033.5000]
    	
    	output_mask = mimics.segment.segment_vessel(target_mask = None, 
    	                                            threshold_min=th_min, 
    	                                            threshold_max=th_max, 
    	                                            seed_point=seed,
    	                                            orientation_point=orientation,
    	                                            parameters=par_default)

    """
    pass


def calculate_heterogeneity(percentage1, percentage2):
    """
    Calculates the heterogeneity between two percentages (the percentages typically indicate the percentage low attenuation):
        * Heterogenity(%) = abs(percentage1 - percentage2).
    
    :param percentage1: First percentage.
    :type percentage1: typing.SupportsFloat
    :param percentage2: Second percentage.
    :type percentage2: typing.SupportsFloat
    
    :returns: Heterogeneity
    :rtype: typing.SupportsFloat
    
    :exceptions: ValueError (reason(s): ['Invalid value for percentage arguments. Allowed values: 0 - 100'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = 30
    	p2 = 45
    	het = mimics.segment.calculate_heterogeneity(p1,p2)

    """
    pass


def segment_airway(point_1, point_2, noise_filter=False, leakage_detection=2, post_processing=True):
    """
    Segments semi-automatically the airway track on inspiration or expiration scans. By indicating the start of the trachea the user initiates the airway segmentation process. The outputs of the tool are a mask and 3D model of the segmented airway.
    
    During the segmentation process it is important to investigate the segmentation for leakages. Leakages occur in regions where the contrast between the airway and the airway wall decreases, in such regions the segmentation can leak into the pulmonary parenchyma and subsequently lung tissue gets erroneously marked as airway.
    
    The segmentation process will preview the segmentation result in 2D and 3D. Leakages can be removed by placing a leakage indicator on the 3D preview or afterwards by post-processing the mask using edit mask tools.
    
    The Segment Airways tool allows semi-automatically segmentation of the airway by indicating the trachea.
    
    :param point_1: Origin point of the trachea.
    :type point_1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point_2: Point that indicates the direction of the trachea.
    :type point_2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param noise_filter: (optional) It is used if the operation fails to start or many branches are missing. If true, the noise filter is on.
    :type noise_filter: bool
    :param leakage_detection: (optional) Leakages occur in regions where the contrast between the airway and the airway wall decreases, in such regions the segmentation can leak into the pulmonary parenchyma and subsequently lung tissue gets erroneously marked as airway.
    
    Weak detection (0 value) will result in most branches found, the result will contain most leakages. Strong detections (4 value) will result in a shorter airway and less leakages.
    :type leakage_detection: int
    :param post_processing: (optional) If true, it performs post-operation processing to the Part to improve the quality of the triangles while it maintains the essential characteristics of the airway.
    :type post_processing: bool
    
    :returns: Mask and 3D Model(Part) of the airway.
    :rtype: typing.Tuple[mimics.segment.Mask, mimics.Part]
    
    :exceptions: ValueError (reason(s): ['Invalid leakage detection strength. Must be in 0-4 range', 'Both points has the same coordinates']), RuntimeError (reason(s): ["A Part cannot be generated of empty mask 'Airway'", "Can't choose lumen or background seed for the first ROI"])
    
    
    :example:
    .. code-block:: python
    
    	 
    	pnts=[]
    	pnts = [mimics.analyze.indicate_point() for i in range(2)]
    	p1 = pnts[0]
    	p2 = pnts[1]
    	mimics.segment.segment_airway(point_1=p1, point_2=p2)

    """
    pass


def boolean_operations(mask_a, mask_b, operation='Minus'):
    """
    Subtracts, unites or intersects two input masks.
    
    The threshold limits of the resulting mask will be updated according to the values of the masks A and B and the operation applied:
        * Subtraction (Minus) :: Threshold value = Threshold value mask A.
        * Unite :: Lower threshold = min (low mask A, low mask B)). Higher threshold = max (high mask A, high mask B))
        * Intersect :: Lower threshold = max (low mask A, low mask B)). Higher threshold = min (high mask A, high mask B)).
    
    :param mask_a: The mask to be altered.
    :type mask_a: mimics.segment.Mask
    :param mask_b: The mask to be used for mask_a modification.
    :type mask_b: mimics.segment.Mask
    :param operation: (optional) The different boolean operations are:
        * Minus :: mask_b area (pixels) will be subtracted from mask_a area.
        * Unite :: mask_a and mask_b areas will be added.
        * Intersect :: Only common area of mask_a and mask_b will be left.
    :type operation: str
    
    :returns: Modified mask.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	m1 = mimics.data.masks[0]
    	m2 = mimics.data.masks[1]
    	op = "Unite"
    	m = mimics.segment.boolean_operations(mask_a=m1, mask_b=m2, operation=op)

    """
    pass


def cavity_fill(fill_cavity_of, point, slice_type, multiple_layer=True):
    """
    Fills internal gaps of the selected mask.
    
    :param fill_cavity_of: Input mask.
    :type fill_cavity_of: mimics.segment.Mask
    :param point: Point placed on the cavity to fill in the mask.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param slice_type: Specifies the orientation of the slices (Axial, Coronal or Sagittal)
    :type slice_type: str
    :param multiple_layer: (optional) The operation can be performed on one single slice (multiple_layer is false) or in 3D on all slices (multiple_layer is true)
    :type multiple_layer: bool
    
    :returns: Mask with filled in cavities.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Seed point is not on images'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	p = (0, 0, 0) 
    	st = "Axial"
    	mimics.segment.cavity_fill(fill_cavity_of=m, point=p, slice_type=st)

    """
    pass


def create_part_calculation_parameters():
    """
    Creates the Part custom calculation parameters corresponding to 'Optimal' quality preset. Properties can be modified to adjust the Part calculation parameters.
    
    :returns: Part Calculation Parameters object.
    :rtype: mimics.segment.PartCalculationParameters
    
    
    :example:
    .. code-block:: python
    
    	 
    	par = mimics.segment.create_part_calculation_parameters()
    	
    	par.used_for_export = True
    	par.quality = 'Custom'
    	par.interpolation_method = 'Contour'
    	par.shell_reduction = True
    	par.triangle_reduction = False
    	par.smoothing = True
    	par.smooth_factor = 0.8
    	par.compensate_smooth_shrinkage = False
    	par.matrix_reduction_xy = 1
    	par.matrix_reduction_z = 1

    """
    pass


def smooth_mask(mask):
    """
    Smooths a mask. It filters outliers resulting from manual segmentation while preserving important boundaries.
    
    :param mask: Mask to be smoothed.
    :type mask: mimics.segment.Mask
    
    :returns: Smoothed mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Source mask should not be empty']), MemoryError (reason(s): ['Not enough memory to perform Smooth operation for mask'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	mimics.segment.smooth_mask(mask=m)

    """
    pass


class PartCalculationParameters(object):
    """
    Provides access and stores all Part generation settings.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def quality(self):
        """
        The quality of the calculated part.
        
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @quality.setter
    def quality(self, value):
        """
    
        """
        pass

    @property
    def first_slice_position(self):
        """
        Defines the position of the first slice that is used for the part calculation.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['First slice position must be greater than minimal slice position of the project', 'First slice position cannot greater than last slice position'])
        """
        pass
    
    @first_slice_position.setter
    def first_slice_position(self, value):
        """
    
        """
        pass

    @property
    def last_slice_position(self):
        """
        Defines the position of the last slice that is used for the part calculation.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Last slice position cannot be greater than maximal slice position of the project', 'Last slice position cannot be lower than the first slice position'])
        """
        pass
    
    @last_slice_position.setter
    def last_slice_position(self, value):
        """
    
        """
        pass

    @property
    def matrix_reduction_xy(self):
        """
        Defines the amount of voxels per group in the XY plane, that are used in part calculation.
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Matrix reduction in the XY Plane must be in 1-50 range'])
        """
        pass
    
    @matrix_reduction_xy.setter
    def matrix_reduction_xy(self, value):
        """
    
        """
        pass

    @property
    def matrix_reduction_z(self):
        """
        Defines the amount of voxels per group in Z-direction, that are used in part calculation.
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Matrix reduction in Z-direction must be in 1-50 range'])
        """
        pass
    
    @matrix_reduction_z.setter
    def matrix_reduction_z(self, value):
        """
    
        """
        pass

    @property
    def prefer_continuity(self):
        """
        Defines continuity or accuracy of part calculation. If True, contour continuity is a priority for the part calculation.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @prefer_continuity.setter
    def prefer_continuity(self, value):
        """
    
        """
        pass

    @property
    def interpolation_method(self):
        """
        Defines the interpolation method. The different methods are:
            * Gray Value :: Gray value interpolation is a real 3D interpolation that takes into account the Partial Volume effect. It gives an analytical result, however it is affected by noise.
            * Contour :: Contour interpolation is a 2D interpolation in the plane of the images that is smoothly expanded in the third dimension. This interpolation algorithm uses the gray value interpolation within the slices, but in the Z direction a linear interpolation between the contours is used.
        
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @interpolation_method.setter
    def interpolation_method(self, value):
        """
    
        """
        pass

    @property
    def threshold_method(self):
        """
        Defines the thresholding method.
        
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @threshold_method.setter
    def threshold_method(self, value):
        """
    
        """
        pass

    @property
    def shell_reduction(self):
        """
        If True, controls the number of shells in the output part.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @shell_reduction.setter
    def shell_reduction(self, value):
        """
    
        """
        pass

    @property
    def number_of_largest_shells(self):
        """
        Defines maximum number for shells for the output part. Value range: [1,100]
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Largest shells to keep must be in 1-100 range'])
        """
        pass
    
    @number_of_largest_shells.setter
    def number_of_largest_shells(self, value):
        """
    
        """
        pass

    @property
    def smoothing(self):
        """
        This function is meant to make rough surfaces smoother. It works like a filter for noise reduction.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @smoothing.setter
    def smoothing(self, value):
        """
    
        """
        pass

    @property
    def smooth_iterations(self):
        """
        Specifies the number of smoothing iterations that are performed. Value range: [1,500]
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Number of smooth iteration must be in 1-500 range'])
        """
        pass
    
    @smooth_iterations.setter
    def smooth_iterations(self, value):
        """
    
        """
        pass

    @property
    def smooth_factor(self):
        """
        Determines how much smoothing is performed. Value range: [0,1]
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Smooth factor must be in 0.0-1.0 range'])
        """
        pass
    
    @smooth_factor.setter
    def smooth_factor(self, value):
        """
    
        """
        pass

    @property
    def compensate_smooth_shrinkage(self):
        """
        Determines the shrinkage of the object due to smoothing. If True, the shrinkage of the object due to smoothing is countered.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @compensate_smooth_shrinkage.setter
    def compensate_smooth_shrinkage(self, value):
        """
    
        """
        pass

    @property
    def triangle_reduction(self):
        """
        If True, reduces the number of triangles in the mesh.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @triangle_reduction.setter
    def triangle_reduction(self, value):
        """
    
        """
        pass

    @property
    def triangle_reduction_mode(self):
        """
        Defines the mode of triangle reduction. The different modes are:
            * Point :: better for non-medical objects since they create more uniform mesh based on points.
            * Edge :: better for non-medical objects since they create more uniform mesh based on edges.
            * Advanced edge :: generates less noise on the resulting surface and creates a smaller object.
        
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @triangle_reduction_mode.setter
    def triangle_reduction_mode(self, value):
        """
    
        """
        pass

    @property
    def triangle_reduction_tolerance(self):
        """
        Defines the maximum deviation (in mm) between the triangles so as to belong to the same plane. Value range: [0,5]
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Triangle reduction tolerance must be in 0.0-5.0 range'])
        """
        pass
    
    @triangle_reduction_tolerance.setter
    def triangle_reduction_tolerance(self, value):
        """
    
        """
        pass

    @property
    def triangle_reduction_angle(self):
        """
        Defines which angle should be used to determine edges of the part that cannot be removed. Triangles deviating less than this angle will be grouped with the other triangles. Value range: [0,90]
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Triangle reduction angle must be in 0.0-90.0 range'])
        """
        pass
    
    @triangle_reduction_angle.setter
    def triangle_reduction_angle(self, value):
        """
    
        """
        pass

    @property
    def triangle_reduction_iterations(self):
        """
        Specifies the number of the triangle reduction iterations that are performed. Value range: [1,500]
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Number of the triangle reduction iterarions must be in 1-500 range'])
        """
        pass
    
    @triangle_reduction_iterations.setter
    def triangle_reduction_iterations(self, value):
        """
    
        """
        pass

    @property
    def used_for_export(self):
        """
        If True, the STL file can be used for export.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @used_for_export.setter
    def used_for_export(self, value):
        """
    
        """
        pass


def threshold(mask, threshold_min, threshold_max, bounding_box=None):
    """
    Sets the threshold of the active mask. It can be defined based on a low and a high limit. The mask contains pixels with a value between both threshold limits.
    
    Note: The upper and lower threshold limits are limited to the maximum and minimum intensity in the project.
    
    :param mask: Mask to be thresholded.
    :type mask: mimics.segment.Mask
    :param threshold_min: The minimum value of the threshold. Value range: [1,65535]
    :type threshold_min: int
    :param threshold_max: The maximum value of the threshold. Value range: [1,65535]
    :type threshold_max: int
    :param bounding_box: (optional) Bounding box that includes the region of interest.
    :type bounding_box: typing.Optional[mimics.BoundingBox3d]
    
    :returns: Input mask updated according to defined limits.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['At least one of the vectors of the bounding box has 0 length.', 'Threshold low cannot be greater than threshold high.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	l_t = 100
    	h_t = 3000
    	mimics.segment.threshold(mask=m, threshold_min=l_t, threshold_max=h_t)

    """
    pass


def keep_largest(mask):
    """
    Keeps the largest part of the mask if there are several disconnected parts.
    
    :param mask: Input mask with several disconnected parts.
    :type mask: mimics.segment.Mask
    
    :returns: Mask with a single part.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	mimics.segment.keep_largest(mask=m)

    """
    pass


def create_part(vertices, triangles):
    """
    Creates a new Part using given vertices and triangles.
    
    :param vertices: Memoryview of floats with the stored vertices coordinates data inside.
    :type vertices: memoryview
    :param triangles: Memoryview of floats with the stored triangles (combination of vertices that creates it) data inside.
    :type triangles: memoryview
    
    :returns: Part which corresponds to the defined parameters.
    :rtype: mimics.Part
    
    
    :example:
    .. code-block:: python
    
    	 
    	import numpy as np
    	p = mimics.data.parts[0]
    	v,t = p.get_triangles()
    	v = np.array(v)
    	t = np.array(t)
    	for i in range(len(v)):
    	    v[i] = v[i]+100
    	mimics.segment.create_part(v,t)

    """
    pass


def locate_mask(mask):
    """
    Allows to find some (arbitrary) pixel which corresponds to the given mask.
    
    :param mask: Mask which coordinates needs to be found.
    :type mask: mimics.segment.Mask
    
    :returns: Coordinates of some pixel which belongs to defined mask
    :rtype: typing.Tuple[float, float, float]
    
    :exceptions: ValueError (reason(s): ['Location is not possible, because mask is empty'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	coo = mimics.segment.locate_mask(mask=m)

    """
    pass


def _create_mask(select_new_mask=True):
    """
    Creates a new empty mask.
    
    :param *: 
    :type *: None
    :param select_new_mask: (optional) If True the new mask will be automatically selected and originally selected mask will be unselected.
    :type select_new_mask: bool
    
    :returns: a mask object
    :rtype: mimics.segment.Mask
    """
    pass


def calculate_percentage_low_attenuation(mask, threshold):
    """
    Calculates the percentage low attenuation of a mask with the defined threshold:
        * Percentage Low Attenuation (%) = (Vol_low/Vol_total) * 100%, where Vol_total is the volume of the mask, and Vol_low is the volume of the mask below or equal to the given threshold.
    
    :param mask: Input mask for the calculation.
    :type mask: mimics.segment.Mask
    :param threshold: Gray value threshold.
    :type threshold: int
    
    :returns: Attenuation
    :rtype: float
    
    :exceptions: ValueError (reason(s): ['Invalid value for argument threshold. Allowed values: 0 - 65535'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	mask = mimics.data.masks[0]
    	t = mask.minimum_value + 2
    	att = mimics.segment.calculate_percentage_low_attenuation(mask,t)

    """
    pass


def fill_holes(mask):
    """
    Fills the holes in a mask.
    
    :param mask: Input mask with the holes to be filled.
    :type mask: mimics.segment.Mask
    
    :returns: Mask with filled holes.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	mimics.segment.fill_holes(mask=m)

    """
    pass


def calculate_part_custom(mask, parameters):
    """
    Part which corresponds to the input mask and generation quality.
    
    :param mask: Defines the mask from which a Part should be calculated.
    :type mask: mimics.segment.Mask
    :param parameters: The custom parameters needed for the part calculation.
    :type parameters: mimics.segment.PartCalculationParameters
    
    :returns: A part which corresponds to input mask and to custom settings
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['A part cannot be generated on empty mask.']), PermissionError (reason(s): ['Not enough space on disk to create part.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	par = mimics.segment.create_part_calculation_parameters()
    	
    	par.used_for_export = True
    	par.quality = 'Custom'
    	par.interpolation_method = 'Contour'
    	par.shell_reduction = True
    	par.triangle_reduction = False
    	par.smoothing = True
    	par.smooth_factor = 0.8
    	par.compensate_smooth_shrinkage = False
    	par.matrix_reduction_xy = 1
    	par.matrix_reduction_z = 1
    	
    	m = mimics.data.masks[1]
    	p = mimics.segment.calculate_part_custom(mask=m, parameters=par)

    """
    pass


def local_threshold(mask, threshold_min, threshold_max, search_distance=1, isolate=False, bounding_box=None):
    """
    Add and remove voxels of a mask and its immediate surroundings by adjusting the threshold of the mask and the size of the surrounding region of the mask
    
    The altered mask contains pixels with a value between the low and high threshold limits and within the defined region.
    
    Note: The upper and lower threshold limits are limited to the maximum and minimum intensity in the project.
    
    :param mask: Mask to be altered.
    :type mask: mimics.segment.Mask
    :param threshold_min: The minimum value of the threshold. Value range: [1,65535]
    :type threshold_min: int
    :param threshold_max: The maximum value of the threshold. Value range: [1,65535]
    :type threshold_max: int
    :param search_distance: (optional) Defines the maximum range in pixels away from the edge of the mask in which the operation is applied. Value range: [0,50]
    :type search_distance: int
    :param isolate: (optional) If True, only voxels connected to the input mask are added by the operation.
    :type isolate: bool
    :param bounding_box: (optional) Clipping box that limits the operation to be performed only on the region of interest within the box. The resulting mask is not cropped, and only altered inside the clipping box.
    :type bounding_box: typing.Optional[mimics.BoundingBox3d]
    
    :returns: The updated mask according to the defined parameters.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['At least one of the vectors of the bounding box has 0 length.', 'Threshold low cannot be greater than threshold high.', 'Search distance must be in 0-50 range.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	input_mask = mimics.data.masks[0]
    	l_t = 100
    	h_t = 3000
    	sd = 10
    	output_mask = mimics.segment.local_threshold(mask=input_mask, threshold_min=l_t, threshold_max=h_t, search_distance=sd, isolate=True)

    """
    pass


def crop_mask(mask, bounding_box):
    """
    Crops a mask. This tool allows the user to select a region of interest and restrict the segmentation to it. When cropping a mask, everything outside the region of interest is erased.
    
    :param mask: Mask to be cropped.
    :type mask: mimics.segment.Mask
    :param bounding_box: Cropping box that includes the region of interest.
    :type bounding_box: mimics.BoundingBox3d
    
    :returns: Cropped mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['At least one of the vectors of the bounding box has 0 length.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	bbox = mimics.measure.get_bounding_box(m)
    	bbox.first_vector = (bbox.first_vector[0]/2, 0, 0)
    	bbox.second_vector = (0, bbox.second_vector[1]/2, 0)
    	bbox.third_vector = (0, 0, bbox.third_vector[2] / 2)
    	
    	mimics.segment.crop_mask(mask=m, bounding_box=bbox)

    """
    pass


def create_segment_vessel_parameters(preset=SegmentVesselPreset.Generic):
    """
    Creates the Segment Vessel advanced parameters object corresponding to the selected preset. If None is passed, the default preset is used. Custom parameters are configured by modifying the properties of a Segment Vessel parameters object.
    
    :param preset: (optional) Preset for advanced parameters for Segment Vessel algorithm. If None is passed, the default preset is used.
    :type preset: mimics.segment.SegmentVesselPreset
    
    :returns: Object that provides access and stores all Segment Vessel additional parameters.
    :rtype: mimics.segment.SegmentVesselParameters
    
    
    :example:
    .. code-block:: python
    
    	 
    	par_default = mimics.segment.create_segment_vessel_parameters()
    	
    	par_default.branch_number = 3
    	par_default.branch_rotation = 75.0
    	par_default.diameter_variability = 0.5
    	par_default.max_length = 500.0
    	par_default.max_diameter = 20.0
    	par_default.min_diameter = 0.5
    	par_default.multibranch = True
    	
    	par_coronal = mimics.segment.create_segment_vessel_parameters(preset=mimics.segment.SegmentVesselPreset.Coronary)
    	
    	par_coronal.branch_number = 5
    	par_coronal.max_length = 300.0

    """
    pass


class SegmentVesselParameters(object):
    """
    Provides access to and stores all Segment Vessel advanced parameters.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def multibranch(self):
        """
        Toggle to segment side branches of a vessel (True) or the main indicated vessel only (False). 
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @multibranch.setter
    def multibranch(self, value):
        """
    
        """
        pass

    @property
    def min_diameter(self):
        """
        The minimum diameter in project units of the desired segmented vessels. Vessels with a diameter smaller than the minimum diameter are not segmented.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Minimum diameter must be greater than 0.', 'Minimum diameter is larger than or equal to maximum diameter. Please review diameter values and try again.'])
        """
        pass
    
    @min_diameter.setter
    def min_diameter(self, value):
        """
    
        """
        pass

    @property
    def max_diameter(self):
        """
        The maximum diameter in project units of the desired segmented vessels. Vessels with a diameter larger than the maximum diameter are not segmented.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Maximum diameter must be greater than 0.', 'Maximum diameter is smaller than or equal to minimum diameter. Please review diameter values and try again.'])
        """
        pass
    
    @max_diameter.setter
    def max_diameter(self, value):
        """
    
        """
        pass

    @property
    def branch_number(self):
        """
        The maximum number of side branches starting from a single point. If exceeded, the segmentation of that branch stops.
        
        :type: <class 'int'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Branch Number must be in range: [2, 10].'])
        """
        pass
    
    @branch_number.setter
    def branch_number(self, value):
        """
    
        """
        pass

    @property
    def diameter_variability(self):
        """
        The diameter_variability parameter measures the average maximum change in diameter of the vessel over a short tail section. It tracks the quotient of the largest diameter of consecutive pairs of the last five detected positions in a vessel. The segmentation in that vessel ends if the quotient is smaller than the diameter_variability parameter.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Diameter Variability must be in range: [0.0, 1.0].'])
        """
        pass
    
    @diameter_variability.setter
    def diameter_variability(self, value):
        """
    
        """
        pass

    @property
    def branch_rotation(self):
        """
        The branch_rotation parameter measures the average maximum change in vessel direction over a short tail section. It tracks the average direction changes of consecutive pairs of the last five detected positions in a vessel. The segmentation in that vessel ends if the average direction change exceeds the branch_rotation parameter.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Branch Rotation must be in range: [0.0, 180.0].'])
        """
        pass
    
    @branch_rotation.setter
    def branch_rotation(self, value):
        """
    
        """
        pass

    @property
    def max_length(self):
        """
        The maximum length in project units of the segmented vessel structure. The segmentation of a (side) branch stops and the tool continues in the remaining branches when the total distance between the indicated seed point and the current branch end exceeds the max_length parameter.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Maximum length must be greater than 0.01.'])
        """
        pass
    
    @max_length.setter
    def max_length(self, value):
        """
    
        """
        pass


def region_grow(input_mask, target_mask, point, slice_type, keep_original_mask=True, multiple_layer=True, connectivity='6-connectivity'):
    """
    Makes it possible to split the mask and to remove floating pixels.
    
    :param input_mask: The input mask.
    :type input_mask: mimics.segment.Mask
    :param target_mask: The target_mask can be a new or an existing mask. If it is an existing mask, the selected region will be added to the mask.
    :type target_mask: typing.Optional[mimics.segment.Mask]
    :param point: Point placed at the object to be kept in the target mask.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param slice_type: Specifies the orientation of the slices (Axial, Coronal or Sagittal)
    :type slice_type: str
    :param keep_original_mask: (optional) Determines if the original mask is preserved. If true, no changes are applied to the original mask.
    :type keep_original_mask: bool
    :param multiple_layer: (optional) Specifies if the operation is performed in single- or multi- slices. If true, the operation is performed as multi-slice 3D.
    :type multiple_layer: bool
    :param connectivity: (optional) Defines if the operation is performed slice by slice or in 3D.
    
    If '6' is selected, the operation investigates the neighbouring pixels slice by slice.
    
    If '26' is selected, the operation investigates the neighbouring pixels in the 3D space. The influence along Z-direction depends on the pixel size (XY) to slice increment (Z) ratio.
    :type connectivity: typing.Optional[typing.Union[str, int]]
    
    :returns: All points in the current segmentation that are connected to the defined point will be moved to the target mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Point should lie inside the source mask'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	mask1 = mimics.data.masks[0]
    	mimics.segment.region_grow(input_mask=mask1,
    	                            target_mask=None, 
    	                            point=mimics.segment.locate_mask(mask1), 
    	                            slice_type="Axial")

    """
    pass


def calculate_part(mask, quality='Optimal'):
    """
    Calculate a Part with the defined quality. All quality aspects are grouped in the predefined Low, Medium and High settings. The Custom setting is user defined. Especially for technical CT applications (and all high resolution scans), it is recommended to study the 3D generation parameters and to define practical custom settings.
    
    :param mask: Defines the mask from which a Part should be calculated.
    :type mask: mimics.segment.Mask
    :param quality: (optional) The different quality options are:
    
     * Low :: shortest calculation time but really rough part representation.
    
     * Medium :: short calculation time, but the dimensions of the 3D will not be accurate because of the matrix reduction that is applied on the images!
    
     * High :: still do a matrix reduction in the XY plane but can give in some situations a smoother and better looking 3D.
    
     * Optimal :: most accurate result.
    :type quality: str
    
    :returns: Part which corresponds to the input mask and generation quality.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['A part cannot be generated on empty mask.']), PermissionError (reason(s): ['Not enough space on disk to create part.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	q = "High" 
    	p = mimics.segment.calculate_part(mask=m, quality=q)

    """
    pass


def morphology_operations(input_mask, operation='Erode', number_of_pixels=1, connectivity=8, target_mask_name=None, limited_to_mask=None):
    """
    Performs morphology operations on the mask. It operates the input mask and the result is copied to the target mask.
    
    :param input_mask: Mask to be altered.
    :type input_mask: mimics.segment.Mask
    :param operation: (optional) The different morphology operations are:
        * Erode :: The operation removes pixels from the edges.
        * Dilate :: The operation adds pixels to the edges.
        * Open :: The operation performs first an erosion, followed by a dilation. Small edges will be removed or opened.
        * Close :: The operation performs first a dilation, followed by an erosion. Small cavities will be closed.
    :type operation: str
    :param number_of_pixels: (optional) The amount of the layers of pixels removed or added in one operation.
    :type number_of_pixels: int
    :param connectivity: (optional) Defines if the operation is performed slice by slice or in 3D.
    
    If '8' is selected, the operation investigates the neighbouring pixels slice by slice.
    
    If '26' is selected, the operation investigates the neighbouring pixels in the 3D space. The influence along Z-direction depends on the pixel size (XY) to slice increment (Z) ratio.
    :type connectivity: typing.Optional[typing.Union[str, int]]
    :param target_mask_name: (optional) The target mask name.
    :type target_mask_name: str
    :param limited_to_mask: (optional) Limits the effect of the operation based on another mask. This prevents an end-result from being larger or smaller than required.
    :type limited_to_mask: mimics.segment.Mask
    
    :returns: Mask which lower and upper threshold boundaries are taken from the input mask.
    :rtype: mimics.segment.Mask
    
    :exceptions: ValueError (reason(s): ['Number of pixels must be in 1-50 range.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	m = mimics.data.masks[0]
    	op = "Dilate"
    	px = 3
    	mimics.segment.morphology_operations(input_mask=m, operation=op, number_of_pixels=px)

    """
    pass


def split_mask(selection, regions):
    """
    Splits a single mask into two or more separate masks. This tool allows easy and quick separation of anatomical parts e.g. heart from the surrounding rib cage or separating talus and calcaneus in the foot. Two masks with the region of interest have to be created and used as an input for splitting the selected mask.
    
    :param selection: The original mask.
    :type selection: mimics.segment.Mask
    :param regions: List of masks that contain marked regions that need to be separated from others. Mask with lower index has a priority over masks with higher indices.
    :type regions: typing.Iterable[mimics.segment.Mask]
    
    :returns: Two masks created from the selection mask.
    :rtype: typing.List[mimics.segment.Mask]
    
    :exceptions: ValueError (reason(s): ['At least two masks should be passed for Split Mask operation. Currently %1 is passed'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	source_m = mimics.data.masks[0]
    	empty_m = [mimics.segment.create_mask() for i in range(2)]
    	reg_m = [mimics.segment.activate_edit_mask(empty_m[i], "Draw", "Lasso", True) for i in range(2)]
    	mimics.segment.split_mask(selection=source_m, regions=reg_m)

    """
    pass


def calculate_ct_heart_right_automatic():
    """
    Segments masks of the right heart chambers based on CT data.
    
    :returns: Creates masks that cover the right heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.segment.calculate_ct_heart_right_automatic()

    """
    pass


def calculate_ct_heart_left_automatic():
    """
    Segments masks of the left heart chambers based on CT data.
    
    :returns: Creates masks that cover the left heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.segment.calculate_ct_heart_left_automatic()

    """
    pass


def calculate_ct_heart_separate_thresholds(threshold_left_min, threshold_left_max, threshold_right_min, threshold_right_max, seed_points, bounding_box=None):
    """
    Segments masks of the heart chambers based on CT data. Threshold ranges and seed points are required. A bounding box can be additionally indicated.
    
    :param threshold_left_min: The minimum value of the left heart threshold. Value range: [1,65535]
    :type threshold_left_min: int
    :param threshold_left_max: The maximum value of the left heart threshold. Value range: [1,65535]
    :type threshold_left_max: int
    :param threshold_right_min: The minimum value of the right heart threshold. Value range: [1,65535]
    :type threshold_right_min: int
    :param threshold_right_max: The maximum value of the right heart threshold. Value range: [1,65535]
    :type threshold_right_max: int
    :param seed_points: Seed points that define particular heart chamber: LA (mandatory), LV (mandatory), AO (mandatory), RA (mandatory), RV (mandatory), PA (mandatory), Other (optional). Represented by the analysis sphere and its radius. Should be an iterable of mimics.analyze.Sphere objects.
    :type seed_points: CustomObjectTypeIterable[mimics.analyze.Sphere]
    :param bounding_box: (optional) Cropping box that includes the region of interest (ROI).
    :type bounding_box: mimics.BoundingBox3d
    
    :returns: Creates masks that cover the heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	thres_left = mimics.segment.activate_thresholding()
    	thres_right = mimics.segment.activate_thresholding()
    	sph = mimics.data.spheres
    	
    	mimics.segment.calculate_ct_heart_separate_thresholds(thres_left.threshold_low, 
    	                                                      thres_left.threshold_high, 
    	                                                      thres_right.threshold_low, 
    	                                                      thres_right.threshold_high, 
    	                                                      seed_points=sph)

    """
    pass


def calculate_ct_heart_automatic(segment_myocardium=False):
    """
    Segments masks of the heart chambers based on CT data.
    
    :param segment_myocardium: (optional) Specifies whether to segment myocardium or not.
    :type segment_myocardium: bool
    
    :returns: Creates masks that cover the heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.segment.calculate_ct_heart_automatic(segment_myocardium=True)

    """
    pass


def calculate_ct_heart_left(threshold_min, threshold_max, seed_points, bounding_box=None):
    """
    Segments masks of the left heart chambers based on CT data. Threshold range and seed points are required. A bounding box can be additionally indicated.
    
    :param threshold_min: The minimum value of the left heart threshold. Value range: [1,65535]
    :type threshold_min: int
    :param threshold_max: The maximum value of the left heart threshold. Value range: [1,65535]
    :type threshold_max: int
    :param seed_points: Seed points that define particular heart chamber: LA (mandatory), LV (mandatory), AO (mandatory), RA (optional), RV (optional), PA (optional), Other (optional). Represented by the analysis sphere and its radius. Should be an iterable of mimics.analyze.Sphere objects.
    :type seed_points: CustomObjectTypeIterable[mimics.analyze.Sphere]
    :param bounding_box: (optional) Cropping box that includes the region of interest (ROI).
    :type bounding_box: mimics.BoundingBox3d
    
    :returns: Creates masks that cover the left heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	thres = mimics.segment.activate_thresholding()
    	sph = mimics.data.spheres
    	
    	mimics.segment.calculate_ct_heart_left(thres.threshold_low,thres.threshold_high,seed_points=sph)

    """
    pass


def calculate_ct_heart_from_mask(mask, seed_points):
    """
    Splits a full heart mask into masks of the heart chambers based on CT data and defined seed points.
    
    :param mask: The mask to calculate the heart chambers from.
    :type mask: mimics.segment.Mask
    :param seed_points: Seed points that define particular heart chamber: LA, LV, RA, RV, AO, PA, Other. Represented by the analysis sphere and its radius. Should be an iterable of mimics.analyze.Sphere objects.
    :type seed_points: CustomObjectTypeIterable[mimics.analyze.Sphere]
    
    :returns: Creates masks that cover the heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.segment.activate_thresholding()
    	sph = mimics.data.spheres
    	mimics.segment.calculate_ct_heart_from_mask(mask=m, seed_points=sph)

    """
    pass


def calculate_ct_heart_single_threshold(threshold_min, threshold_max, bounding_box=None, seed_points=[]):
    """
    Segments masks of the heart chambers based on CT data. Threshold range is required. Seed points and bounding box can be additionally indicated.
    
    :param threshold_min: The minimum value of the threshold. Value range: [1,65535]
    :type threshold_min: int
    :param threshold_max: The maximum value of the threshold. Value range: [1,65535]
    :type threshold_max: int
    :param bounding_box: (optional) Cropping box that includes the region of interest (ROI).
    :type bounding_box: mimics.BoundingBox3d
    :param seed_points: (optional) Seed points that define particular heart chamber: LA, LV, RA, RV, AO, PA, Other. Represented by the analysis sphere and its radius. Should be an iterable of mimics.analyze.Sphere objects.
    :type seed_points: CustomObjectTypeIterable[mimics.analyze.Sphere]
    
    :returns: Creates masks that cover the heart chambers according to the defined parameters.
    :rtype: typing.Iterable[mimics.segment.Mask]
    
    
    :example:
    .. code-block:: python
    
    	 
    	thres = mimics.segment.activate_thresholding()
    	sph = mimics.data.spheres
    	mimics.segment.calculate_ct_heart_single_threshold(thres.threshold_low,thres.threshold_high,seed_points=sph)

    """
    pass


class _CTHeartController(object):
    """
    Controller for CT Heart tool
    """
    def set_lower_thershold(self, value):
        """
        Lower threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_upper_threshold(self, value):
        """
        Upper threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_bounding_box(self, bounding_box):
        """
        Set bbox
        
        :param bounding_box: 
        :type bounding_box: mimics.BoundingBox3d
        """
        pass

    def remove_all_seed_points(self):
        """
        Removes all seed points
        
    
        """
        pass

    def restore_session_parameters(self):
        """
        Restores parameters(seed points) from previous session
        
    
        """
        pass

    def remove_point(self, group_name, seed_point):
        """
        Remove existing seed point
        
        :param group_name: 
        :type group_name: str
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        """
        pass

    def set_hole_size(self, voxel_size):
        """
        Set hole size voxels
        
        :param voxel_size: 
        :type voxel_size: typing.SupportsInt
        """
        pass

    def remove_masks(self, masks):
        """
        Removes masks
        
        :param masks: 
        :type masks: typing.List[mimics.segment.Mask]
        """
        pass

    def unite_masks(self, masks):
        """
        Unite masks
        
        :param masks: 
        :type masks: typing.List[mimics.segment.Mask]
        """
        pass

    def discard(self):
        """
        Cancel processing
        
    
        """
        pass

    def perform_segmentation(self, overwrite_masks):
        """
        Performs segmentation
        
        :param overwrite_masks: 
        :type overwrite_masks: bool
        
        :returns: Returns the result code of CT Heart calculation.
        :rtype: str
        """
        pass

    def add_seed_point(self, seed_point):
        """
        Adds seed point
        
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        
        :returns: Seed point
        :rtype: mimics.analyze.Sphere
        """
        pass

    def add_seed_point_group(self, group_name):
        """
        Add seed point group
        
        :param group_name: 
        :type group_name: str
        """
        pass

    def check_seed_point_intersection_with_other_groups(self, seed_point):
        """
        Check intersection
        
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        
        :returns: Returns result
        :rtype: bool
        """
        pass

    def set_input_masks(self, masks):
        """
        Set masks
        
        :param masks: 
        :type masks: typing.Iterable[mimics.segment.Mask]
        """
        pass

    def set_height_parameter(self, height_mm):
        """
        Set height
        
        :param height_mm: 
        :type height_mm: typing.SupportsFloat
        """
        pass

    def set_core_distance(self, distance_mm):
        """
        Set height
        
        :param distance_mm: 
        :type distance_mm: typing.SupportsFloat
        """
        pass

    def finalize(self):
        """
        Finalize controller
        
    
        """
        pass

    def accept(self):
        """
        Get result of tool
        
        
        
        :returns: Result masks
        :rtype: typing.Tuple[typing.Iterable[mimics.segment.Mask], mimics.segment.Mask]
        """
        pass




class _RegionGrowAppState(object):
    """
    GUI class for interactive usage
    """
    pass


class _AutoCTHeartController(object):
    """
    Controller for Automatic CT Heart tool
    """
    def set_left_lower_threshold(self, value):
        """
        Left lower threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_right_lower_threshold(self, value):
        """
        Right lower threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_left_upper_threshold(self, value):
        """
        Left upper threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_right_upper_threshold(self, value):
        """
        Right upper threshold
        
        :param value: 
        :type value: int
        """
        pass

    def set_bounding_box(self, bounding_box):
        """
        Set bbox
        
        :param bounding_box: 
        :type bounding_box: mimics.BoundingBox3d
        """
        pass

    def remove_all_seed_points(self):
        """
        Removes all seed points
        
    
        """
        pass

    def set_segmentation_mode(self, segmentation_mode):
        """
        Set segmentation mode to either manual or automatic
        
        :param segmentation_mode: 'Auto' or 'Manual'
        :type segmentation_mode: str
        """
        pass

    def set_roi(self, roi):
        """
        Set region of interest to left heart, right heart or full heart
        
        :param roi: 'Left Heart', 'Right Heart', or 'Full Heart'
        :type roi: str
        """
        pass

    def set_segment_myocardium(self, segment_myocardium=False):
        """
        Set segment myocardium indicator in 'Full heart' mode
        
        :param segment_myocardium: (optional) Indicates segment myocardium in 'Full heart' mode
        :type segment_myocardium: bool
        """
        pass

    def restore_session_parameters(self):
        """
        Restores parameters(seed points) from previous session
        
    
        """
        pass

    def is_mandatory_seed_points_set(self):
        """
        Returns True if all mandatory seed points are defined for the defined segmentation mode, otherwise False.
        
    
        """
        pass

    def remove_point(self, group_name, seed_point):
        """
        Remove existing seed point
        
        :param group_name: 
        :type group_name: str
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        """
        pass

    def discard(self):
        """
        Cancel processing
        
    
        """
        pass

    def perform_segmentation(self, overwrite_masks):
        """
        Performs segmentation
        
        :param overwrite_masks: 
        :type overwrite_masks: bool
        
        :returns: Returns the result code of CT Heart calculation.
        :rtype: str
        """
        pass

    def add_seed_point(self, seed_point):
        """
        Adds seed point
        
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        
        :returns: Seed point
        :rtype: mimics.analyze.Sphere
        """
        pass

    def has_neural_networks(self):
        """
        Returns True if all the nnets binary files exist in the Mimics installation folder, otherwise False.
        
    
        """
        pass

    def all_mandatory_masks_segmented(self):
        """
        Returns True if all mandatory masks are segmented, otherwise False.
        
    
        """
        pass

    def check_seed_point_intersection_with_other_groups(self, seed_point):
        """
        Check intersection
        
        :param seed_point: 
        :type seed_point: mimics.analyze.Sphere
        
        :returns: Returns result
        :rtype: bool
        """
        pass

    def finalize(self):
        """
        Finalize controller
        
    
        """
        pass

    def accept(self):
        """
        Get result of tool
        
        
        
        :returns: Result masks
        :rtype: typing.Tuple[typing.Iterable[mimics.segment.Mask], mimics.segment.Mask]
        """
        pass




def create_mask(buffer=None, select_new_mask=True):
    """
    Creates an empty mask. Creates a mask using mask data stored in the buffer if the input buffer is given. Automatic selecting, or not, can be controlled with the parameter 'select_new_mask'.
    
    :param buffer: (optional) Memoryview object with the stored mask data inside.
    :type buffer: memoryview
    :param *: 
    :type *: None
    :param select_new_mask: (optional) If True the new mask will be automatically selected and originally selected mask will be unselected.
    :type select_new_mask: bool
    
    :returns: New mask.
    :rtype: mimics.segment.Mask
    """
    pass


def activate_region_grow(input_mask=None, target_mask=None, keep_original_mask=True, multiple_layer=True, connectivity='6-connectivity'):
    """
    Activates Region Grow tool.
    
    :param input_mask: (optional) The input mask.
    :type input_mask: mimics.segment.Mask
    :param target_mask: (optional) The target mask.
    :type target_mask: mimics.segment.Mask
    :param *: 
    :type *: None
    :param keep_original_mask: (optional) Determines if the original mask is preserved. If true, no changes are applied to the original mask.
    :type keep_original_mask: bool
    :param multiple_layer: (optional) Specifies if the operation is performed in single- or multi- slices. If true, the operation is performed as multi-slice 3D.
    :type multiple_layer: bool
    :param connectivity: (optional) Defines if the operation is performed slice by slice or in 3D.
    
    If '6' is selected, the operation investigates the neighbouring pixels slice by slice.
    
    If '26' is selected, the operation investigates the neighbouring pixels in the 3D space. The influence along Z-direction depends on the pixel size (XY) to slice increment (Z) ratio.
    :type connectivity: typing.Optional[typing.Union[str, int]]
    
    :returns: Returns a modified result mask. All points in the current segmentation that are connected to the defined point will be moved to the target mask.
    :rtype: mimics.segment.Mask
    
    
    :example:
    .. code-block:: python
    
    	 
    	m = mimics.data.masks[0]
    	mimics.segment.activate_region_grow(m,connectivity="26-connectivity")

    """
    pass


def HU2GV(hv):
    """
    Converts value expressed in Hounsfield units to value expressed in pixel gray values.
    
    :param hv: Value expressed in Hounsfield units.
    :type hv: int
    
    
    :example:
    .. code-block:: python
    
    	 
    	hu = 3000
    	gv = mimics.segment.HU2GV(hu)
    	print(gv)

    """
    pass


def GV2HU(gv):
    """
    Converts value expressed in pixel gray values to value expressed in Hounsfield units.
    
    :param gv: Value expressed in pixel grey values.
    :type gv: int
    
    
    :example:
    .. code-block:: python
    
    	 
    	gv = 0
    	hu = mimics.segment.GV2HU(gv)
    	print(hu)

    """
    pass


def activate_calculate_polylines_from_part(selected_parts=None, is_modal=True):
    """
    Activates Calculate Polylines from Part tool.
    
    :param *: 
    :type *: None
    :param selected_parts: (optional) The input parts to calculate polylines from.
    :type selected_parts: typing.Optional[typing.Sequence[mimics.Part]]
    :param is_modal: (optional) Specifies if the script execution will be interrupted till tool work finish.
    :type is_modal: bool
    
    :exceptions: mimics.UserInterrupted (reason(s): ['User interrupted script execution.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.segment.activate_calculate_polylines_from_part(selected_parts=[mimics.data.parts[0]], is_modal=True)

    """
    pass


def activate_local_threshold(mask=None, thresholds=None, search_distance=None, clipping=None, preview=None, isolate=None, is_modal=True):
    """
    Activates Local Threshold tool.
    
    :param *: 
    :type *: None
    :param mask: (optional) The input mask to be altered. If 'None' is given, the user will need to select a mask.
    :type mask: typing.Optional[mimics.segment.Mask]
    :param thresholds: (optional) Minimum and maximum thresholds (GV) for the mask to be set. If 'None' is given, the thresholds are taken from the input mask.
    :type thresholds: typing.Optional[typing.Sequence[int]]
    :param search_distance: (optional) Search distance. Allowed values 0...50. If 'None' is given, then the choice from the previous tool launch is taken.
    :type search_distance: typing.Optional[int]
    :param clipping: (optional) Specifies if the clipping for the resulting mask will be performed by selection ROI. If 'None' is given, then the choice from the previous tool launch is taken.
    :type clipping: typing.Optional[bool]
    :param preview: (optional) Specifies if the preview for the resulting mask is ON. If 'None' is given, then the choice from the previous tool launch is taken.
    :type preview: typing.Optional[bool]
    :param isolate: (optional) Specifies if the Isolate for the resulting mask will be performed. If 'None' is given, then the choice from the previous tool launch is taken.
    :type isolate: typing.Optional[bool]
    :param is_modal: (optional) Specifies if the script execution will be interrupted till tool work finish.
    :type is_modal: bool
    
    :returns: The updated mask according to the defined parameters.
    :rtype: typing.Optional[mimics.segment.Mask]
    
    :exceptions: mimics.UserInterrupted (reason(s): ['User interrupted script execution.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	result_mask = mimics.segment.activate_local_threshold(mask=mimics.data.masks[0], thresholds=[0,1000], search_distance=2, clipping=True, preview=True, isolate=True, is_modal=True)

    """
    pass


def activate_smart_brush(input_mask=None, shape=None, mode=None, diameter=None, sensitivity_percentage=None, selected_mode=None, smooth=None, is_modal=True):
    """
    Activates Smart Brush tool.
    
    :param *: 
    :type *: None
    :param input_mask: (optional) The input mask to be edited. If 'None' is given, then the New Mask will be created.
    :type input_mask: typing.Optional[mimics.segment.Mask]
    :param shape: (optional) Shape of the brush.
    :type shape: typing.Optional[mimics.gui.AreaMarkingShape]
    :param mode: (optional) Mode of the brush.
    :type mode: typing.Optional[mimics.gui.AreaMarkingMode]
    :param diameter: (optional) Diameter of the brush. Allowed values 1...200.
    :type diameter: typing.Optional[int]
    :param sensitivity_percentage: (optional) Tool brush sensitivity. Allowed values 1...100. If 'None' is given, then the choice from the previous tool launch is taken.
    :type sensitivity_percentage: typing.Optional[int]
    :param selected_mode: (optional) Specifies which mode is selected: Region Grow or Ray Cast. Allowed values: 'region_grow' and 'ray_cast' If 'None' is given, then the choice from the previous tool launch is taken.
    :type selected_mode: typing.Optional[str]
    :param smooth: (optional) Specifies if the Smoothing for the result mask will be performed. If 'None' is given, then the choice from the previous tool launch is taken.
    :type smooth: typing.Optional[bool]
    :param is_modal: (optional) Specifies if the script execution will be interrupted till tool work finish.
    :type is_modal: bool
    
    :returns: The edited mask.
    :rtype: typing.Optional[mimics.segment.Mask]
    
    :exceptions: mimics.UserInterrupted (reason(s): ['User interrupted script execution.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	result_mask = mimics.segment.activate_smart_brush(input_mask=mimics.data.masks[0], shape=mimics.gui.AreaMarkingShape.Sphere, mode=mimics.gui.AreaMarkingMode.Draw, diameter=80, sensitivity_percentage=50, selected_mode='region_grow', smooth=True, is_modal=True)

    """
    pass


def activate_ct_heart(mode=None, region_of_interest=None, myocardium=None, threshold_mode=None, threshold_1=None, threshold_2=None, is_modal=True):
    """
    Activates CT Heart tool.
    
    :param *: 
    :type *: None
    :param mode: (optional) The method used for segmentation of the cardiac regions. The Automatic mode will perform segmentation in an automated way, while the Manual mode requires the user to specify threshold values and seed points to mark the different regions.
    :type mode: typing.Optional[str]
    :param region_of_interest: (optional) The regions that shall be segmented by the algorithm. The Left Heart ROI shall attempt to segment the LA, LV and AO regions. The Right Heart ROI shall attempt to segment the RA, RV and PA regions. The Full Heart mode shall attempt to segment all of the above.
    :type region_of_interest: typing.Optional[str]
    :param myocardium: (optional) Enables/disables the checkbox for Myocardium segmentation. When enabled, the Myocardium shall be segmented. Only available for the Automatic Full Heart mode.
    :type myocardium: typing.Optional[bool]
    :param threshold_mode: (optional) Selects the 'Separate' or 'Single' threshold mode for the Manual CT heart segmentation.
    :type threshold_mode: typing.Optional[str]
    :param threshold_1: (optional) If Manual Left Heart or Manual Full Heart Separate Thresholds mode is selected - sets min and max threshold values for the Left Heart Threshold. If Manual Full Heart Single Threshold is selected - sets min and max threshold values for the Heart Threshold. Otherwise, this parameter is ignored.
    :type threshold_1: typing.Optional[typing.Sequence[int]]
    :param threshold_2: (optional) If Manual Full Heart Separate Thresholds mode is selected - sets min and max threshold values for the Right Heart Threshold. Otherwise, this parameter is ignored.
    :type threshold_2: typing.Optional[typing.Sequence[int]]
    :param is_modal: (optional) Specifies if the script execution will be interrupted till tool work finish.
    :type is_modal: bool
    
    :returns: Creates masks that cover the heart chambers according to the defined parameters.
    :rtype: typing.Optional[typing.Sequence[mimics.segment.Mask]]
    
    :exceptions: mimics.UserInterrupted (reason(s): ['User interrupted script execution.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	segmentation_result = mimics.segment.activate_ct_heart(mode='Manual', region_of_interest='Full Heart', myocardium=False, threshold_mode='Single', threshold_1=(1204,2188), threshold_2=(1112,2678), is_modal=True)

    """
    pass


def activate_segment_vessel(target_mask=None, thresholds=None, min_diameter=None, max_diameter=None, diameter_variability=None, branch_rotation=None, multibranch=None, branch_number=None, limit_length=None, max_length=None, is_modal=True):
    """
    Activates Segment Vessel tool.
    
    :param *: 
    :type *: None
    :param target_mask: (optional) Mask to which the segmented blood vessels are added. If 'None' is given, a new mask containing the segmented vessels is created.
    :type target_mask: typing.Optional[mimics.segment.Mask]
    :param thresholds: (optional) Minimum and maximum thresholds (GV) for the mask to be set. If 'None' is given, the thresholds are taken from the input mask.
    :type thresholds: typing.Optional[typing.Sequence[int]]
    :param min_diameter: (optional) The minimum diameter in project units of the desired segmented vessels. The minimum diameter must be greater than 0 and less than the max diameter. Vessels with a diameter smaller than the minimum diameter are not segmented. If 'None' is given, then the choice from the previous tool launch is taken.
    :type min_diameter: typing.Optional[typing.SupportsFloat]
    :param max_diameter: (optional) The maximum diameter in project units of the desired segmented vessels. The maximum diameter must be greater than 0 and the minimum diameter. Vessels with a diameter larger than the maximum diameter are not segmented. If 'None' is given, then the choice from the previous tool launch is taken.
    :type max_diameter: typing.Optional[typing.SupportsFloat]
    :param diameter_variability: (optional) The diameter variability parameter measures the average maximum change in diameter of the vessel over a short tail section. Allowed values 0...100. It tracks the quotient of the largest diameter of consecutive pairs of the last five detected positions in a vessel. The segmentation in that vessel ends if the quotient is smaller than the diameter_variability parameter. If 'None' is given, then the choice from the previous tool launch is taken.
    :type diameter_variability: typing.Optional[int]
    :param branch_rotation: (optional) The branch rotation parameter measures the average maximum change in vessel direction over a short tail section. Allowed values 0...180. It tracks the average direction changes of consecutive pairs of the last five detected positions in a vessel. The segmentation in that vessel ends if the average direction change exceeds the branch_rotation parameter. If 'None' is given, then the choice from the previous tool launch is taken.
    :type branch_rotation: typing.Optional[int]
    :param multibranch: (optional) Specifies whether to segment side branches of a vessel (True) or the main indicated vessel only (False). If 'None' is given, then the choice from the previous tool launch is taken.
    :type multibranch: typing.Optional[bool]
    :param branch_number: (optional) The maximum number of side branches starting from a single point. If exceeded, the segmentation of that branch stops. Allowed values 2...10. If 'None' is given, then the choice from the previous tool launch is taken.
    :type branch_number: typing.Optional[int]
    :param limit_length: (optional) Specifies whether to limit the length of a vessel (True) or no (False). If 'None' is given, then the choice from the previous tool launch is taken.
    :type limit_length: typing.Optional[bool]
    :param max_length: (optional) The maximum length in project units of the segmented vessel structure. Maximum length must be greater than 0.0001. The segmentation of a (side) branch stops and the tool continues in remaining branches when the total distance between the indicated seed point and the current branch end exceeds the max_length parameter. If 'None' is given, then the choice from the previous tool launch is taken.
    :type max_length: typing.Optional[typing.SupportsFloat]
    :param is_modal: (optional) Specifies if the script execution will be interrupted till tool work finish.
    :type is_modal: bool
    
    :returns: Mask with segmented vessels. The returned mask is merged with the input mask or created as a new mask if no input mask was provided.
    :rtype: typing.Optional[mimics.segment.Mask]
    
    :exceptions: mimics.UserInterrupted (reason(s): ['User interrupted script execution.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	target_mask = mimics.segment.activate_segment_vessel(target_mask=mimics.data.masks[0], thresholds=[0,1000], min_diameter=0.01, max_diameter=40.0, diameter_variability=25, branch_rotation=90, multibranch=True, branch_number=6, limit_length=True, max_length=200000.0, is_modal=True)

    """
    pass


