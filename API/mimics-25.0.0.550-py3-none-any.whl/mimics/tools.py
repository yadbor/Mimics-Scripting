import typing
import mimics


def calculate_part_contours_on_plane(part, origin, normal):
    """
    Calculates countour points of the intersection between the defined Part and a plane defined by the given origin and normal.
    
    :param part: The Part.
    :type part: mimics.Part
    :param origin: Origin of the intersecting plane.
    :type origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param normal: Normal of the intersecting plane.
    :type normal: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Countour points.
    :rtype: typing.List[typing.List[typing.Tuple[float, float, float]]]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	pl = mimics.data.planes[0]
    	cntr = mimics.tools.calculate_part_contours_on_plane(part=p,
    	                                                    origin=pl.origin,
    	                                                    normal=pl.normal)

    """
    pass


def hollow(objects_to_hollow, hollow_inside=True, thickness=1.5, keep_originals=True):
    """
    Hollows parts.
    
    :param objects_to_hollow: Parts to hollow.
    :type objects_to_hollow: typing.Iterable[mimics.Part]
    :param hollow_inside: (optional) Hollowing direction: inside if True, outside if False.
    :type hollow_inside: bool
    :param thickness: (optional) Wall thickness for hollowing operation.
    :type thickness: typing.SupportsFloat
    :param keep_originals: (optional) If True, hides the original Parts but does not delete them.
    :type keep_originals: bool
    
    :returns: List of Parts that is the result of hollowing operation.
    :rtype: typing.List[mimics.Part]
    
    :exceptions: ValueError (reason(s): ['List of parts to hollow is empty.', 'Specified thickness is too small; it should be at least 0.01.', 'Failed to hollow part. Please check the quality of the part and try again.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	part0 = mimics.data.parts[0]
    	part1 = mimics.data.parts[1]
    	mimics.tools.hollow([part0, part1], True, 2.0)

    """
    pass


def wrap(object_to_wrap, smallest_detail=None, gap_closing_distance=None, dilate_result=False, protect_thin_walls=False, keep_originals=True):
    """
    Creates a wrapping surface of the selected object.
    
    This tool is particularly useful for medical parts, to filter small inclusions or close small holes. Furthermore, the function is a useful tool towards Finite Element Analysis, where an enveloping surface is needed.
    
    :param object_to_wrap: Part to be wrapped.
    :type object_to_wrap: mimics.Part
    :param smallest_detail: (optional) Corresponds to the size of the triangles of the new surface. Value range: [0.01, 10000]. If None, the default value is project's pixel size multiplied by 2.
    :type smallest_detail: typing.SupportsFloat
    :param gap_closing_distance: (optional) Determines the size of gaps that will be wrapped away via the operation. Value range: [0.01, 10000]. If None, the default value is project's pixel size.
    :type gap_closing_distance: typing.SupportsFloat
    :param dilate_result: (optional) If true, the result after wrapping will be dilated such that the pixels around the extremities of the mask are included.
    :type dilate_result: bool
    :param protect_thin_walls: (optional) Specifies the protection of the thin walls. If true, thin walls are preserved resulting to a slightly thicker model than the original one. If false, thin walls are not protected. Depending on the smallest detail it is possible that the walls with a thickness within the same range are collapsed.
    :type protect_thin_walls: bool
    :param keep_originals: (optional) Determines if the original objects are preserved. If true, the original objects are kept, otherwise they are deleted.
    :type keep_originals: bool
    
    :returns: A wrapped Part.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Cannot wrap empty STL', 'Smallest detail parameter should be in range from 0.01 to 10000', 'Gap closing distance parameter should be in range from 0.01 to 10000']), MemoryError (reason(s): ['Not enough memory to perform Wrap operation with defined parameters. Please adjust the parameters and try again.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	sd = 0.6
    	gcd = 0.6
    	mimics.tools.wrap(object_to_wrap=p, smallest_detail=sd, gap_closing_distance=gcd)

    """
    pass


def smooth(object_to_smooth, smooth_factor, iterations=1, compensate_shrinkage=False, keep_originals=False):
    """
    Performs smoothing of the Part. The result of smoothing operation is put in the Part's list.
    
    :param object_to_smooth: Part to be smoothed.
    :type object_to_smooth: mimics.Part
    :param smooth_factor: Determines how much smoothing is performed. Value range: [0, 1].
    :type smooth_factor: typing.SupportsFloat
    :param iterations: (optional) Specifies the number of the iterations that are performed. Value range: [1, 500]
    :type iterations: int
    :param compensate_shrinkage: (optional) Determines the shrinkage of the object due to the smoothing. If true, the shrinkage of the object is countered.
    :type compensate_shrinkage: bool
    :param keep_originals: (optional) Determines if the original objects are preserved. If true, the original objects are kept, otherwise they are deleted.
    :type keep_originals: bool
    
    :returns: A smoothed Part.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Cannot smooth empty STL', 'Smooth factor should be in range 0..1', 'Iterations count should be in range 1..500'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	sf = 0.6
    	it = 10
    	mimics.tools.smooth(object_to_smooth=p, smooth_factor=sf, iterations=it)

    """
    pass


def cut_with_plane(parts, plane, plane_thickness=None, keep_originals=True, split_result=False, sorting_order='SortByVolume'):
    """
    Cuts one or more Parts with a plane.
    
    :param parts: Parts to cut.
    :type parts: typing.Iterable[mimics.Part]
    :param plane: Plane that will be used for cutting.
    :type plane: mimics.analyze.Plane
    :param plane_thickness: (optional) Thickness of a cutting parallelepiped. If not specified, cutting will be performed with an infinite analytical plane.
    :type plane_thickness: typing.SupportsFloat
    :param keep_originals: (optional) If true, hides the original Parts but does not delete them.
    :type keep_originals: bool
    :param split_result: (optional) If true, will split each of resulting Parts after cutting.
    :type split_result: bool
    :param sorting_order: (optional) Sorts the output result. 'SortByVolume' - sort result by volume, 'SortByPlaneSide' - sorts by direction of plane`s normal, when same direction sort by volume.
    :type sorting_order: str
    
    :returns: List of Parts that is the result of cutting and splitting operations.
    :rtype: typing.List[mimics.Part]
    
    :exceptions: ValueError (reason(s): ['Parts list is empty.', 'Specified plane thickness is too small; it should be at least 0.01.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	part0 = mimics.data.parts[0]
    	part1 = mimics.data.parts[1]
    	plane = mimics.data.planes[0]
    	mimics.tools.cut_with_plane([part0, part1], plane)

    """
    pass


