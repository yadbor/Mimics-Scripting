import typing
import mimics


class CineLoopPlayer(object):
    """
    The cine_loop_control_panel object.
    """
    def pause(self):
        """
        Pause playng the cineloop
        
        
        
        :returns: Result
        :rtype: bool
        """
        pass

    def close(self):
        """
        Close cineloop mode
        
        
        
        :returns: Result
        :rtype: bool
        """
        pass

    def play(self, play_for=0):
        """
        Start playng the cineloop 
        
        :param play_for: (optional) Positive integers - number of seconds to play, otherwise - play until stopped
        :type play_for: int
        
        :returns: Result
        :rtype: bool
        """
        pass

    def next(self):
        """
        The next image of cineloop
        
        
        
        :returns: Result
        :rtype: bool
        """
        pass

    def previous(self):
        """
        The previous image of cineloop
        
        
        
        :returns: Result
        :rtype: bool
        """
        pass

    @property
    def loop(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @loop.setter
    def loop(self, value):
        """
    
        """
        pass

    @property
    def speed(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @speed.setter
    def speed(self, value):
        """
    
        """
        pass


