import rpyc

conn_mimics = None
portnumber = 15012

def create_connection():
    global conn_mimics
    global portnumber
    try:
        conn_mimics = rpyc.connect("localhost",portnumber,config = {"allow_public_attrs" : True})
        print("Connected to listening service")
    except:
        raise RuntimeError("Could Not Connect, first start Mimics external IDE scripting service")

def send_command(name, args, kwargs):
    if conn_mimics == None:
        create_connection()
    elif conn_mimics.closed == True:
        create_connection()

    keys = []
    values = []
    for k, v in kwargs.items():
        keys.append(k)
        values.append(v)

    kwargs_as_tuple = ((tuple(keys), tuple(values)))
    return conn_mimics.root.get_answer(name, args, kwargs_as_tuple)

def close():
    global conn_mimics
    if conn_mimics == None:
        create_connection()
    if conn_mimics.closed != True:
        stoppingservice = rpyc.connect("localhost",15013)
        stoppingservice.root.stop_mimics_service()

