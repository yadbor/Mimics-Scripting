import typing
import mimics


def invert_transformation(transformation):
    """
    Inverts input transformation object.
    
    :param transformation: Transformation object.
    :type transformation: mimics.Transformation
    
    
    :example:
    .. code-block:: python
    
    	 
    	t = mimics.data.transformations[0]
    	# the same as t.invert()
    	mimics.experimental.invert_transformation(t)

    """
    pass


def set_transformation(object, transformation):
    """
    Sets (replaces) transformation to object.
    
    :param object: Object for which to set transformation.
    :type object: typing.Union[mimics.Part, mimics.Osteotomy, mimics.analyze.Point, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Plane, mimics.analyze.Centerline]
    :param transformation: Transformation object.
    :type transformation: mimics.Transformation
    
    
    :example:
    .. code-block:: python
    
    	 
    	part_a = mimics.data.parts[0]
    	part_b = mimics.data.parts[1]
    	
    	transformation_a = mimics.experimental.create_transformation_from_object(part_a)
    	
    	p = mimics.experimental.set_transformation(part_b, transformation_a)

    """
    pass


def create_transformation_from_object(object):
    """
    Creates transformation object.
    
    :param object: Object from which the transformation is created.
    :type object: mimics.Object
    
    :returns: Transformation object
    :rtype: mimics.Transformation
    
    :exceptions: ValueError (reason(s): ['Transformation object can not be created if tranformation matrix is not rigid.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	part_a = mimics.data.parts[0]
    	
    	device_transformation = mimics.experimental.create_transformation_from_object(part_a)

    """
    pass


