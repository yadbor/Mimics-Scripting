import typing
import mimics


class SubvolumeMesh(mimics.Object):
    """
    A part of a volume mesh based on voxels.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def number_of_elements(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def number_of_nodes(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def material_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @material_visible.setter
    def material_visible(self, value):
        """
    
        """
        pass

    @property
    def contour_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @contour_visible.setter
    def contour_visible(self, value):
        """
    
        """
        pass

    @property
    def material_assigned(self):
        """
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass


def assign_material_from_lookup(volume_mesh, lookup_file):
    """
    Assigns material to the selected volume mesh or its subvolumes according to the parameteres from lookup file. Note that most FEA software does not allow to enter a density with a negative value.
    
    :param volume_mesh: A volume mesh.
    :type volume_mesh: mimics.fea.VolumeMesh
    :param lookup_file: Path to the desired lookup file.
    :type lookup_file: str
    
    
    :example:
    .. code-block:: python
    
    	 
    	vol_mesh = mimics.data.meshes[0]
    	look_up_file = r"C:\MedData\DemoFiles\Lookup_Tables\lookup_table_v2_0.xml"
    	mimics.fea.assign_material_from_lookup(vol_mesh,look_up_file)
    	print(vol_mesh.material_assigned)

    """
    pass


class _MaterialAssignmentController(object):
    """
    Allows to assign materials to VolumeMesh object
    """
    def set_mesh(self, mesh):
        """
        Set mesh to work with
        
        :param mesh: 
        :type mesh: mimics.fea.VolumeMesh
        """
        pass

    def set_mesh_subvolume(self, mesh_subvolume):
        """
        Set mesh subvolume to work with
        
        :param mesh_subvolume: 
        :type mesh_subvolume: mimics.fea.SubvolumeMesh
        """
        pass

    def init_from_lookup_file(self, lookup_filename):
        """
        Init controller from lookup
        
        :param lookup_filename: 
        :type lookup_filename: str
        """
        pass

    def assign_materials(self):
        """
        Assign materials
        
    
        """
        pass

    def finalize(self):
        """
        Clear controller
        
    
        """
        pass




class AbaqusSingleOutputExportOptions(object):
    """
    Options structure for abaqus single output text format.
    """
    def __init__(self, mesh, export_volume, export_surface, element_type=None):
        """
        :param mesh: 
        :type mesh: mimics.fea.VolumeMesh
        :param export_volume: 
        :type export_volume: bool
        :param export_surface: 
        :type export_surface: bool
        :param element_type: (optional) 
        :type element_type: typing.Union[str, None]
        """
        pass

    @property
    def mesh(self):
        """
        :type: <class 'mimics.fea.VolumeMesh'>
        :read-only: False
    
        """
        pass
    
    @mesh.setter
    def mesh(self, value):
        """
    
        """
        pass

    @property
    def export_volume(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @export_volume.setter
    def export_volume(self, value):
        """
    
        """
        pass

    @property
    def export_surface(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @export_surface.setter
    def export_surface(self, value):
        """
    
        """
        pass

    @property
    def element_type(self):
        """
        :type: typing.Union[str, NoneType]
        :read-only: False
    
        """
        pass
    
    @element_type.setter
    def element_type(self, value):
        """
    
        """
        pass


class VolumeMesh(mimics.Object):
    """
    A volume mesh based on voxels.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def number_of_elements(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def number_of_nodes(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def number_of_subvolumes(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def subvolumes(self):
        """
        :type: typing.List[mimics.fea.SubvolumeMesh]
        :read-only: True
    
        """
        pass

    @property
    def material_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @material_visible.setter
    def material_visible(self, value):
        """
    
        """
        pass

    @property
    def contour_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @contour_visible.setter
    def contour_visible(self, value):
        """
    
        """
        pass

    @property
    def material_assigned(self):
        """
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass


