import inspect
from functools import wraps, reduce
from collections.abc import Callable

#TODO: remove following imports
import mimics
import typing
import mimics.connmim

from types import BuiltinFunctionType, FunctionType

MODULE_PATCHABLE = (BuiltinFunctionType, FunctionType)

def decorate(func, decorators, callable_only=False):
    """Return a function decorated by all decorators or the function itself
    if there are no decorators specified or the func is not callable and
    callable_only is True.
    """
    if callable_only and not isinstance(func, Callable):
        return func

    reducced_p = reduce(lambda a, b: b(a), decorators, func)
    return reducced_p

def convert_to_tuple(arg):
    RETURN_AS_IS_TYPES = [
      str,
      tuple,
      mimics.Object
      ]

    for rt in RETURN_AS_IS_TYPES:
        if isinstance(arg, rt):
            return arg

    if isinstance(arg, typing.Iterable):
        return_value = []
        for v in arg:
            return_value.append(convert_to_tuple(v))
        return tuple(return_value)
    
    return arg

def call_listener(full_method_name):
    def wrapper(func):
        @wraps(func)
        def wrapped(*args, **kwargs):
            new_args = []
            for arg in args:
                new_args.append(convert_to_tuple(arg))
            
            new_kwargs = dict()
            for k, v in kwargs.items():
                new_kwargs[k] = convert_to_tuple(v)

            result = mimics.connmim.send_command(full_method_name, tuple(new_args), new_kwargs)
            if result and isinstance(result, Exception):
                raise result.__class__(str(result))

            return result
        return wrapped
    return wrapper


def patch_module(module = None):
    if not module:
        module = mimics

    modules = {k: v for k, v in module.__dict__.items() if inspect.ismodule(v)}
    methods = {k: v for k, v in module.__dict__.items() if isinstance(v, MODULE_PATCHABLE)}

    for method_name, method in methods.items():
        listener_caller = call_listener('{}.{}'.format(module.__name__, method_name))
        method_wrappers = (listener_caller, )

        _method_wrappers = list(method_wrappers)
        decorated_method = decorate(method, _method_wrappers)
        setattr(module, method_name, decorated_method)

    MODULES_TO_SKIP = [
        mimics,
        typing,
        mimics.wrap_api,
        mimics.connmim
    ]

    for sub_module_name, sub_module in modules.items():
        if sub_module not in MODULES_TO_SKIP:
            patch_module(sub_module)


def patch_data_object():
    mimics.data = mimics.connmim.send_command('mimics.data',(), {})
