import typing
import mimics


def modify_tag(filename, tagpath, value):
    """
    Modifies tag value in the specified DICOM file. Mimics supports modification of DICOM tags with the following value representations (VR): CS, DA, DS, FD, FL, IS, LO, PN, SH, SL, SS, TM, UL, US. We recommend to not use this API to modify DICOM tags with value representation OB, tags with group ID 0002, and tags with tag ID 0000. Caution should be taken when modifying tags with value representation SQ, to not create internal inconsistencies.
    
    :param filename: Full path to the file
    :type filename: str
    :param tagpath: Tag to anonymize
    :type tagpath: typing.Iterable
    :param value: New value
    :type value: str
    
    :exceptions: ValueError (reason(s): ['Tag path can`t be empty'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	#It is highly recommended to copy the original DICOM before modifying it
    	f = r'C:\MedData\DemoFiles\DICOM_Mandible\SIMON_0.dcm'
    	
    	patient_name_tag = [(0x0010, 0x0010)] # hexadecimal
    	new_name = "Doe John"
    	mimics.dicom.modify_tag(filename=f, tagpath=patient_name_tag, value=new_name)
    	
    	patient_birth_tag = [(16,48)] #decimal
    	new_birth_date = "19641128"
    	mimics.dicom.modify_tag(filename=f, tagpath=patient_birth_tag, value=new_birth_date)

    """
    pass


def anonymize_file(filename, retain_attributes=[]):
    """
    Removes patient's information from specified DICOM file. If some DICOM File Meta Element tags are absent [0002, XXXX] they will appear, except [0002, 0100] and [0002, 0102].
    
    :param filename: Full path to the DICOM file to anonymize.
    :type filename: str
    :param retain_attributes: (optional) Anonymize attributes.
    :type retain_attributes: typing.Iterable[str]
    
    
    :example:
    .. code-block:: python
    
    	 
    	dicom = 'C:\MedData\DemoFiles\DICOM_Airway\J_50230713_0.dcm'
    	attrs = ["RETAIN_SAFE_PRIVATE_OPTION", "CLEAN_DESC_OPTION"]
    	mimics.dicom.anonymize_file(filename = dicom, retain_attributes = attrs)

    """
    pass


