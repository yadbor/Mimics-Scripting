import typing
import mimics


class PulmonarySurface(object):
    """
    This object class represents cutting surface object of pulmonology module
    """
    pass


def boolean_3d_unite(object1, object2, keep_originals=True):
    """
    Boolean unite operation between Parts, STLs or Analysis Spheres and Cylinders. Can be performed between two or more objects.
    
    :param object1: Object to be used first for the boolean operation.
    :type object1: mimics.Object
    :param object2: Object to be used second for the boolean operation.
    :type object2: mimics.Object
    :param keep_originals: (optional) If true, it keeps original Parts unchanged.
    :type keep_originals: bool
    
    :returns: Part that is the result of boolean unite operation.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Passed object is not supported in boolean operations.', 'An empty list passed.', 'Result of boolean operation cannot be empty.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = mimics.data.parts[0]
    	p2 = mimics.data.parts[1]
    	res = mimics.simulate.boolean_3d_unite(object1=p1, object2=p2)

    """
    pass


def boolean_3d(object_list1, object_list2, operation='Unite', keep_originals=True):
    """
    Boolean operation between Parts, STLs or Analysis Lines, Spheres, Splines and Cylinders. Can be performed between two or more objects.
    
    :param object_list1: Object(s) to be used first for the boolean operation.
    :type object_list1: CustomObjectTypeIterable[typing.Union[mimics.Part, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Line]]
    :param object_list2: Object(s) to be used second for the boolean operation.
    :type object_list2: CustomObjectTypeIterable[typing.Union[mimics.Part, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Line]]
    :param operation: (optional) Boolean operation name.
    :type operation: str
    :param keep_originals: (optional) If true, it keeps original Parts unchanged.
    :type keep_originals: bool
    
    :returns: Part that is the result of boolean operation.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Passed object is not supported in boolean operations.', 'An empty list passed.', 'Result of boolean operation cannot be empty.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = mimics.data.parts[0]
    	p2 = mimics.data.parts[1]
    	p3 = mimics.data.parts[2]
    	mimics.simulate.boolean_3d([p1],[p2,p3],"Unite")

    """
    pass


def boolean_3d_minus(object1, object2, keep_originals=True):
    """
    Boolean minus operation between Parts, STLs or Analysis Spheres and Cylinders. Can be performed between two or more objects.
    
    :param object1: Object of the first group to be used for boolean operation.
    :type object1: mimics.Object
    :param object2: Object of the second group to be used for boolean operation.
    :type object2: mimics.Object
    :param keep_originals: (optional) If true, it keeps original Parts unchanged.
    :type keep_originals: bool
    
    :returns: Part that is the result of boolean minus operation.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Passed object is not supported in boolean operations.', 'An empty list passed.', 'Result of boolean operation cannot be empty.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = mimics.data.parts[0]
    	p2 = mimics.data.parts[1]
    	res = mimics.simulate.boolean_3d_minus(object1=p1, object2=p2)

    """
    pass


def boolean_3d_intersect(object1, object2, keep_originals=True):
    """
    Boolean intersect operation between Parts, STLs or Analysis Spheres and Cylinders. Can be performed between two or more objects.
    
    :param object1: Object of the first group to be used for the boolean operation.
    :type object1: mimics.Object
    :param object2: Object of the second group to be used for the boolean operation.
    :type object2: mimics.Object
    :param keep_originals: (optional) If true, it keeps original Parts unchanged.
    :type keep_originals: bool
    
    :returns: Part that is the result of boolean intersect operation.
    :rtype: mimics.Part
    
    :exceptions: ValueError (reason(s): ['Passed object is not supported in boolean operations.', 'An empty list passed.', 'Result of boolean operation cannot be empty.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = mimics.data.parts[0]
    	p2 = mimics.data.parts[1]
    	res = mimics.simulate.boolean_3d_intersect(object1=p1, object2=p2)

    """
    pass


