import typing
import mimics


class Subscription(object):
    """
    RAII object that unsubscribes from notification when removed.
    """
    def __init__(self, notification_name, callback, notification_type='after', timeout=None, singleshot=None, is_enabled_if_modal_gui=None):
        """
        Init
        
        :param notification_name: 
        :type notification_name: str
        :param callback: 
        :type callback: collections.abc.Callable
        :param *: 
        :type *: None
        :param notification_type: (optional) 
        :type notification_type: str
        :param timeout: (optional) 
        :type timeout: int
        :param singleshot: (optional) 
        :type singleshot: bool
        :param is_enabled_if_modal_gui: (optional) 
        :type is_enabled_if_modal_gui: bool
        """
        pass

    def unsubscribe(self):
        """
        Unsubscribes from notification. If the given subscription already unsubscribed, then calling the method is noop (in this case, mimics.events.Subscription.is_active() returns False).
        
    
        """
        pass

    def is_active(self):
        """
        Checks if the subscription is active.
        
        Subscriptions are immediatelly active after they have been created with 'mimics.events.subscribe()'.
        
        Call mimics.events.Subscription.unsubscribe() against the subscription object in question to de-activate it.
        
        
        
        :returns: True if the given subscription is active, False otherwise. 
        :rtype: bool
        """
        pass




def unsubscribe_all():
    """
    Unsubscribes from all notifications.
    
    Use 'mimics.events.Subscription.unsubscribe()' method to unsubscribe from individual notications for the 'Subscription' object obtained with 'mimics.events.subscribe()' API while subscribing.
    
    Important:
        * This API shall only be used in extreme situations and/or for diagnostic or debugs purposes.
        * It is so because this API unsubscribes not only notification of the given script or scripting plugin, but all 'your' AND somebody else's notificaitons, thus 'destroying' logic of other scripting plugin which are loaded now.
        * A safer way is to unsubsribe on individual notification basis. See more in documentation for 'mimics.events.Subscription.unsubscribe()'.
    
    
    :example:
    .. code-block:: python
    
    	 
    	# Attention:
    	#  * the sample below is not for usage in production code
    	import mimics
    	import logging
    	
    	DIAGNOSTIC_MODE = True
    	
    	
    	def on_object_changed(obj: mimics.Object):
    	    global DIAGNOSTIC_MODE
    	    
    	    mimics.logging.log_user_message(logging.INFO, "Notification received, object: {}".format(obj))
    	    if DIAGNOSTIC_MODE:
    	        # Note:
    	        #  * for diagnostic purposes, i would like to clear ALL (mine and others)
    	        #    subscriptions because i would like to test how it works 
    	        #    with a single event or signle object first
    	        mimics.events.unsubscribe_all()
    	        mimics.logging.log_user_message(logging.DEBUG, "All subscriptions have been dropped!")
    	    
    	    # Do some manipulation with the objects
    	    # Note: some of them might be changing manipulations
    	    #       which will result sending "enclosed" recursive event
    	    obj.name = "Changed on-fly: " + obj.name
    	
    	
    	sub_obj_changed = mimics.events.subscribe(notification_name="obj_changed", callback=on_object_changed)
    	# Instructions:
    	# * execute script and change some of the objects with GUI

    """
    pass


def subscribe(notification_name, callback, notification_type='after', timeout=None, singleshot=None, is_enabled_if_modal_gui=None):
    """
    Creates a new subscription for a specific notification. Whenever specific notification occures - defined callback function will be called.
    
    Supported notifications names:
        * 'doc_opened' : is triggered when a Project is opened. Callback function has no arguments. Supports both 'before' and 'after' notification_type. For detailed example see the 'Example' section below.
        * 'doc_saved' : is triggered when current opened Project is about to be saved or after it has been saved. Callback function has no arguments. Supports both 'before' and 'after' notification_type. For detailed example see the 'Example' section below.
        * 'doc_closed' : is triggered when current opened Project is closed. Callback function has no arguments. Supports both 'before' and 'after' notification_type. For detailed example see the 'Example' section below.
        * 'app_closed' : is triggered when the application is closed. Callback function has no arguments. Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'pm_tab_closed' : is triggered when the Project Management tab (e.g. 'Masks', 'Objects', etc.) is closed. In case the whole Project Management panel is closed - separate notifications for all visible PM tabs will be triggered. Callback function has 1 argument - id of the PM tab that was closed (type : str). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'pm_tab_docked' : is triggered when the Project Management tab (e.g. 'Masks', 'Objects', etc.) is docked to any place in other suitable Widget. By default all PM Tabs are docked to Project Management panel. Callback function has 1 argument - id of the PM tab that was docked (type : str). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'pm_tab_undocked' : is triggered when the Project Management tab (e.g. 'Masks', 'Objects', etc.) is undocked to floating position. By default all PM Tabs are docked to Project Management panel. Callback function has 1 argument - id of the PM tab that was undocked (type : str). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_added' : is triggered when any mimics.Object or derived class object has been added to currently opened Project. Callback function has 1 argument - mimics.Object or derived class object that has been added (exact type depends of the added object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_deleted' : is triggered when any mimics.Object or derived class object is deleted from currently opened Project. Callback function has 1 argument - mimics.Object or derived class object that has been deleted (exact type depends of the deleted object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_geometry_changed' : is triggered when the geometry of mimics.Object`s or derived class object`s geometry in current opened Project is changed (position, geometrical properties, etc.) Callback function has 1 argument - mimics.Object or derived class object which geometry was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_relation_changed' : is triggered when the relation (link to specific Image data for Objects) of mimics.Object`s or derived class object`s in current opened Project is changed. Callback function has 1 argument - mimics.Object or derived class object which relation was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_label_changed' : is triggered when the name of mimics.Object`s or derived class object`s in current opened Project is changed. Callback function has 1 argument - mimics.Object or derived class object which name was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_metadata_changed' : is triggered when the metadata of mimics.Object`s or derived class object`s in current opened Project is changed. Callback function has 1 argument - mimics.Object or derived class object which metadata was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_visual_state_changed' : is triggered when the visibility of mimics.Object or derived class object in current opened Project is changed. Callback function has 1 argument - mimics.Object or derived class object which visibility was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_selection_changed' : is triggered when the selection of mimics.Object or derived class object in current opened Project is changed. Callback function has 1 argument - mimics.Object or derived class object which selection was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'obj_changed' : is triggered when any mimics.Object or derived class object in current opened Project is changed. This notification is general and is triggered whenever any child notification is triggered : 'obj_geometry_changed', 'obj_relation_changed', 'obj_label_changed', 'obj_metadata_changed', 'obj_visual_state_changed'. Not triggered when object is deleted, use 'obj_deleted' notification_name instead. Callback function has 1 argument - mimics.Object or derived class object which was changed (exact type depends of the changed object type: mimics.Object or derived type). Supports only 'after' notification_type. For detailed example see the 'Example' section below.
        * 'timer' : is triggered every time interval defined in 'timeout' (in milliseconds). In case 'singleshot' parameter is True - event is triggered only once after time defined in 'timeout' (in milliseconds) passes. Callback function has no arguments. Supports both 'before' and 'after' notification_type. For detailed example see the 'Example' section below.
    
    :param notification_name: Name of the notification. Check function description to see all supported notification names.
    :type notification_name: str
    :param callback: Callback function that will be called when notification is triggered. Check function description or 'Example' section to see required signature for callback function for a specific notification.
    :type callback: collections.abc.Callable
    :param *: 
    :type *: None
    :param notification_type: (optional) Defines whether callback should be triggered before or after the operation or event.
    :type notification_type: str
    :param timeout: (optional) Timeout interval of the timer event in milliseconds. Applicable only to the 'timer' notification_name, otherwise ignored.
    :type timeout: int
    :param singleshot: (optional) Defines repetition of the timer event. If True then defined callback will triggred only once. Applicable only to the 'timer' notification_name, otherwise ignored.
    :type singleshot: bool
    :param is_enabled_if_modal_gui: (optional) By default value (or False), in order to implicit support for hard to diagnose situations, the timers notifications are put on hold while modal GUI is active. This can be overridden by providing True value for this parameter, if so, extra attention is needed while modifying data is the callback.
    :type is_enabled_if_modal_gui: bool
    
    :returns: RAII object that removes the subscription when deleted. It should be stored in a variable.
    :rtype: mimics.events.Subscription
    
    :exceptions: ValueError (reason(s): ["Notification '<notification_name>' does not exists. Please provide a valid notification name.", "Notification '<notification_name>' is not supported for the subscription type 'before/after'.", "'timeout' parameter is required while setting a 'timer' notification."]), TypeError (reason(s): ["'timeout' parameter is expected only for a 'timer' notification_name. None is expected.", "'singleshot' parameter is expected only for a 'timer' notification_name. None is expected.", "'is_enabled_if_modal_gui' parameter is expected only for a 'timer' notification_name. None is expected.", "Unsupported notification type '<notification_type>' is provided for notification '<notification_name>'."])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	def on_app_closed():
    	    try:
    	        print("Application closed")
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	
    	
    	sub_app_closed = mimics.events.subscribe("app_closed", on_app_closed)
    	
    	
    	#Example 2
    	# Currently it is impossible to interrupt project opening via notification callback
    	def on_before_doc_opened(project_path):
    	    try:
    	        print("Project is about to be opened: {}".format(project_path))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	
    	
    	sub_before_doc_opened = mimics.events.subscribe("doc_opened", on_before_doc_opened, notification_type="before")
    	
    	
    	def on_after_doc_opened(project_path):
    	    try:
    	        print("Project is opened: {}".format(project_path))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	
    	
    	sub_after_doc_opened = mimics.events.subscribe("doc_opened", on_after_doc_opened, notification_type="after")
    	
    	
    	# Currently it is impossible to interrupt project closing via notification callback
    	def on_before_doc_closed():
    	    try:
    	        print("Project is about to be closed")
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	
    	
    	sub_before_doc_closed = mimics.events.subscribe("doc_closed", on_before_doc_closed, notification_type="before")
    	
    	
    	def on_after_doc_closed():
    	    try:
    	        print("Project is closed")
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	
    	
    	sub_after_doc_closed = mimics.events.subscribe("doc_closed", on_after_doc_closed, notification_type="after")
    	
    	
    	def on_before_doc_saving():
    	    try:
    	        print("Project is about to be saved")
    	    except BaseException as ex:
    	        print(f"Exception occurred: {format(ex)}")
    	
    	
    	sub_before_doc_saving = mimics.events.subscribe("doc_saved", on_before_doc_saving, notification_type="before")
    	
    	
    	def on_after_doc_saved():
    	    try:
    	        print("Project has been saved")
    	    except BaseException as ex:
    	        print(f"Exception occurred: {format(ex)}")
    	
    	
    	sub_after_doc_saved = mimics.events.subscribe("doc_saved", on_after_doc_saved, notification_type="after")
    	
    	
    	#Example 3
    	def on_pm_tab_closed(index):
    	    try:
    	        print("Pm tab closed: {}".format(index))
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	    return index
    	
    	
    	sub_pm_tab_closed = mimics.events.subscribe("pm_tab_closed", on_pm_tab_closed)
    	
    	
    	def on_pm_tab_docked(index):
    	    try:
    	        print("Pm tab docked: {}".format(index))
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	    return index
    	
    	
    	sub_pm_tab_docked = mimics.events.subscribe("pm_tab_docked", on_pm_tab_docked)
    	
    	
    	def on_pm_tab_undocked(index):
    	    try:
    	        print("Pm tab undocked: {}".format(index))
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	    return index
    	
    	
    	sub_pm_tab_undocked = mimics.events.subscribe("pm_tab_undocked", on_pm_tab_undocked)
    	
    	
    	#Example 4
    	import mimics
    	
    	
    	def on_obj_added(obj: mimics.Object):
    	    try:
    	        print("Object added: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_added = mimics.events.subscribe("obj_added", on_obj_added)
    	
    	
    	def on_obj_deleted(obj: mimics.Object):
    	    try:
    	        print("Object deleted: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_deleted = mimics.events.subscribe("obj_deleted", on_obj_deleted)
    	
    	
    	def on_obj_geometry_changed(obj: mimics.Object):
    	    try:
    	        print("Object geometry changed: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_geometry_changed = mimics.events.subscribe("obj_geometry_changed", on_obj_geometry_changed)
    	
    	
    	def on_obj_relation_changed(obj: mimics.Object):
    	    try:
    	        print("Object relation changed: {}:{}. ".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_relation_changed = mimics.events.subscribe("obj_relation_changed", on_obj_relation_changed)
    	
    	
    	def on_obj_label_changed(obj: mimics.Object):
    	    try:
    	        print("Object name changed: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_label_changed = mimics.events.subscribe("obj_label_changed", on_obj_label_changed)
    	
    	
    	def on_obj_metadata_changed(obj: mimics.Object):
    	    try:
    	        print("Object metadata changed: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_metadata_changed = mimics.events.subscribe("obj_metadata_changed", on_obj_metadata_changed)
    	
    	
    	def on_obj_visual_state_changed(obj):
    	    try:
    	        print("Object visibility changed: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_visual_state_changed = mimics.events.subscribe("obj_visual_state_changed", on_obj_visual_state_changed)
    	
    	
    	def on_obj_selection_changed(obj):
    	    try:
    	        print("Object selection changed: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_selection_changed = mimics.events.subscribe("obj_selection_changed", on_obj_selection_changed)
    	
    	
    	def on_obj_changed(obj: mimics.Object):
    	    try:
    	        print("Object modified: {}:{}".format(type(obj), obj.name))
    	    except BaseException as ex:
    	        print("Exception occurred: {}".format(ex))
    	    return obj.name
    	
    	
    	sub_obj_changed = mimics.events.subscribe("obj_changed", on_obj_changed)
    	
    	
    	#Example 5
    	def on_timer():
    	    try:
    	        print("Timer tick")
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	
    	
    	sub_timer = mimics.events.subscribe("timer", on_timer, timeout=3000)
    	
    	
    	def on_timer_singleshot():
    	    try:
    	        print("Timer singleshot")
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	
    	
    	sub_timer_singleshot = mimics.events.subscribe("timer", on_timer_singleshot, timeout=5000, singleshot=True)
    	
    	
    	#Example 6
    	def on_timer():
    	    try:
    	        print("Timer tick")
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	
    	sub_timer = mimics.events.subscribe("timer", on_timer, timeout=3000)
    	print("The subscriptiom is active: {}".format(sub_timer.is_active()))
    	
    	sub_timer.unsubscribe()
    	print("The subscriptiom is active: {}".format(sub_timer.is_active()))
    	
    	
    	def on_timer_singleshot():
    	    try:
    	        print("Timer singleshot")
    	    except BaseException as ex:
    	        print("Exception occured: {}".format(ex))
    	
    	sub_timer_singleshot = mimics.events.subscribe("timer", on_timer_singleshot, timeout=1000, singleshot=True)
    	print("The singleshot subscriptiom is active: {}".format(sub_timer_singleshot.is_active()))
    	while sub_timer_singleshot.is_active():
    	    mimics.update_gui()  # this is too let timers notifications to be processed
    	print("The singleshot timer has been triggered, thus the subscription is not active anymore automatically (is_active() = {})".format(sub_timer_singleshot.is_active()))

    """
    pass


