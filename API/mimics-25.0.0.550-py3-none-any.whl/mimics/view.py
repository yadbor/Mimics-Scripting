import typing
import mimics


def enable_overlay():
    """
    Enables overlay.
    """
    pass


def disable_overlay():
    """
    Disables overlay.
    """
    pass


def is_overlay_enabled():
    """
    Returns if overlay is enabled.
    
    :returns: boolean
    :rtype: bool
    """
    pass


class PanoramicReslice(mimics.Object):
    """
    Panoramic reslice view that visualizes image data along a curve.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def cross_section_length(self):
        """
        The cross-sectional length determines the length of the images in the plane perpendicular to the panoramic curve. The value should not be less than the pixel size value and should not exceed the bigger from the images' dimensions. None is used for "Optional" cross section length. "Optional" value calculated by application automatically.
        
        :type: typing.Union[typing.SupportsFloat, NoneType]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Passed value is not in allowed range determined by images pixel size and dimensions.'])
        """
        pass
    
    @cross_section_length.setter
    def cross_section_length(self, value):
        """
    
        """
        pass

    @property
    def cross_section_height(self):
        """
        The cross-sectional height determines the height of the images in the plane perpendicular to the panoramic curve. The value should not be less than the pixel size value and should not exceed the images height. None is used for the height of images
        
        :type: typing.Union[typing.SupportsFloat, NoneType]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Passed value is not in allowed range determined by images pixel size and dimensions.'])
        """
        pass
    
    @cross_section_height.setter
    def cross_section_height(self, value):
        """
    
        """
        pass

    @property
    def points(self):
        """
        Points defined by the user, that are used as an input data to create a panoramic curve.
        
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Not enough points to build a spline (len(points) < 2).'])
        """
        pass
    
    @points.setter
    def points(self, value):
        """
    
        """
        pass

    @property
    def geometry_points(self):
        """
        A set of points creating a smooth panoramic curve passing through the input points indicated by user.
        
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: True
    
        """
        pass


def restore_view():
    """
    Returns the view to the default viewport settings of the user.
    """
    pass


class ViewToImageTransform(object):
    """

    """
    def transform(self, point):
        """
        Transforms the input 3d point to a point on the image.
        
        :param point: Point to be transformed.
        :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :returns: 2D point.
        :rtype: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat]
        """
        pass




def clear_log():
    """
    Clears the log.
    """
    pass


def create_camera_settings():
    """
    Creates default camera settings, which can be customized and set to the camera.
    
    :returns: Camera settings
    :rtype: mimics.view.CameraSettings
    """
    pass


def export_simulated_fluoroscopy(filename, fluoroscopy_object, colored_objects, width=800, height=800, image_type='autodetect'):
    """
    Exports fluoroscopy simulated image to file. Can simulate defined objects in color
    
    :param filename: path to result file, file extension will be used to detect output format if not explicitely specified by file_type.
    :type filename: str
    :param fluoroscopy_object: Pre-configured object used for simulation
    :type fluoroscopy_object: mimics.view.Fluoroscopy
    :param colored_objects: Objects, that shall be simulated in color
    :type colored_objects: typing.Iterable[mimics.Object]
    :param width: (optional) width of result image, pixels. Value range: [1,65535]
    :type width: int
    :param height: (optional) height of result image, pixels. Value range: [1,65535]
    :type height: int
    :param image_type: (optional) format of output file, preferred over filename extension
    :type image_type: str
    
    :exceptions: RuntimeError (reason(s): ['failed to simulate to file. Might be because of I/O error or incompatible output format']), ValueError (reason(s): ['incompatible output format'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	path = r"C:\MedData\my_file.bmp"
    	objs = [p for p in mimics.data.points]
    	f = mimics.view.create_fluoroscopy_view_default()
    	f.simulate(objects_contrast = [])
    	mimics.view.export_simulated_fluoroscopy(filename=path, fluoroscopy_object=f, colored_objects=objs)

    """
    pass


def create_resliced_view_with_plane(plane):
    """
    Reslices the stack of images along a specified plane. As a result, three orthogonal views are obtained with original view parallel to the selected plane.
    
    :param plane: The reference plane.
    :type plane: mimics.analyze.Plane
    
    :returns: Reslice plane.
    :rtype: mimics.view.Reslice
    
    
    :example:
    .. code-block:: python
    
    	 
    	pln = mimics.data.planes[0]
    	fl = mimics.view.create_resliced_view_with_plane(plane=pln)

    """
    pass


def maximize_view(view_type):
    """
    Maximizes defined view to fullscreen.
    
    :param view_type: View that should be maximized.
    :type view_type: mimics.view.View
    
    :exceptions: ValueError (reason(s): ['Invalid view.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	v = mimics.data.views
    	mimics.view.maximize_view(v[0])

    """
    pass


class Reslice(mimics.Object):
    """
    Reslice view visualizes the images in a selected direction.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def rotate_xyz(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: False
    
        """
        pass
    
    @rotate_xyz.setter
    def rotate_xyz(self, value):
        """
    
        """
        pass

    @property
    def width(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Width should not be in a specific range for the current Mimics project.']), RuntimeError (reason(s): ["Can't set custom width to Reslice object if 'auto_resize_to_imagedata' attribute is True. To set the width please first change 'auto_resize_to_imagedata' to False"])
        """
        pass
    
    @width.setter
    def width(self, value):
        """
    
        """
        pass

    @property
    def height(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Height should not be in a specific range for the current Mimics project']), RuntimeError (reason(s): ["Can't set custom height to Reslice object if 'auto_resize_to_imagedata' attribute is True. To set the height please first change 'auto_resize_to_imagedata' to False"])
        """
        pass
    
    @height.setter
    def height(self, value):
        """
    
        """
        pass

    @property
    def reslice_step(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @reslice_step.setter
    def reslice_step(self, value):
        """
    
        """
        pass

    @property
    def origin(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def normal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def auto_resize_to_imagedata(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @auto_resize_to_imagedata.setter
    def auto_resize_to_imagedata(self, value):
        """
    
        """
        pass


def show_reference_planes():
    """
    Turns on the visualization of the reference planes.
    """
    pass


def create_fluoroscopy_view_with_reslice_plane(plane):
    """
    Creates a fluoroscopy object. Reslice plane is required.
    
    :param plane: A plane to generate a Fluoroscopy object from it.
    :type plane: mimics.view.Reslice
    
    :returns: A fluoroscopy object.
    :rtype: mimics.view.Fluoroscopy
    
    
    :example:
    .. code-block:: python
    
    	 
    	pln = mimics.data.reslice_planes[0]
    	fl = mimics.view.create_fluoroscopy_view_with_reslice_plane(plane=pln)

    """
    pass


def is_mask_3d_preview_enabled():
    """
    Returns the state of the mask 3D preview.
    
    :returns: State of the mask 3D preview.
    :rtype: bool
    """
    pass


def navigate_to(point):
    """
    Navigates to a certain position in the image dataset by defining a point. All images are immediately updated to show the defined point.
    
    :param point: Coordinates of the point to which navigation should be done.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.points[0]
    	mimics.view.navigate_to(p)

    """
    pass


def hide_reference_planes():
    """
    Turns off the visualization of the reference planes.
    """
    pass


def enable_transparency():
    """
    Turns on the transparency of the Parts.
    """
    pass


def show_log_panel():
    """
    Shows the log panel.
    """
    pass


def get_log():
    """
    Get entire user log text.
    
    :returns: User log text
    :rtype: str
    """
    pass


def create_view_to_image_transform(view, camera_settings=None, image_width=None, image_height=None):
    """
    Calculates the transformation of a view from the patient's coordinate system to the screen coordinate system (image pixels). If image_width or image_height are None then width and height are taken as screen resolution size. The transformation can be used to transform a point from the patient's coordinate system to the screen (image) coordinate system.
    
    :param view: View for transform calculation.
    :type view: mimics.view.View
    :param camera_settings: (optional) Camera settings for transform calculation.
    :type camera_settings: mimics.view.CameraSettings
    :param image_width: (optional) View width.
    :type image_width: int
    :param image_height: (optional) View height.
    :type image_height: int
    
    :returns: Transformation of a view from the patient's coordinate system to the image pixel coordinate system.
    :rtype: mimics.view.ViewToImageTransform
    
    :exceptions: RuntimeError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	pnt = mimics.indicate_coordinate()
    	v = mimics.data.views.find("3D")
    	if v:
    	    tr = mimics.view.create_view_to_image_transform(v)
    	    tr_pnt = tr.transform(pnt)
    	    print("Coordinates of the clicked point:",pnt)
    	    print("Coordinates of the transformed point:",tr_pnt)

    """
    pass


def _set_layout(layout_name, images, reslices):
    """
    Changes layout. If the defined value is equal to the current layout - it will be recalculated
    
    :param layout_name: Name of the layout.
    :type layout_name: str
    :param images: Images. They depends on the layout
    :type images: typing.Iterable[mimics.Object]
    :param reslices: Reslices. They depends on the layout
    :type reslices: typing.Iterable[mimics.Object]
    
    :exceptions: ValueError (reason(s): ['Unsupported layout name', 'Invalid number of Images', 'Invalid number of Reslices', 'Invalid Image', 'Invalid Slicer'])
    """
    pass


def set_layout(layout_name, images=None, reslices=None):
    """
    Changes the layout. If the defined value is equal to the current layout - it will be recalculated.
    
    :param layout_name: Name of the layout. Attributes of mimics.Layouts can be passed as the layout_name argument, e.g. mimics.Layouts.Layout3D
    :type layout_name: str
    :param *: 
    :type *: None
    :param images: (optional) Images. They depends on the layout
    :type images: typing.Union[mimics.Object, typing.Iterable[mimics.Object], None]
    :param reslices: (optional) Reslices. They depends on the layout
    :type reslices: typing.Union[mimics.Object, typing.Iterable[mimics.Object], None]
    
    :exceptions: ValueError (reason(s): ['Unsupported layout name', 'Invalid number of Images', 'Invalid number of Reslices', 'Invalid Image', 'Invalid Slicer'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	l = mimics.Layouts.Layout3D
    	im = images=mimics.data.images[0]
    	mimics.view.set_layout(layout_name=l, images=im)

    """
    pass


class Camera(object):
    """
    Camera object allows to operate with camera alignment, rotation and zooming. It can be received via mimics.views.View object.
    
    Camera contains properties that defines current camera position (See mimics.views.CameraSetting object for more details, it can be obtained via get_settings function call). All properties can be modified to change the Camera's position.
    """
    def get_settings(self):
        """
        Allows to access current camera settings and modify them. Modifying returned object does not lead to mimics.views.View object change. Does not work in background mode, to get settings without UI, please use mimics.view.create_camera_settings.
        
        
        
        :returns: Camera settings
        :rtype: mimics.view.CameraSettings
        """
        pass

    def set_settings(self, camera_settings):
        """
        Applies passed settings to the camera that leads to mimics.views.View object change. Note that passed values of view_center and zoom_point will be projected to the plane of the window, which is defined by up_vector and view_vector properties. Due to that fact, the final values of view_center and zoom_point will not necessarily match original variables from CameraSettings.
        
        :param camera_settings: Camera settings to be applied.
        :type camera_settings: mimics.view.CameraSettings
        
        :exceptions: ValueError (reason(s): ['Up vector must be orthogonal to the view vector.', 'View vector for 2D views cannot be changed.'])
        """
        pass

    def zoom_to_bounding_box(self, bounding_box):
        """
        Zooms to the defined bounding box.
        
        :param bounding_box: Bounding box
        :type bounding_box: mimics.BoundingBox3d
        
        :exceptions: ValueError (reason(s): ['Bounding box is not valid. Provide valid bounding box.'])
        """
        pass

    def rotate(self, angles):
        """
        Rotates the camera according to the defined angles.
        
        :param angles: Rotation angles.
        :type angles: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        """
        pass

    @property
    def view_center(self):
        """
        A 3D point that is displayed at the center of the window. Note, that after changing this property, it will not necessarily match the passed value due to the fact that it is projected to the plane of the window.
        
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @view_center.setter
    def view_center(self, value):
        """
    
        """
        pass

    @property
    def up_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @up_vector.setter
    def up_vector(self, value):
        """
    
        """
        pass

    @property
    def view_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
        :exceptions: ValueError (reason(s): ['View vector for 2D views cannot be changed.'])
        """
        pass
    
    @view_vector.setter
    def view_vector(self, value):
        """
    
        """
        pass

    @property
    def zoom_factor(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Zoom factor must be greater than 0.'])
        """
        pass
    
    @zoom_factor.setter
    def zoom_factor(self, value):
        """
    
        """
        pass

    @property
    def zoom_point(self):
        """
        A 3D point that preserves its position on the window after zooming. Note, that after changing this property, it will not necessarily match the passed value due to the fact that it is projected to the plane of the window.
        
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @zoom_point.setter
    def zoom_point(self, value):
        """
    
        """
        pass


class Fluoroscopy(mimics.Object):
    """
    Fluoroscopy view visualizes the region of interest in different view angles.
    """
    def _clear_settings(self):
        """
        removes all simulated objects and their parameters
        
    
        """
        pass

    def _export(self, filename, colored_objects, image_width=600, image_height=600, image_type='autodetect'):
        """
        performs simulation to file of pre-configured simulation object
        
        :param filename: path to result file, file extension will be used to detect output format if not explicitely specified by file_type
        :type filename: str
        :param colored_objects: objects to be simulated in color. order is important
        :type colored_objects: typing.Iterable[mimics.Object]
        :param image_width: (optional) width of result image, pixels. Value range: [1,65535]
        :type image_width: int
        :param image_height: (optional) height of result image, pixels. Value range: [1,65535]
        :type image_height: int
        :param image_type: (optional) format of output file, preferred over filename extension
        :type image_type: str
        """
        pass

    def _simulate_object(self, object, contrast):
        """
        sets object simulation params
        
        :param object: object to be simulated
        :type object: mimics.Object
        :param contrast: object simulation contrast
        :type contrast: typing.SupportsFloat
        """
        pass

    @property
    def lao_rao_angle(self):
        """
        The LAO & RAO angle. Positive values correspond to RAO angle, negative values correspond to LAO angle.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @lao_rao_angle.setter
    def lao_rao_angle(self, value):
        """
    
        """
        pass

    @property
    def cran_caud_angle(self):
        """
        The Cranial & Caudal angle. Positive values correspond to Cranial angle, negative values correspond to Caudal angle.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @cran_caud_angle.setter
    def cran_caud_angle(self, value):
        """
    
        """
        pass

    @property
    def simulation_mode(self):
        """
        Fluoroscopy view mode: to be applied on activation or immediately
        
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @simulation_mode.setter
    def simulation_mode(self, value):
        """
    
        """
        pass

    @property
    def distance_source_to_detector(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @distance_source_to_detector.setter
    def distance_source_to_detector(self, value):
        """
    
        """
        pass

    @property
    def distance_source_to_patient(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @distance_source_to_patient.setter
    def distance_source_to_patient(self, value):
        """
    
        """
        pass

    @property
    def attenuation_coefficient(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @attenuation_coefficient.setter
    def attenuation_coefficient(self, value):
        """
    
        """
        pass

    @property
    def normalize_contrast(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @normalize_contrast.setter
    def normalize_contrast(self, value):
        """
    
        """
        pass


def is_maximized(view):
    """
    Returns true if the defined view is maximized to full screen or false otherwise.
    
    :param view: View that should be checked.
    :type view: mimics.view.View
    
    :exceptions: ValueError (reason(s): ['Invalid view.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	v = mimics.data.views.find("Axial")
    	if v:
    	    maximized = mimics.view.is_maximized(v)
    	    print(maximized)

    """
    pass


def disable_transparency():
    """
    Turns off the transparency of the Parts.
    """
    pass


def hide_log_panel():
    """
    Hides the log panel.
    """
    pass


class CameraSettings(object):
    """
    CameraSettings allows to operate with camera alignment, rotation and zooming. It can be modified via up_vector, view_vector, view_center and zoom_factor.
    
    Properties:
        * up_vector and view_vector defines the rotation of the View. up_vector is aligned with Y-axis(top to bottom) of the window. view_vector is an eye vector, this vector is orthogonal to the screen and directed from the user. If passed vectors are not orthogonal, up_vector is set as orthogonal to view_vector in the plane determined by up and view vectors
        * view_center allows to set camera center - it is a 3D point that is moved to the center of the window.
        * zoom_factor is a ratio to default window zooming. Default zooming is selected as a bounding box of all visible objects inscribed in the window. Default zoom factor equals 1.
        * zoom_point is a 3D point that preserves its position on the window after zooming.
    """
    def zoom_to_bounding_box(self, bbox, zoom_factor=1.0, zoom_center=None):
        """
        Zooming to the required zoom point in the required bounding box with the required zoom factor. This method updates view_center property according to the bounding box center.
        
        :param bbox: Bounding box.
        :type bbox: mimics.BoundingBox3d
        :param zoom_factor: (optional) Zoom factor with regard to bounding box. If the value is '1' bounding box is fully inscribed into view. 
        :type zoom_factor: typing.SupportsFloat
        :param zoom_center: (optional) Point to zoom into.
        :type zoom_center: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :exceptions: ValueError (reason(s): ['Bounding box is not valid. Pass point and three vectors.', 'Bounding box is not valid. Provide valid bounding box.', 'Zoom factor must be greater then 0.'])
        """
        pass

    @property
    def view_center(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @view_center.setter
    def view_center(self, value):
        """
    
        """
        pass

    @property
    def up_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @up_vector.setter
    def up_vector(self, value):
        """
    
        """
        pass

    @property
    def view_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @view_vector.setter
    def view_vector(self, value):
        """
    
        """
        pass

    @property
    def zoom_factor(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Zoom factor must be greater than 0.'])
        """
        pass
    
    @zoom_factor.setter
    def zoom_factor(self, value):
        """
    
        """
        pass

    @property
    def zoom_point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @zoom_point.setter
    def zoom_point(self, value):
        """
    
        """
        pass


def create_resliced_view_default():
    """
    Creates a default MPR.
    
    :returns: Reslice plane.
    :rtype: mimics.view.Reslice
    
    
    :example:
    .. code-block:: python
    
    	 
    	fl = mimics.view.create_resliced_view_default()

    """
    pass


class View(object):
    """
    An object describing view in Mimics's layouts. (Coronal, Axial, Sagittal, 3D etc.)
    """
    def get_camera(self):
        """
        Returns mimics.view.View object that allows to operate with camera alignment.
        
        
        
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    def get_widget(self):
        """
        Returns an PyQt5' QWidget (or a QWidget-derived class) instance of Qt widget (window) that represents a view.
        
        If your script is going to use the instance a lot or too often, it is recommended 
        
        to store the instance at the Python side to be re-used within your function. However, it is highly not recommended to store this 
        
        QWidget object for long time, because views are highly mutable objects (e.g. they can be created/deleted when layout is change) and that can result 
        
        in the QWidget to be deleted. Note, that referencing to a delete QWidget will results in Python exception (see documentation of the PtQt and sip).
        
        
        
        :returns: instance of PyQt5.QtWidgets.QWidget
        :rtype: mimics.gui.PyQt5.QtWidgets.QWidget
        
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.']), ImportError (reason(s): ['PyQt library is either not installed, mis-configured or its version mis-matches version of Qt in the host application.'])
        """
        pass

    def is_under_mouse(self):
        """
        Returns true the mouse cursor is currently within the given view
        
        
        
        :returns: true if mouse cursor is within the given view
        :rtype: bool
        
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    def __eq__(self, operand):
        """
        :param operand: 
        :type operand: mimics.view.View
        """
        pass

    @property
    def width(self):
        """
        :type: <class 'int'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    @property
    def height(self):
        """
        :type: <class 'int'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    @property
    def type(self):
        """
        :type: <class 'str'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    @property
    def image_data(self):
        """
        :type: <class 'mimics.ImageData'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass

    @property
    def base_object(self):
        """
        :type: typing.Union[mimics.Object, NoneType]
        :read-only: True
        :exceptions: ValueError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
        """
        pass


def get_camera(view):
    """
    Gets current camera of a selected view.
    
    :param view: View to get the camera for.
    :type view: mimics.view.View
    
    :returns: Camera of a selected view.
    :rtype: mimics.view.Camera
    
    :exceptions: RuntimeError (reason(s): ['The given view is not valid anymore. Probably it was removed due to layout recalculation.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	views = mimics.data.views
    	cmr = mimics.view.get_camera(views[0])
    	print(dir(cmr))

    """
    pass


def is_transparency_enabled():
    """
    Returns the state of the transparency of the Parts..
    
    :returns: State of the transparency of the Parts.
    :rtype: bool
    """
    pass


def create_panoramic_reslice(points, cross_section_length=None, cross_section_height=None):
    """
    Creates reslice object along a specified spline (panoramic curve).
    
    :param points: The source points.
    :type points: typing.Sequence[typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]]
    :param cross_section_length: (optional) The cross-sectional length determines the length of the images in the plane perpendicular to the curve. The value should not be less than the pixel size value and should not exceed the bigger from the images' dimensions. By default - None. None represents "Optional" cross section length (value calculated by application automatically).
    :type cross_section_length: typing.Optional[typing.SupportsFloat]
    :param cross_section_height: (optional) The cross-sectional height determines the height of the images in the plane perpendicular to the panoramic curve. The value should not be less than the pixel size value and should not exceed the images height. By default - None. None is used for the height of images
    :type cross_section_height: typing.Optional[typing.SupportsFloat]
    
    :returns: Panoramic curve.
    :rtype: mimics.view.PanoramicReslice
    
    :exceptions: ValueError (reason(s): ['Cross section length should be in range %1-%2', 'Cross section height should be in range %1-%2', 'At least two points must be indicated'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# given that we have at least one spline created
    	spline = mimics.data.splines[0]
    	# create panoramic with default ("Optimal") cross_section_length
    	panoramic = mimics.view.create_panoramic_reslice(spline)
    	
    	# create panoramic with default ("Optimal") cross_section_length
    	points = spline.points
    	panoramic_from_points = mimics.view.create_panoramic_reslice(points)
    	
    	# second parameter allows to set explicit cross_section_length
    	panoramic_with_custom_cross_section_length = mimics.view.create_panoramic_reslice(spline, 20)

    """
    pass


def create_fluoroscopy_view_default():
    """
    Creates a Fluoroscopy object. Default (axial view) plane will be used.
    
    :returns: A Fluoroscopy object.
    :rtype: mimics.view.Fluoroscopy
    """
    pass


def create_fluoroscopy_view_with_analyze_plane(plane):
    """
    Creates a Fluoroscopy object. Analysis plane is required.
    
    :param plane: A plane to generate a Fluoroscopy object from it.
    :type plane: mimics.analyze.Plane
    
    :returns: A Fluoroscopy object.
    :rtype: mimics.view.Fluoroscopy
    
    
    :example:
    .. code-block:: python
    
    	 
    	pln = mimics.data.planes[0]
    	fl = mimics.view.create_fluoroscopy_view_with_analyze_plane(plane=pln)

    """
    pass


def disable_mask_3d_preview():
    """
    Disables the mask 3D preview.
    """
    pass


def enable_mask_3d_preview():
    """
    Enables the mask 3D preview.
    """
    pass


def set_contrast(lower_point=None, upper_point=None):
    """
    Changes the contrast.
    
    :param lower_point: (optional) Lower contrast point.
    :type lower_point: typing.Tuple[typing.SupportsInt, typing.SupportsFloat]
    :param upper_point: (optional) Upper contrast point.
    :type upper_point: typing.Tuple[typing.SupportsInt, typing.SupportsFloat]
    
    :exceptions: ValueError (reason(s): ['Lower contrast point should be in range from 0 to 1', 'Upper contrast point should be in range from 0 to 1', 'Upper contrast point should be higher then lower contrast point', 'Lower contrast point should be in range from 0 to maximum gray value of the project', 'Upper contrast point should be in range from 0 to maximum gray value of the project', 'Upper contrast point should be higher then lower contrast point'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.view.set_contrast((20,0.2),(230,0.8))
    	mimics.view.set_contrast(upper_point=(250,1))
    	mimics.view.set_contrast(lower_point=(128,0))
    	mimics.view.set_contrast((0,0),(255,1))

    """
    pass


