import typing
import mimics


def get_user_log_file_path():
    """
    Returns the path to the user log file for the current session of Mimics. The returned path can be changed by the command line parameter "-save_log <filename.txt>".  The log file is written in (UTF-16 Unicode encoding) with the BOM marker at the start of the file.
    
    Note about memory buffering: for performance reasons, the application writes log messages by groups. This means that, at a given moment of time, if one reads a log's file content, he/she cannot be sure if the last records were already added to the file or they are still being buffered in memory.
    To ensure that the last records are written to the log file, the script can/must invoke mimics.logging.flush().  Despite, setting "Extending diagnostic" = On  also makes sure that buffering latest log records is not activated and that all the records are always in the log file (see Preferences/Log page or command switch "-logging_level debug"), it is not recommended to count/use on this approach in production because keeping "Extending diagnostic" always ON may degrade the performance.
    
    See also: mimics.logging.flush().
    
    :returns: file path to the user log file path for the current session
    :rtype: str
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	# This example demonstrates how one can reliably read
    	# a certain (controlled as number of chars to read) amount of
    	# the most fresh (tail) user log records.
    	from typing import Sequence
    	import logging
    	import os
    	import mimics
    	
    	
    	def read_tail_of_user_log(tail_size_in_char: int = 512) -> Sequence[str]:
    	    # Before reading last records of the log file, it is mandatory
    	    # to make sure that all the memory buffered content are flushed to
    	    # the file system.
    	    mimics.logging.flush()
    	
    	    log_path = mimics.logging.get_user_log_file_path()
    	    size = os.stat(log_path).st_size
    	    pos = max(size - tail_size_in_char * 2, 0)  # if a file is smaller than tail_size_in_char UTF-16 chars
    	    with open(log_path, "rb") as file:  # open as binary to be able to seek reliably
    	        file.seek(pos, os.SEEK_SET)
    	        log_bytes: bytes = file.read(size - pos)
    	        if pos == 0:
    	            if len(log_bytes) >= 2 and log_bytes[0] == 0xFF and log_bytes[1] == 0xFE:  # the BOM marker
    	                log_bytes = log_bytes[2:]
    	
    	    # ATTENTION: mimics log files are in 16 bits Unicode format
    	    return tuple(line for line in log_bytes.decode("UTF-16").splitlines() if line.strip())
    	
    	
    	# write the  message to the log -> so we will be able to find it later
    	MSG = "Some text message to write and to find later."
    	mimics.logging.log_user_message(logging.INFO, MSG)
    	
    	print(f"Location of the user log file: '{mimics.logging.get_user_log_file_path()}' and printing tail of it.")
    	
    	found_pos = -1
    	for i, ln in enumerate(read_tail_of_user_log()):
    	    print(f" - {i}: {ln}")
    	    if MSG in ln:
    	        found_pos = i
    	
    	print(f"The MSG is found at {found_pos}th line of the tail.")
    	
    	
    	#Example 2
    	# This example demonstrates how one can reliably read
    	# entire content of the user log file.
    	from typing import Sequence
    	import logging
    	import os
    	import mimics
    	
    	
    	def read_user_log() -> Sequence[str]:
    	    # Before reading last records of the log file, it is mandatory
    	    # to make sure that all the memory buffered content are flushed to
    	    # the file system.
    	    mimics.logging.flush()
    	
    	    with open(mimics.logging.get_user_log_file_path(), "rb") as file:
    	        content: bytes = file.read()
    	        if len(content) >= 2 and content[0] == 0xFF and content[1] == 0xFE:  # the BOM marker
    	            content = content[2:]
    	        return tuple(line for line in content.decode("UTF-16").splitlines() if line.strip())
    	
    	
    	mimics.logging.log_user_message(logging.INFO, "Some text message to write.")
    	
    	print(f"Location of the system log file: '{mimics.logging.get_user_log_file_path()}' and printing all records:")
    	for i, ln in enumerate(read_user_log()):
    	    print(f" - {i}: {ln}")

    """
    pass


def get_system_log_file_path():
    """
    Returns the path to the system log file for the current session of Mimics. The returned path can be changed by the command line parameter "-save_system_log <filename.txt>".  The log file is written in (UTF-16 Unicode encoding) with the BOM marker at the start of the file.
    
    Note about memory buffering: for performance reasons, the application writes log messages by groups. This means that, at a given moment of time, if one reads a log's file content, he/she cannot be sure if the last records were already added to the file or they are still being buffered in memory.
    To ensure that the last records are written to the log file, the script can/must invoke mimics.logging.flush().  Despite, setting "Extending diagnostic" = On  also makes sure that buffering latest log records is not activated and that all the records are always in the log file (see Preferences/Log page or command switch "-logging_level debug"), it is not recommended to count/use on this approach in production because keeping "Extending diagnostic" always ON may degrade the performance.
    
    See also: mimics.logging.flush().
    
    :returns: path to the system log file path for the current session
    :rtype: str
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	# This example demonstrates how one can reliably read
    	# a certain (controlled as number of chars to read) amount of
    	# the most fresh (tail) system log records
    	from typing import Sequence
    	import logging
    	import os
    	import mimics
    	
    	
    	def read_tail_of_system_log(tail_size_in_char: int = 512) -> Sequence[str]:
    	    # Before reading last records of the log file, it is mandatory
    	    # to make sure that all the memory buffered content are flushed to
    	    # the file system.
    	    mimics.logging.flush()
    	
    	    log_path = mimics.logging.get_system_log_file_path()
    	    size = os.stat(log_path).st_size
    	    pos = max(size - tail_size_in_char * 2, 0)  # if a file is smaller than tail_size_in_char UTF-16 chars
    	    with open(log_path, "rb") as file:  # open as binary to be able to seek reliably
    	        file.seek(pos, os.SEEK_SET)
    	        log_bytes: bytes = file.read(size - pos)
    	        if pos == 0:
    	            if len(log_bytes) >= 2 and log_bytes[0] == 0xFF and log_bytes[1] == 0xFE:  # the BOM marker
    	                log_bytes = log_bytes[2:]
    	
    	
    	    # ATTENTION: mimics log files are in 16 bits Unicode format
    	    return tuple(line for line in log_bytes.decode("UTF-16").splitlines() if line.strip())
    	
    	
    	# write the  message to the log -> so we will be able to find it later
    	MSG = "Some text message to write and to find later."
    	mimics.logging.log_system_message(logging.INFO, MSG)
    	
    	print(f"Location of the system log file: '{mimics.logging.get_system_log_file_path()}' and printing tail of it.")
    	
    	found_pos = -1
    	for i, ln in enumerate(read_tail_of_system_log()):
    	    print(f" - {i}: {ln}")
    	    if MSG in ln:
    	        found_pos = i
    	
    	print(f"The MSG is found at {found_pos}th line of the tail.")
    	
    	
    	#Example 2
    	# This example demonstrates how one can reliably read
    	# entire content of the system log file.
    	from typing import Sequence
    	import logging
    	import os
    	import mimics
    	
    	
    	def read_system_log() -> Sequence[str]:
    	    # Before reading last records of the log file, it is mandatory
    	    # to make sure that all the memory buffered content are flushed to
    	    # the file system.
    	    mimics.logging.flush()
    	
    	    with open(mimics.logging.get_system_log_file_path(), "rb") as file:
    	        content: bytes = file.read()
    	        if len(content) >= 2 and content[0] == 0xFF and content[1] == 0xFE:  # the BOM marker
    	            content = content[2:]
    	        return tuple(line for line in content.decode("UTF-16").splitlines() if line.strip())
    	
    	
    	mimics.logging.log_system_message(logging.INFO, "Some text message to write.")
    	
    	print(f"Location of the system log file: '{mimics.logging.get_system_log_file_path()}' and printing all records:")
    	for i, ln in enumerate(read_system_log()):
    	    print(f" - {i}: {ln}")

    """
    pass


def log_system_message(level, message, kwargs=None):
    """
    Allows to redirect log message to Mimics system log.
    
    It is possible to redirect all messages from any logging.Logger to Mimics system log via logging. Logger instance with name 'mimics.system'. 
    
    :param level: Logging level. The list of possible values (as well as the rules of the application) of the logging level is following conventions of the standard Python module 'logging'. The logging level can be controlled via the preference of the application and/or command line. See respectful documentation.
    :type level: int
    :param message: Message to be logged. For robustness (especially in trouble-shooting and diagnostic scenarios), the application also accepts a value of an arbitrary type (including None, in which case, it is converted to 'None' text).
    :type message: typing.Union[str, typing.Any]
    :param kwargs: (optional) Optional dictionary of key:value pairs which will be logged in the tabular format after the message. Keys and values can be of arbitrary types. The application uses string representation of keys and values to convert them to text before logging. The conversion takes after checking the logging for performance reasons, so, for the 'logging.DEBUG' it is highly recommended to pass the parameters of an event being logged in 'kwargs' parameter (in contrast to formatting them unconditionally into the 'message' argument). For robustness (especially in trouble-shooting and diagnostic scenarios), the application also accepts values of an arbitrary type (including None, in which case, it is ignored).
    :type kwargs: typing.Union[typing.Dict[typing.Any, typing.Any], typing.Any]
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	import logging
    	import os
    	import mimics
    	
    	
    	# print single log message to Mimics system log
    	mimics.logging.log_system_message(level=logging.DEBUG, message="debug message")
    	mimics.logging.log_system_message(level=logging.INFO, message="info message")
    	mimics.logging.log_system_message(level=logging.WARNING, message="warning message")
    	mimics.logging.log_system_message(level=logging.ERROR, message="error message")
    	
    	
    	# print single log message with a table of Windows environment variables
    	mimics.logging.log_system_message(logging.INFO, "Environment:", dict(os.environ))
    	
    	
    	# redirect all log messages from example_logger to Mimics system log
    	ms_logger = logging.getLogger("mimics.system")
    	
    	example_logger = logging.getLogger("example")
    	example_logger.setLevel(logging.DEBUG)
    	example_logger.addHandler(ms_logger)
    	example_logger.debug("test message")
    	example_logger.info("test message")
    	example_logger.warning("test message")
    	example_logger.error("test message")
    	
    	
    	#Example 2
    	import logging
    	import mimics
    	
    	
    	# print single log message with diagnostic information about parameters with which a function is called
    	def parameters_logger(function_to_decorate):
    	    def parameters_logger_impl(*args, **kwargs):
    	        mimics.logging.log_system_message(
    	            logging.INFO,
    	            "Function is called with:",
    	            {
    	                " - name": function_to_decorate.__name__,
    	                " - the positional": args,
    	                " - keyword arguments": kwargs
    	            })
    	        function_to_decorate(*args, **kwargs)
    	    return parameters_logger_impl
    	
    	
    	@parameters_logger
    	def my_function_move_part(obj, action):
    	    import mimics
    	    print("doing something with obj, action: {}, {}".format(obj, action))
    	
    	
    	my_function_move_part(obj="my object", action=7)
    	my_function_move_part("my object", action=None)
    	my_function_move_part(["complex", "object"], True)

    """
    pass


def flush():
    """
    Flushes the log MEMORY buffers to the files on the hard disk. This ensures that all logging records, including those which are currently buffered in memory, will be read if you open one of the log files while a session is still open.
    
    See more explanations in mimics.logging.get_user_log_file_path(), mimics.logging.get_system_log_file_path() documentation.
    
    See also: mimics.logging.get_user_log_file_path(), mimics.logging.get_system_log_file_path().
    
    
    :example:
    .. code-block:: python
    
    	 
    	# This example demonstrates how flush() API affects completeness of
    	# the most fresh (tail) user log records in the log file.
    	from typing import Sequence
    	import logging
    	import os
    	from random import randrange
    	import mimics
    	
    	
    	def read_tail_of_user_log_without_flushing(tail_size_in_char: int = 512) -> Sequence[str]:
    	    log_path = mimics.logging.get_user_log_file_path()
    	    size = os.stat(log_path).st_size
    	    pos = max(size - tail_size_in_char * 2, 0)  # if a file is smaller than tail_size_in_char UTF-16 chars
    	    with open(log_path, "rb") as file:  # open as binary to be able to seek reliably
    	        file.seek(pos, os.SEEK_SET)
    	        # ATTENTION: mimics log files are in 16 bits Unicode format
    	        return tuple(line for line in file.read(size - pos).decode("UTF-16").splitlines() if line.strip())
    	
    	
    	def find_message_in_the_tail_of_log(msg: str) -> bool:
    	    for ln in read_tail_of_user_log_without_flushing():
    	        if msg in ln:
    	            print("The message has been found!")
    	            return True
    	    print("The message has NOT been found!")
    	    return False
    	
    	
    	if mimics.logging.get_logging_level() <= logging.DEBUG:
    	    print("This example needs logging level higher than 'DEBUG'.")
    	else:
    	    # we flush at the very start to have predictable (no buffered log records) situation
    	    mimics.logging.flush()
    	
    	    # write the message to the log in INFO (buffered way) -> so we will be able to find it later
    	    MSG = f"Some random ({randrange(10000)}) text message to write and to find later."
    	    mimics.logging.log_user_message(logging.INFO, MSG)
    	
    	    found = find_message_in_the_tail_of_log(MSG)
    	    assert not found, "the last log record shall not be found in the tail, because flushing has not taken place yet,"
    	
    	    mimics.logging.flush()
    	
    	    found = find_message_in_the_tail_of_log(MSG)
    	    assert found, "the last log record shall shall be found after the flush()."

    """
    pass


def get_logs_path():
    """
    Returns the path to the folder containing the log files for the current session of Mimics. Note that Mimics supports several logs, namely:
    
     * User log files :: a log of user activities; the default names of the files are MIS_yyy_mm_dd_hh_mm_ss_PID.txt;
    
     * System log :: a log containing records about events that occur within Mimics itself; the default names of the files are MIS_yyy_mm_dd_hh_mm_ss_PID.log;
    
     * DNB log files :: a log of events in the DICOM Network bridge library  that is used for connection of Mimics with PACSs; the default names of the files are PACS_ yyy_mm_dd_hh_mm_ss_PID.log.txt;
    
     * PACS uploader log :: a log of events that occur when  sending files to a PACS; the default names of the files are Uploader_ yyy_mm_dd_hh_mm_ss_PID.log;
    
     * SCD client log :: a log of events that occur while communication of Mimics with SurgiCase Drive (Mimics Viewer) services; the default names of the files are FileTransfers_ yyy_mm_dd_hh_mm_ss_PID.log.
    
    Here, yy, mm, dd, hh, ss corresponds to the date of creation of the file (year, month, date, hour, min, sec), PID is the process identification number.
    
    See also: mimics.logging.get_user_log_file_path(), mimics.logging.get_system_log_file_path(), mimics.get_registry_path().
    
    :returns: Path to the folder with log files, e.g. 'C:/Users/[USER]/AppData/Local/Materialise/Materialise Mimics Medical/24.0.0.357/Logs'.
    :rtype: str
    
    
    :example:
    .. code-block:: python
    
    	 
    	import os
    	import mimics
    	
    	logs_path = mimics.logging.get_logs_path()
    	
    	print(f"Listing logging content in '{logs_path}':")
    	assert os.path.exists(logs_path)
    	assert os.path.isdir(logs_path)
    	
    	for root, subdirectories, files in os.walk(logs_path):
    	    stripped_root = os.path.normpath(root)[len(logs_path):]
    	    for filename in files:
    	        print(f"\t - {os.path.join(stripped_root, filename)}")

    """
    pass


def get_logging_level():
    """
    Returns Mimics logging level. The logging levels are expressed in the way how it is done in standard Python's module 'logging'. See respectful documentation.
    
    :returns: Returns Mimics logging level
    :rtype: int
    
    
    :example:
    .. code-block:: python
    
    	 
    	import logging
    	
    	level = mimics.logging.get_logging_level()
    	logging.getLogger().setLevel(level)

    """
    pass


def log_user_message(level, message, kwargs=None):
    """
    Allows to redirect log message to Mimics user log. 
    
    It is possible to redirect all messages from any logging.Logger to Mimics user log via logging. Logger instance with name 'mimics.user'.
    
    :param level: Logging level. The list of possible values (as well as the rules of the application) of the logging level is following conventions of the standard Python module 'logging'. The logging level can be controlled via the preference of the application and/or command line. See respectful documentation.
    :type level: int
    :param message: Message to be logged. For robustness (especially in trouble-shooting and diagnostic scenarios), the application also accepts a value of an arbitrary type (including None, in which case, it is converted to 'None' text).
    :type message: typing.Union[str, typing.Any]
    :param kwargs: (optional) Optional dictionary of key:value pairs which will be logged in the tabular format after the message. Keys and values can be of arbitrary types. The application uses string representation of keys and values to convert them to text before logging. The conversion takes after checking the logging for performance reasons, so, for the 'logging.DEBUG' it is highly recommended to pass the parameters of an event being logged in 'kwargs' parameter (in contrast to formatting them unconditionally into the 'message' argument). For robustness (especially in trouble-shooting and diagnostic scenarios), the application also accepts values of an arbitrary type (including None, in which case, it is ignored).
    :type kwargs: typing.Union[typing.Dict[typing.Any, typing.Any], typing.Any]
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	import logging
    	import mimics
    	
    	# print single log message to Mimics user log
    	mimics.logging.log_user_message(level=logging.DEBUG, message="debug message")
    	mimics.logging.log_user_message(level=logging.INFO, message="info message")
    	mimics.logging.log_user_message(level=logging.WARNING, message="warning message")
    	mimics.logging.log_user_message(level=logging.ERROR, message="error message")
    	
    	# print single log message to Mimics user log with a table of parameters
    	pressure = 760
    	patient_name = "Karl"
    	temperature = 36.7
    	mimics.logging.log_user_message(logging.INFO,
    	                                "Healthiness state:",
    	                                {"Pressure": pressure, "Patient name": patient_name, "Temperature": temperature})
    	
    	# redirect all log messages from example_logger to Mimics user log
    	ms_logger = logging.getLogger("mimics.user")
    	
    	example_logger = logging.getLogger("example")
    	example_logger.setLevel(logging.DEBUG)
    	example_logger.addHandler(ms_logger)
    	example_logger.debug("test message")
    	example_logger.info("test message")
    	example_logger.warning("test message")
    	example_logger.error("test message")
    	
    	
    	#Example 2
    	import logging
    	import mimics
    	
    	
    	# print single log message with diagnostic information about 
    	# parameters with which a function is called
    	def parameters_logger(function_to_decorate):
    	    def parameters_logger_impl(*args, **kwargs):
    	        mimics.logging.log_user_message(
    	            logging.INFO,
    	            "Function is called with:",
    	            {
    	                " - name": function_to_decorate.__name__,
    	                " - the positional": args,
    	                " - keyword arguments": kwargs
    	            })
    	        function_to_decorate(*args, **kwargs)
    	    return parameters_logger_impl
    	
    	
    	@parameters_logger
    	def my_function_move_part(obj, action):
    	    import mimics
    	    print("doing something with obj, action: {}, {}".format(obj, action))
    	
    	
    	my_function_move_part(obj="my object", action=7)
    	my_function_move_part("my object", action=None)
    	my_function_move_part(["complex", "object"], True)

    """
    pass


