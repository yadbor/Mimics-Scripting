import typing
import mimics


def indicate_spline(message='Please indicate points that will define the spline.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate a spline.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true it displays the OK button and waits for user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Spline Object.
    :rtype: mimics.analyze.Spline
    
    
    :example:
    .. code-block:: python
    
    	 
    	t = 'Spline A'
    	sp = mimics.analyze.indicate_spline(title=t)

    """
    pass


def create_midpoint(point1, point2, name=None, color=None):
    """
    Creates a point as a midpoint of two points.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the label of the new point. If not present, a default label will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A point.
    :rtype: mimics.analyze.Point
    
    :exceptions: ValueError (reason(s): ['Could not create a new point as a midpoint of two coincident points', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	coordinates1 = (3,5,7)
    	coordinates2 = (5,9,11)
    	mimics.analyze.create_midpoint(point1=coordinates1, point2=coordinates2)

    """
    pass


def create_point_center_of_gravity(part, name=None, color=None):
    """
    Creates a point as the center of gravity point of a part.
    
    :param part: The Part.
    :type part: mimics.Part
    :param name: (optional) Defines the name of the new point. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A point.
    :rtype: mimics.analyze.Point
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	cof = mimics.analyze.create_point_center_of_gravity(part=p)

    """
    pass


def create_point_as_lines_intersection(line1, line2, name=None, color=None):
    """
    Creates a point as intersection of two lines.
    
    :param line1: The first line.
    :type line1: mimics.analyze.Line
    :param line2: The second line.
    :type line2: mimics.analyze.Line
    :param name: (optional) Defines the name of the new point. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A point.
    :rtype: mimics.analyze.Point
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Invalid line argument', 'Input lines do not intersect', 'Analytical lines coincide'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	ln1 = mimics.data.lines[0]
    	mid = ((ln1.point1[0]+ln1.point2[0])/2,(ln1.point1[1]+ln1.point2[1])/2,(ln1.point1[2]+ln1.point2[2])/2)
    	ln2 = mimics.data.lines.duplicate(ln1)
    	ln2.point1 = (mid[0]-25,mid[1],mid[2])
    	ln2.point1 = (mid[0]+25,mid[1],mid[2])
    	mimics.analyze.create_point_as_lines_intersection(line1=ln1, line2=ln2)

    """
    pass


def create_plane_origin_and_normal(origin, normal, name=None, color=None):
    """
    Creates a plane.The origin and normal are required.
    
    :param origin: Origin of the plane.
    :type origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param normal: Normal of the plane.
    :type normal: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new plane. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new plane. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: returns Plane
    :rtype: mimics.analyze.Plane
    
    :exceptions: ValueError (reason(s): ['Normal vector length is 0.', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	o = (-108.75,7.08,9.45)
    	d = (-86.54,-17.59,9.45)
    	mimics.analyze.create_plane_origin_and_normal(origin=o, normal=d)

    """
    pass


def edit_spline(spline, message='Please edit the spline.', title=None):
    """
    Displays a dialog for spline editing, activates cursor for the selected spline editing.
    
    :param spline: Spline to be edited.
    :type spline: mimics.analyze.Spline
    :param message: (optional) Description of the dialog.
    :type message: str
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Spline object.
    :rtype: mimics.analyze.Spline
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (0,0,0)
    	p2 = (100,0,0)
    	p3 = (0,100,0)
    	sp = mimics.analyze.create_spline([p1,p2,p3],closed=True)
    	mimics.analyze.edit_spline(sp)

    """
    pass


def _resize_plane_to_objects(plane, objects, move_origin, include_full_bbox, scale_factor=1.0, first_axis=None, second_axis=None):
    """
    Change the size and/or position of plane with regards to bounding box, described by object(s). 
    
    The Mimics plane stays in the same analytical plane. In other words, plane equation does not change. 
    
    The origin of Mimics plane can be unchanged or changed, depending on 'move_origin' parameter. 
    
    New origin is calculated as projection of bounding box center on the analytical plane. 
    
    The size of Mimics plane can be changed in 2 ways depending on 'include_full_bbox' parameter. 
    
    With 'include_full_bbox'==True, the plane is square with side calculated as distance from the plane center to the most distant bounding box corner. 
    
    With 'include_full_bbox'==False, the size of plane is calculated in a way that plane contains all projected bounding box corners. 
    
    The resulted plane can be scaled via 'scale_factor'. 
    
    Bounding box of objects is calculated in some coordinate system. This coodinate system can be specified via 'first_axis' and 'second_axis' vectors. 
    
    If 'first_axis' and 'second_axis' are None - the 'x_axis' and 'y_axis' of plane will be used respectively. 
    
    Bounding box is a cuboid, so it axes have to be perpendicular. 
    
    If 'first_axis' is not perpendicular to 'second_axis', 'second_axis' will be modified to become perpendicular. 
    
    If 'first_axis' and 'second_axis' are parrallel - exception. 
    
    Both axes should be specified or not specified simultaneously. If 'first_axis' is specified and 'second_axis' is not, or vise versa - exception. 
    
    This API might be usefull for MPR creation. See mimics.view.create_resliced_view_with_plane API. 
    
    :param plane: The plane that will be resized into bounding box of objects
    :type plane: mimics.analyze.Plane
    :param objects: Objects that specify the bounding box used for plane resizing
    :type objects: typing.Union[mimics.Object, GenericObjectIterable]
    :param move_origin: To move origin or expand plane size. If move_origin is True - plane origin is moved to the projection of bounding box center on the plane. If move_origin is False - the plane origin is unchanged.
    :type move_origin: bool
    :param include_full_bbox: Take into account the size of bbox or not. Determine the plane size as if MPR will be created on this plane. If include_full_bbox is True - after any MPR rotation, MPR will contain the whole bounding box. If include_full_bbox is False - plane contains all points projected from bounding box corners on the plane
    :type include_full_bbox: bool
    :param scale_factor: (optional) Scale factor shrinks(<1.0) or expands(>1.0) plane size. If the value is '1.0', plane is resized to bounding box as described in 'include_full_bbox'
    :type scale_factor: typing.SupportsFloat
    :param first_axis: (optional) First axis of the bounding box. By default x_axis of plane is used
    :type first_axis: typing.Optional[TMimicsVector]
    :param second_axis: (optional) Second axis of the bounding box. By default x_axis of plane is used
    :type second_axis: typing.Optional[TMimicsVector]
    """
    pass


def indicate_point(message='Please indicate point', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate a point.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true it displays the OK button and waits for user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: A Point.
    :rtype: mimics.analyze.Point
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = "Please indicate the point"
    	cnfrm = False
    	smb = True
    	tit = "Indicate Point"
    	pnt = mimics.analyze.indicate_point(message=msg, confirm=cnfrm, show_message_box=smb, title=tit)

    """
    pass


def create_line_origin_direction_length(origin, direction, length, name=None, color=None):
    """
    Creates a line. Origin, direction and length are required.
    
    :param origin: Coordinates of the origin point of the line.
    :type origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param direction: Direction of the line.
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param length: Length of the line.
    :type length: typing.SupportsFloat
    :param name: (optional) Defines the name of the new line. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new line. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A line.
    :rtype: mimics.analyze.Line
    
    :exceptions: ValueError (reason(s): ['Direction vector length is 0', 'Length should not be less than 0', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	o = (10,10,10)
    	d = (-1,0,0)
    	l = 50.0
    	mimics.analyze.create_line_origin_direction_length(origin=o, direction=d, length=l)

    """
    pass


def create_point(point, name=None, color=None):
    """
    Creates a point by indicating its coordinates.
    
    :param point: The x, y, z coordinates of the point.
    :type point: typing.Union[TMimicsPoint, typing.Dict[int, typing.SupportsFloat]]
    :param name: (optional) Defines the name of the new point. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A point.
    :rtype: mimics.analyze.Point
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	coordinates = (3,5,7)
    	mimics.analyze.create_point(point=coordinates)

    """
    pass


def create_plane_fit_to_surface(part, name=None, color=None):
    """
    Creates a plane by fitting it to a surface (part).
    
    :param part: The Part.
    :type part: mimics.Part
    :param name: (optional) Defines the name of the new plane. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new plane. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A plane.
    :rtype: mimics.analyze.Plane
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	mimics.analyze.create_plane_fit_to_surface(part = p)

    """
    pass


def create_plane_fit_to_spline(spline, name=None, color=None):
    """
    Creates a plane by fitting it to a spline geometry points.
    
    :param spline: The Spline.
    :type spline: mimics.analyze.Spline
    :param name: (optional) Defines the name of the new plane. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new plane. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A plane.
    :rtype: mimics.analyze.Plane
    """
    pass


class Circle(mimics.Object):
    """
    Circle is an analysis object based on center, radius and direction.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def center(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @center.setter
    def center(self, value):
        """
    
        """
        pass

    @property
    def radius(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Radius should not be less than 0.0001'])
        """
        pass
    
    @radius.setter
    def radius(self, value):
        """
    
        """
        pass

    @property
    def normal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Normal vector length is 0.'])
        """
        pass
    
    @normal.setter
    def normal(self, value):
        """
    
        """
        pass


def create_sphere_points(point1, point2, point3, point4, name=None, color=None):
    """
    Creates a sphere. Four points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point4: Coordinates of the fourth point.
    :type point4: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new sphere. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new sphere. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A sphere.
    :rtype: mimics.analyze.Sphere
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Could not create sphere with 4 points placed on the same plane', 'Could not create sphere with 3 or more points placed on the same line', 'Could not create sphere because its radius was too large'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (2,5.7,3)
    	p2 = (3,4,5)
    	p3 = (0.8,3.45,7.62)
    	p4 = (9,10,14)
    	sph = mimics.analyze.create_sphere_points(point1=p1, point2=p2, point3=p3, point4=p4)

    """
    pass


def indicate_plane_origin_and_normal(message='Please indicate point on the curve that will define plane.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate a plane by selecting origin point on a curve (spline or centerline). Normal is automatically calculated based on a curve. Plane adjustment is possible by moving the origin point.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true it displays the OK button and waits for user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of hte dialog.
    :type title: str
    
    :returns: Plane object.
    :rtype: mimics.analyze.Plane
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.analyze.indicate_plane_origin_and_normal(message='Please indicate point on the curve that will define plane.')

    """
    pass


def edit_point(point, message='Please edit the point', title=None):
    """
    Displays a dialog which asks the user to edit a specific point.
    
    :param point: Point to be edited.
    :type point: mimics.analyze.Point
    :param message: (optional) Description of the dialog.
    :type message: str
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: A Point.
    :rtype: mimics.analyze.Point
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.points[0]
    	msg = "Please edit the point"
    	t = "Edit Point"
    	mimics.analyze.edit_point(point=p, message=msg, title=t)

    """
    pass


def find_closest_point(point, object):
    """
    Finds closest point from the defined point to the defined object: centerline, line, part, plane or spline.
    
    :param point: Coordinates of the point.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param object: Object: centerline, line, part, plane or spline.
    :type object: typing.Union[mimics.analyze.Centerline, mimics.analyze.Line, mimics.Part, mimics.analyze.Plane, mimics.analyze.Spline]
    
    :returns: Coordinate of the closest point.
    :rtype: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :exceptions: TypeError (reason(s): ['Exception in case if selected object is not centerline, spline or part'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.points[0]
    	obj = mimics.data.parts[0]
    	cl = mimics.analyze.find_closest_point(point=p, object=obj)

    """
    pass


class Line(mimics.Object):
    """
    Line is an analysis object based on two points.
    """
    def __init__(self):
        """
    
        """
        pass

    def __len__(self):
        """
    
        """
        pass

    def __getitem__(self, index):
        """
        :param index: 
        :type index: int
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def direction(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def length(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Length of the line which points coincide cannot be changed because it has no direction', 'Length should not be less than 0.0001'])
        """
        pass
    
    @length.setter
    def length(self, value):
        """
    
        """
        pass


class Plane(mimics.Object):
    """
    Plane is an analysis object based on the defined origin and normal.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def origin(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @origin.setter
    def origin(self, value):
        """
    
        """
        pass

    @property
    def normal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @normal.setter
    def normal(self, value):
        """
    
        """
        pass

    @property
    def x_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def y_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def z_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def width(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Width should not be less than 0.0001'])
        """
        pass
    
    @width.setter
    def width(self, value):
        """
    
        """
        pass

    @property
    def height(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Height should not be less than 0.0001'])
        """
        pass
    
    @height.setter
    def height(self, value):
        """
    
        """
        pass

    @property
    def delta_x(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['DeltaX should not be less than 0.0001'])
        """
        pass
    
    @delta_x.setter
    def delta_x(self, value):
        """
    
        """
        pass

    @property
    def delta_y(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['DeltaY should not be less than 0.0001'])
        """
        pass
    
    @delta_y.setter
    def delta_y(self, value):
        """
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def point3(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point3.setter
    def point3(self, value):
        """
    
        """
        pass

    @property
    def transparency(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Transparency should be in 0.0-1.0 range.'])
        """
        pass
    
    @transparency.setter
    def transparency(self, value):
        """
    
        """
        pass


def create_cylinder_fit_to_surface(part, name=None, color=None):
    """
    Creates a cylinder fit to surface (part).
    
    :param part: Part for the cylinder to be fit into.
    :type part: mimics.Part
    :param name: (optional) Defines the name of the new cylinder. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new cylinder. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A cylinder.
    :rtype: mimics.analyze.Cylinder
    
    :exceptions: ValueError (reason(s): ['Could not create cylinder with two points that coincide', 'Could not create cylinder with radius less than 0.0001', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	mimics.analyze.create_cylinder_fit_to_surface(part = p)

    """
    pass


class Spline(mimics.Object):
    """
    Spline is an analysis object defined by control points. Can be closed or opened.
    """
    def __init__(self):
        """
    
        """
        pass

    def __len__(self):
        """
    
        """
        pass

    def __getitem__(self, index):
        """
        :param index: 
        :type index: int
        
        :exceptions: IndexError (reason(s): ['Point index is out of available range ( index >= len(spline) ).'])
        """
        pass

    @property
    def closed(self):
        """
        State of Spline: closed or not closed
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @closed.setter
    def closed(self, value):
        """
    
        """
        pass

    @property
    def points(self):
        """
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: False
        :exceptions: ValueError (reason(s): ['One point is not enough to build a spline'])
        """
        pass
    
    @points.setter
    def points(self, value):
        """
    
        """
        pass

    @property
    def diameter(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Diameter should be non-negative and below maximum allowed for project pixel size.'])
        """
        pass
    
    @diameter.setter
    def diameter(self, value):
        """
    
        """
        pass

    @property
    def length(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def order(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def geometry_points(self):
        """
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: True
    
        """
        pass

    @property
    def project_on_slices(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @project_on_slices.setter
    def project_on_slices(self, value):
        """
    
        """
        pass

    @property
    def opaque_on_images(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @opaque_on_images.setter
    def opaque_on_images(self, value):
        """
    
        """
        pass

    @property
    def precision(self):
        """
        :type: <class 'typing.SupportsInt'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Precision must be 0, 1, 2 or 3'])
        """
        pass
    
    @precision.setter
    def precision(self, value):
        """
    
        """
        pass

    @property
    def is_label_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_visible.setter
    def is_label_visible(self, value):
        """
    
        """
        pass

    @property
    def indexes_visible(self):
        """
        Allows enabling/disabling visualization of the numbers shown next to the control points of the spline.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @indexes_visible.setter
    def indexes_visible(self, value):
        """
    
        """
        pass

    @property
    def is_unit_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_unit_visible.setter
    def is_unit_visible(self, value):
        """
    
        """
        pass


def create_line(point1, point2, name=None, color=None):
    """
    Creates a line. Two points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new line. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new line. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A line.
    :rtype: mimics.analyze.Line
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Could not create line with points that coincide'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (1,2.4,36)
    	p2 = (8,8,98)
    	mimics.analyze.create_line(point1=p1, point2=p2)

    """
    pass


def create_plane_points(point1, point2, point3, name=None, color=None):
    """
    Creates a plane. Three points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new plane. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new plane. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A plane.
    :rtype: mimics.analyze.Plane
    
    :exceptions: ValueError (reason(s): ['Could not create plane with points that coincide', 'Could not create plane with points placed on the same line', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (-108.75,7.08,9.45)
    	p2 = (-86.54,-17.59,9.45)
    	p3 = (-28.32,-29.93,-8)
    	mimics.analyze.create_plane_points(point1=p1, point2=p2, point3=p3)

    """
    pass


def resize_plane_to_bounding_box(plane, bounding_box, move_origin, include_full_bbox, scale_factor=1.0):
    """
    Change the size and/or position of plane with regards to bounding box. 
    
    The Mimics plane stays in the same analytical plane. In other words, plane equation does not change. 
    
    The origin of Mimics plane can be unchanged or changed, depending on 'move_origin' parameter. 
    
    New origin is calculated as projection of bounding box center on the analytical plane. 
    
    The size of Mimics plane can be changed in 2 ways depending on 'include_full_bbox' parameter. 
    
    With 'include_full_bbox'==True, the plane is square with side calculated as distance from the plane center to the most distant bounding box corner. 
    
    With 'include_full_bbox'==False, the size of plane is calculated in a way that plane contains all projected bounding box corners. 
    
    The resulted plane can be scaled via 'scale_factor'. 
    
    This API might be usefull for MPR creation. See mimics.view.create_resliced_view_with_plane API. 
    
    :param plane: The plane that will be resized into bounding box
    :type plane: mimics.analyze.Plane
    :param bounding_box: The bounding box used for plane resizing
    :type bounding_box: mimics.BoundingBox3d
    :param move_origin: To move origin or expand plane size. If move_origin is True - plane origin is moved to the projection of bounding box center on the plane. If move_origin is False - the plane origin is unchanged.
    :type move_origin: bool
    :param include_full_bbox: Take into account the size of bbox or not. Determine the plane size as if MPR will be created on this plane. If include_full_bbox is True - after any MPR rotation, MPR will contain the whole bounding box. If include_full_bbox is False - plane contains all points projected from bounding box corners on the plane
    :type include_full_bbox: bool
    :param scale_factor: (optional) Scale factor shrinks(<1.0) or expands(>1.0) plane size. If the value is '1.0', plane is resized to bounding box as described in 'include_full_bbox'
    :type scale_factor: typing.SupportsFloat
    
    :exceptions: ValueError (reason(s): ['Scale factor should be in range from 0.0001 to 10000'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	plane = mimics.data.planes[0]
    	part = mimics.data.parts[0]
    	bbox = mimics.measure.get_bounding_box(part)
    	mimics.analyze.resize_plane_to_bounding_box(plane=plane, bounding_box=bbox, move_origin=True, include_full_bbox=False, scale_factor=1.0)

    """
    pass


class Point(mimics.Object):
    """
    Point is an analysis object based on the defined coordinates.
    """
    def __len__(self):
        """
    
        """
        pass

    def __getitem__(self, index):
        """
        :param index: 
        :type index: int
        """
        pass

    @property
    def coordinates(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @coordinates.setter
    def coordinates(self, value):
        """
    
        """
        pass

    @property
    def x(self):
        """
        :type: <class 'float'>
        :read-only: False
    
        """
        pass
    
    @x.setter
    def x(self, value):
        """
    
        """
        pass

    @property
    def y(self):
        """
        :type: <class 'float'>
        :read-only: False
    
        """
        pass
    
    @y.setter
    def y(self, value):
        """
    
        """
        pass

    @property
    def z(self):
        """
        :type: <class 'float'>
        :read-only: False
    
        """
        pass
    
    @z.setter
    def z(self, value):
        """
    
        """
        pass

    @property
    def allow_change_follow_position(self):
        """
        Switches ON/OFF the re-link behavior of the point to the object specified in 'follow_position_of property' when the point is edited manually on viewports.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @allow_change_follow_position.setter
    def allow_change_follow_position(self, value):
        """
    
        """
        pass

    @property
    def follow_position_of(self):
        """
        Specifies an object with which was established linkage from the point side.
        
        When the object specified in this property will change its position, the point will follow it and the point position will be changed accordingly.
        
        :type: typing.Union[mimics.Part, mimics.Osteotomy, mimics.analyze.Sphere, mimics.analyze.Cylinder, NoneType]
        :read-only: False
        :exceptions: ValueError (reason(s): ['The point can only follow the objects represented as 3D objects, such as imported parts, osteotomy objects, cylinders, and others.'])
        """
        pass
    
    @follow_position_of.setter
    def follow_position_of(self, value):
        """
    
        """
        pass


def indicate_plane_points(message='Please indicate three points that will define plane.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate a plane by indicating three points. Plane adjustment is possible by moving the control points.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true it displays the OK button and waits for user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Plane object.
    :rtype: mimics.analyze.Plane
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate three points that will define plane.'
    	tit = 'Plane 1'
    	plane = mimics.analyze.indicate_plane_points(message=msg, title=tit)

    """
    pass


def create_line_as_planes_intersection(plane1, plane2, name=None, color=None):
    """
    Creates a line as intersection of two planes.
    
    :param plane1: The first plane.
    :type plane1: mimics.analyze.Plane
    :param plane2: The second plane.
    :type plane2: mimics.analyze.Plane
    :param name: (optional) Defines the name of the new line. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new line. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A line.
    :rtype: mimics.analyze.Line
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Input planes are parallel.', 'Input planes are overlapping.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	pl1 = mimics.data.planes[0]
    	pl2 = mimics.data.planes.duplicate(pl1)
    	pl2.origin = (0,0,0)
    	pl2.normal = (0,0,1)
    	mimics.analyze.create_line_as_planes_intersection(plane1 = pl1, plane2 = pl2)

    """
    pass


def create_plane_points_perpendicular_to_plane(point1, point2, plane, align_to_points=False, name=None, color=None):
    """
    Creates a plane that goes through the two given points and perpendicular to the given plane. Orients the new plane along the input points or aligns it with the input plane.
    
    :param point1: Coordinates of the point 1, where the origin of the new plane will be placed.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the point 2.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param plane: A plane object.
    :type plane: mimics.analyze.Plane
    :param align_to_points: (optional) Flag that indicates whether the new plane will be aligned to the points (true) or along the input plane (false).
    :type align_to_points: bool
    :param name: (optional) Defines the name of the new plane. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new plane. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A plane.
    :rtype: mimics.analyze.Plane
    
    :exceptions: ValueError (reason(s): ['Could not create plane when the input points coincide', 'Could not create plane when the input points lay on a normal to the input plane'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	point1 = mimics.data.points[0]  # take a point from database (this will be the center of the 
    	point2 = (10.22, 28.0, 3.0)  # or we just take a hardcoded coordinate
    	plane = mimics.data.planes[0]
    	
    	# creating a plane which will be oriented along the plane:
    	#   the x-direction of the plane will be oriented along the projections of 
    	#   Point1->Point2 vector on the original plane.
    	new_plane = mimics.analyze.create_plane_points_perpendicular_to_plane(point1=point1, point2=point2, plane=plane, align_to_points=True)
    	print("{} = {}".format(point1.coordinates, new_plane.origin))  # the coordinates shall be the same
    	
    	# creating a plane which will be oriented along the points:
    	#   the x-direction of the plane will be oriented along Point1->Point2 vector
    	new_plane = mimics.analyze.create_plane_points_perpendicular_to_plane(point1=point1, point2=point2, plane=plane, align_to_points=True)
    	print("{} = {}".format(point1.coordinates, new_plane.origin))  # the coordinates shall be the same

    """
    pass


def _project_point_to_part(point, part, direction):
    """
    Projects a point to a part given a direction vector and returns projection points sorted by distance from projected point.
    
    :param point: The point to project.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param part: The part.
    :type part: mimics.Part
    :param direction: The direction (vector) of point projection.
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Coordinates of intersection points on part sorted by distance.
    :rtype: typing.Iterable[TMimicsPoint]
    """
    pass


def create_spline(points, closed=False, diameter=None, name=None, color=None, order=None):
    """
    Creates a spline. At least two points are required.
    
    :param points: Coordinates of the points.
    :type points: typing.Sequence[TMimicsPoint]
    :param closed: (optional) State of the spline: closed or not closed.
    :type closed: bool
    :param diameter: (optional) Diameter of the spline. If the input value is 'None' diameter is selected according to the pixel size of the project.
    :type diameter: typing.SupportsFloat
    :param name: (optional) Defines the name of the new spline. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new spline. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param order: (optional) Order of spline for creation. Available values - 2, 3, 4. If not specified, spline order is defined automatically (3 for not closed spline, 4 for closed spline)
    :type order: typing.Optional[typing.SupportsInt]
    
    :returns: A spline object.
    :rtype: mimics.analyze.Spline
    
    :exceptions: ValueError (reason(s): ['One point is not enough points to build a spline', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	point_1 = (-108.75,7.08,9.45)
    	point_2 = (-86.54,-17.59,9.45)
    	point_3 = (-28.32,-29.93,9.45)
    	point_4 = (12.14,-24.50,9.45)
    	point_5 = (35.82,14.48,9.45)
    	mimics.analyze.create_spline(points=[point_1,point_2,point_3,point_4,point_5], closed=False)

    """
    pass


class Sphere(mimics.Object):
    """
    Sphere is an analysis object based on center and radius.
    """
    def __init__(self):
        """
    
        """
        pass

    def __len__(self):
        """
    
        """
        pass

    def __getitem__(self, index):
        """
        :param index: 
        :type index: int
        """
        pass

    @property
    def center(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @center.setter
    def center(self, value):
        """
    
        """
        pass

    @property
    def radius(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Radius should not be less than 0.0001'])
        """
        pass
    
    @radius.setter
    def radius(self, value):
        """
    
        """
        pass

    @property
    def transparency(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Transparency should be in 0.0-1.0 range.'])
        """
        pass
    
    @transparency.setter
    def transparency(self, value):
        """
    
        """
        pass


def create_cylinder_points_radius(point1, point2, radius, name=None, color=None):
    """
    Creates a cylinder. Two points and radius are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param radius: Radius of the cylinder.
    :type radius: typing.SupportsFloat
    :param name: (optional) Defines the name of the new cylinder. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new cylinder. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A cylinder.
    :rtype: mimics.analyze.Cylinder
    
    :exceptions: ValueError (reason(s): ['Could not create cylinder with two points that coincide', 'Could not create cylinder with radius less than 0.0001', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (0,0,0)
    	p2 = (1,1,5)
    	r = 40.0
    	mimics.analyze.create_cylinder_points_radius(point1=p1, point2=p2 ,radius=r)

    """
    pass


def set_plane_orientation_x(plane, direction, retain_normal):
    """
    Rotates the Plane to make its x_axis aligned with the given direction.
    
    :param plane: Plane to rotate.
    :type plane: mimics.analyze.Plane
    :param direction: Direction for the x_axis of the Plane to be aligned with.
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param retain_normal: if true, then normal of the plane will be retained and the plane will rotate to align with the projection of the direction on the plane.
    :type retain_normal: bool
    
    :exceptions: ValueError (reason(s): ['the direction vector cannot have zero length', 'the direction vector cannot be orthogonal to the plane'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# align the X axis of the plane with sagittal slice, and keep the plane's normal unchanged
    	pl = mimics.data.planes[0]
    	d = (0, 10, 0)
    	mimics.analyze.set_plane_orientation_x(pl, d, True)
    	
    	# align the  X axis of the plane with sagittal slice 
    	pl = mimics.data.planes[0]
    	d = (0, 10, 0)
    	mimics.analyze.set_plane_orientation_x(pl, d, False)

    """
    pass


def set_plane_orientation_y(plane, direction, retain_normal):
    """
    Rotates the Plane to make its y_axis aligned with the given direction.
    
    :param plane: Plane to rotate.
    :type plane: mimics.analyze.Plane
    :param direction: Direction for the y_axis of the Plane to be aligned with.
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param retain_normal: if true, then normal of the plane will be retained and the plane will rotate to align with the projection of the direction on the plane.
    :type retain_normal: bool
    
    :exceptions: ValueError (reason(s): ['the direction vector cannot have zero length', 'the direction vector cannot be orthogonal to the plane'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# align the Y axis of the plane with coronal slice, and keep the plane's normal unchanged
    	pl = mimics.data.planes[0]
    	d = (10, 0, 0)
    	mimics.analyze.set_plane_orientation_y(pl, d, True)
    	
    	# align the Y axis of the plane with coronal slice
    	pl = mimics.data.planes[0]
    	d = (10, 0, 0)
    	mimics.analyze.set_plane_orientation_y(pl, d, False)

    """
    pass


def create_sphere_center_radius(center, radius, name=None, color=None):
    """
    Creates a sphere. Center and radius are required.
    
    :param center: Center of the sphere.
    :type center: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param radius: Radius of the sphere.
    :type radius: typing.SupportsFloat
    :param name: (optional) Defines the name of the new sphere. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new sphere. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A sphere.
    :rtype: mimics.analyze.Sphere
    
    :exceptions: ValueError (reason(s): ['Radius cannot be negative', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Could not create sphere because its radius was too large'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	c = (3,4,5)
    	r = 45.0
    	sph=mimics.analyze.create_sphere_center_radius(center=c, radius=r)

    """
    pass


class Cylinder(mimics.Object):
    """
    Cylinder is an analysis object based on two points, length and radius.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def height(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Height of the cylinder cannot be changed because its current height is zero and, consequently, it has no direction', 'Height should not be less than 0.0001'])
        """
        pass
    
    @height.setter
    def height(self, value):
        """
    
        """
        pass

    @property
    def radius(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Radius should not be less than 0.0001'])
        """
        pass
    
    @radius.setter
    def radius(self, value):
        """
    
        """
        pass

    @property
    def direction(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def transparency(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Transparency should be in 0.0-1.0 range.'])
        """
        pass
    
    @transparency.setter
    def transparency(self, value):
        """
    
        """
        pass


def create_line_fit_to_surface(part, name=None, color=None):
    """
    Creates a line by fitting it to a surface (part).
    
    :param part: The Part.
    :type part: mimics.Part
    :param name: (optional) Defines the name of the new line. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new line. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A line.
    :rtype: mimics.analyze.Line
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	mimics.analyze.create_line_fit_to_surface(part = p)

    """
    pass


def create_projected_points(point, direction, object, project_through, color=None, return_points='All'):
    """
    Creates points projected on Part in given direction.
    
    :param point: The point to project.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param direction: The projection direction (vector).
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param object: The object for the point to be projected on: part or area.
    :type object: typing.Union[mimics.Part, mimics.measure.Area]
    :param project_through: Flag that indicates whether projection goes through Part or not
    :type project_through: bool
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param return_points: (optional) The different return_points options are:
        * All :: returns the list of all the points.
        * Closest :: returns the list with a single closest point.
        * Farthest :: returns the list with a single farthest point.
    :type return_points: str
    
    :returns: objects.
    :rtype: typing.Iterable[mimics.analyze.Point]
    
    :exceptions: ValueError (reason(s): ['Direction cannot be null', 'Could not project a point in given direction. Try to change input'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	pt = mimics.data.points[0]
    	d = (-0.185911, -0.948227, -0.257493)
    	part = mimics.data.parts[0]
    	mimics.analyze.create_projected_points(point=pt, direction=d, object=part, project_through=True, return_points='All')

    """
    pass


def create_circle_center_normal_radius(center, normal, radius, name=None, color=None):
    """
    Creates a circle. Center, normal and radius are required.
    
    :param center: Coordinates of the center point of the circle.
    :type center: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param normal: Normal of the circle.
    :type normal: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param radius: Radius of the circle.
    :type radius: typing.SupportsFloat
    :param name: (optional) Defines the name of the new circle. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new circle. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A circle.
    :rtype: mimics.analyze.Circle
    
    :exceptions: ValueError (reason(s): ['Normal vector length is 0', 'Radius should not be less than 0.0001', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	c = (10,10,10)
    	n = (-1,0,0)
    	r = 5.0
    	mimics.analyze.create_circle_center_normal_radius(center=c, normal=n, radius=r)

    """
    pass


def indicate_sphere(message='Please indicate four points that will define sphere.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate a sphere by indicating four points. Sphere adjustment is possible by moving of the control point.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true it displays the OK button and waits for user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Sphere object.
    :rtype: mimics.analyze.Sphere
    
    
    :example:
    .. code-block:: python
    
    	 
    	t = "Indicate sphere"
    	sph = mimics.analyze.indicate_sphere(title=t, confirm=False)

    """
    pass


def create_spline_project_on_plane(spline, plane, name=None, color=None, order=None):
    """
    Projects the spline to a plane and creates a new spline.
    
    :param spline: The Spline to project.
    :type spline: mimics.analyze.Spline
    :param plane: The plane.
    :type plane: mimics.analyze.Plane
    :param name: (optional) Defines the name of the new spline. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new spline. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param order: (optional) Order of projected spline. Available values - 2, 3, 4. If not specified, spline order is defined automatically (3 for not closed spline, 4 for closed spline)
    :type order: typing.Optional[typing.SupportsInt]
    
    :returns: A spline.
    :rtype: mimics.analyze.Spline
    
    :exceptions: ValueError (reason(s): ['Defined spline is projected into invalid spline on the defined plane.', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	point_1 = (-108.75,7.08,9.45)
    	point_2 = (-86.54,-17.59,9.45)
    	point_3 = (-28.32,-29.93,9.45)
    	point_4 = (12.14,-24.50,9.45)
    	point_5 = (35.82,14.48,9.45)
    	spl = mimics.analyze.create_spline(points=[point_1,point_2,point_3,point_4,point_5], closed=False)
    	plane_pnt1 = (0,0,0)
    	plane_pnt2 = (200,0,0)
    	plane_pnt3 = (0,0,200)
    	pl = mimics.analyze.create_plane_points(plane_pnt1, plane_pnt2, plane_pnt3)
    	sp = mimics.analyze.create_spline_project_on_plane(spline=spl, plane=pl)

    """
    pass


def project_point(point, object, direction):
    """
    Projects a defined point to the defined object with a defined direction vector and returns projection points sorted by distance from the projected point.
    
    :param point: The point to project.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param object: The object (mimics.Part) for the point to be projected on.
    :type object: mimics.Part
    :param direction: The direction (vector) of the point projection.
    :type direction: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Coordinates of projection points on the object sorted by distance.
    :rtype: typing.Iterable[TMimicsPoint]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.points[0]
    	obj = mimics.data.parts[0]
    	d = (0,0,1) 
    	cl = mimics.analyze.project_point(point=p, object=obj, direction=d)

    """
    pass


def create_point_as_line_and_plane_intersection(line, plane, name=None, color=None):
    """
    Creates a point as intersection of a line and a plane.
    
    :param line: The line.
    :type line: mimics.analyze.Line
    :param plane: The plane.
    :type plane: mimics.analyze.Plane
    :param name: (optional) Defines the name of the new point. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A point.
    :rtype: mimics.analyze.Point
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Invalid line', 'Invalid plane', 'Line lays on the plane', 'Input line and plane do not intersect'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	ln = mimics.data.lines[0]
    	pl = mimics.data.planes[0]
    	mimics.analyze.create_point_as_line_and_plane_intersection(line=ln, plane=pl)

    """
    pass


def create_lines_inertia_axes(part):
    """
    Creates three lines through the inertia axes of a part.
    
    :param part: The Part.
    :type part: mimics.Part
    
    :returns: X,Y,Z inertia axes lines.
    :rtype: typing.List[mimics.analyze.Line]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	mimics.analyze.create_lines_inertia_axes(part=p)

    """
    pass


def create_closest_point(point, object, name=None, color=None):
    """
    Finds closest point from the defined point to the defined object: centerline, line, part, plane or spline.
    
    :param point: Coordinates of the point.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param object: Object: centerline, line, part, plane or spline.
    :type object: typing.Union[mimics.analyze.Centerline, mimics.analyze.Line, mimics.Part, mimics.analyze.Plane, mimics.analyze.Spline]
    :param name: (optional) Defines the name of the new point. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new point. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Coordinate of the closest point.
    :rtype: mimics.analyze.Point
    
    :exceptions: TypeError (reason(s): ['Exception in case if selected object is not centerline, spline or part'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.points[0]
    	obj = mimics.data.parts[0]
    	cl = mimics.analyze.create_closest_point(point=p, object=obj)

    """
    pass


def resize_plane_to_objects(plane, objects, move_origin, include_full_bbox, scale_factor=1.0, first_axis=None, second_axis=None):
    """
    Change the size and/or position of plane with regards to bounding box, described by object(s). 
    
    The Mimics plane stays in the same analytical plane. In other words, plane equation does not change. 
    
    The origin of Mimics plane can be unchanged or changed, depending on 'move_origin' parameter. 
    
    New origin is calculated as projection of bounding box center on the analytical plane. 
    
    The size of Mimics plane can be changed in 2 ways depending on 'include_full_bbox' parameter. 
    
    With 'include_full_bbox'==True, the plane is square with side calculated as distance from the plane center to the most distant bounding box corner. 
    
    With 'include_full_bbox'==False, the size of plane is calculated in a way that plane contains all projected bounding box corners. 
    
    The resulted plane can be scaled via 'scale_factor'. 
    
    Bounding box of objects is calculated in some coordinate system. This coodinate system can be specified via 'first_axis' and 'second_axis' vectors. 
    
    If 'first_axis' and 'second_axis' are None - the 'x_axis' and 'y_axis' of plane will be used respectively. 
    
    Bounding box is a cuboid, so it axes have to be perpendicular. 
    
    If 'first_axis' is not perpendicular to 'second_axis', 'second_axis' will be modified to become perpendicular. 
    
    If 'first_axis' and 'second_axis' are parrallel - exception. 
    
    Both axes should be specified or not specified simultaneously. If 'first_axis' is specified and 'second_axis' is not, or vise versa - exception. 
    
    This API might be usefull for MPR creation. See mimics.view.create_resliced_view_with_plane API. 
    
    :param plane: The plane that will be resized into bounding box of objects
    :type plane: mimics.analyze.Plane
    :param objects: Objects that specify the bounding box used for plane resizing
    :type objects: GenericObjectIterable
    :param move_origin: To move origin or expand plane size. If move_origin is True - plane origin is moved to the projection of bounding box center on the plane. If move_origin is False - the plane origin is unchanged.
    :type move_origin: bool
    :param include_full_bbox: Take into account the size of bbox or not. Determine the plane size as if MPR will be created on this plane. If include_full_bbox is True - after any MPR rotation, MPR will contain the whole bounding box. If include_full_bbox is False - plane contains all points projected from bounding box corners on the plane
    :type include_full_bbox: bool
    :param scale_factor: (optional) Scale factor shrinks(<1.0) or expands(>1.0) plane size. If the value is '1.0', plane is resized to bounding box as described in 'include_full_bbox'
    :type scale_factor: typing.SupportsFloat
    :param first_axis: (optional) First axis of the bounding box. By default x_axis of plane is used
    :type first_axis: typing.Optional[TMimicsVector]
    :param second_axis: (optional) Second axis of the bounding box. By default x_axis of plane is used
    :type second_axis: typing.Optional[TMimicsVector]
    
    :exceptions: ValueError (reason(s): ['Scale factor should be in range from 0.0001 to 10000', 'Axes cannot be parallel', 'Both axes should be specified or not specified simultaneously'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	plane = mimics.data.planes[0]
    	part = mimics.data.parts[0]
    	mimics.analyze.resize_plane_to_objects(plane=plane, objects=[part], move_origin=True, include_full_bbox=False, scale_factor=1.0, first_axis=None, second_axis=None)

    """
    pass


class Centerline(mimics.Object):
    """
    Centerline object is a centerline of a Part which is represented as a tree structure of splines which are fitted to the Part as channels.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def show_branching_points(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @show_branching_points.setter
    def show_branching_points(self, value):
        """
    
        """
        pass


def create_circle_points(point1, point2, point3, name=None, color=None):
    """
    Creates a circle. Three points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new circle. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new circle. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A circle.
    :rtype: mimics.analyze.Circle
    
    :exceptions: ValueError (reason(s): ['Could not create circle with points that coincide', 'Could not create circle with points placed on same line', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (6,7,8)
    	p2 = (3.4,5,16)
    	p3 = (1,1,1)
    	mimics.analyze.create_circle_points(point1=p1, point2=p2, point3=p3)

    """
    pass


def create_cylinder_points(point1, point2, point3, name=None, color=None):
    """
    Creates a cylinder. Three points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param name: (optional) Defines the name of the new cylinder. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new cylinder. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A cylinder.
    :rtype: mimics.analyze.Cylinder
    
    :exceptions: ValueError (reason(s): ['Could not create cylinder with two points that coincide', 'Could not create cylinder with radius less than 0.0001', 'Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (0,0,0)
    	p2 = (0,0,50)
    	p3 = (400,0,0)
    	mimics.analyze.create_cylinder_points(point1=p1, point2=p2, point3=p3)

    """
    pass


def create_sphere_fit_to_surface(part, name=None, color=None):
    """
    Creates a sphere by fitting it to a surface (part).
    
    :param part: The Part.
    :type part: mimics.Part
    :param name: (optional) Defines the name of the new sphere. If not present, a default name will be set.
    :type name: str
    :param color: (optional) Defines the color of the new sphere. If not present, a default color will be set.
    :type color: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: A sphere.
    :rtype: mimics.analyze.Sphere
    
    :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)', 'Could not create sphere because its radius was too large'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	mimics.analyze.create_sphere_fit_to_surface(part = p)

    """
    pass


