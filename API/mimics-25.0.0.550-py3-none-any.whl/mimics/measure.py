import typing
import mimics


def indicate_distance_measurement(message='Please indicate two points for distance measurement.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate points for the distance measurement.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether the message box should be shown or not. If false then all other parameters are ignored
    :type show_message_box: bool
    :param confirm: (optional) If true, it displays the OK button and waits for the user to click it to confirm object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Distance Measurement.
    :rtype: mimics.measure.Distance
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate Distance 1'
    	cnfrm = False
    	tit = 'Point 1'
    	dis = mimics.measure.indicate_distance_measurement(message=msg, confirm=cnfrm, title=tit)

    """
    pass


class CenterlineCurvature(mimics.Object):
    """
    The curvature measurement at the defined point.  The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


class MeasurementValue(object):
    """
    An object with particular measurement.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value_name(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def value(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def unit(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass


def get_label_position(measurement, view):
    """
    Returns the placement of the measurement label on the specified view.
    
    :param measurement: Measurement with the label.
    :type measurement: mimics.Object
    :param view: View to work with.
    :type view: mimics.view.View
    
    :returns: Bounding box object that defines the placement.
    :rtype: mimics.BoundingBox2d
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,0,0)
    	p2 = (0,0,0)
    	p3 = (0,100,0)
    	p4 = (100,100,0)
    	l = [p1, p2, p3, p4]
    	area = mimics.measure.create_area_measurement(points=l)
    	meas = mimics.data.area_measurements[0]
    	v = "3D"
    	pos = mimics.measure.get_label_position(measurement=meas, view=mimics.data.views[v])
    	print(pos)

    """
    pass


class Angle(mimics.Object):
    """
    Angle measurement.
    """
    def get_reslice_object(self):
        """
        Reslice plane that measurement is attached to. Only mimics.view.Reslice object is supported at the moment. If the measurement is attached to the reslice object of other types - None will be returned.
        
        
        
        :returns: Referenced reslice plane.
        :rtype: typing.Optional[mimics.view.Reslice]
        """
        pass

    def set_reslice_object(self, reslice_object=None):
        """
        Measurement will be attached to the defined reslice object.
        
        :param reslice_object: (optional) Reslice object for the measurement to be attached.
        :type reslice_object: typing.Optional[typing.Union[mimics.view.Reslice, mimics.view.PanoramicReslice, mimics.view.Fluoroscopy]]
        """
        pass

    @property
    def precision(self):
        """
        :type: <class 'typing.SupportsInt'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Precision must be 0, 1 or 2'])
        """
        pass
    
    @precision.setter
    def precision(self, value):
        """
    
        """
        pass

    @property
    def is_label_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_visible.setter
    def is_label_visible(self, value):
        """
    
        """
        pass

    @property
    def is_unit_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_unit_visible.setter
    def is_unit_visible(self, value):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def center(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @center.setter
    def center(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def part_of_point1(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def part_of_center(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def part_of_point2(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def reflex_angle(self):
        """
        Specifies if the angle is acute (always less than 180 degrees) or reflex (always more than 180 degrees).
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @reflex_angle.setter
    def reflex_angle(self, value):
        """
    
        """
        pass


def create_ellipticity_measurement(centerline, point):
    """
    Creates an ellipticity of the best fit ellipse in a contour in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Ellipticity measurement on Centerline
    :rtype: mimics.measure.CenterlineEllipticity
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_ellipticity_measurement(centerline=cntrln, point=pnt)

    """
    pass


def set_label_position(measurement, view, origin):
    """
    Modifies the placement of the measurement label on the specified view.
    
    :param measurement: Measurement with the label.
    :type measurement: mimics.Object
    :param view: View to work with.
    :type view: mimics.view.View
    :param origin: 2D coordinates of the origin of the new position of the measurement label.
    :type origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,100,100)
    	p2 = (150,100,65)
    	m1 = mimics.measure.create_distance_measurement(p1,p2)
    	v = mimics.data.views[0]
    	mimics.measure.set_label_position(m1,v,(20,0))

    """
    pass


def create_triad_measurement(centerline, point):
    """
    Creates a tangent, normal and binormal vectors in a point that lies on the centerline.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Triad measurement on Centerline
    :rtype: mimics.measure.Triad
    
    :exceptions: ValueError (reason(s): ['Centerline Measurement Point should be placed directly on Centerline'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_triad_measurement(centerline=cntrln, point=pnt)

    """
    pass


class CenterlineSectionalArea(mimics.Object):
    """
    The area of the contour in a control point. The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def create_best_fit_diameter_measurement(centerline, point):
    """
    Creates a diameter of the circle that fits the best in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Best Fit Diameter Centerline measurement
    :rtype: mimics.measure.CenterlineBestFitDiameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_best_fit_diameter_measurement(centerline=cntrln, point=pnt)

    """
    pass


class CenterlineHydraulicDiameter(mimics.Object):
    """
    The hydraulic diameter of the contour in a control point. The hydraulic diameter is defined as : 4*(surface X-section area) / (circumference of the X-section). The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def create_hydraulic_ratio_measurement(centerline, point):
    """
    Creates a hydraulic ratio of a contour in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Hydraulic Ratio measurement on Centerline
    :rtype: mimics.measure.CenterlineHydraulicRatio
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_hydraulic_ratio_measurement(centerline=cntrln, point=pnt)

    """
    pass


class CenterlineHydraulicRatio(mimics.Object):
    """
    The hydraulic ratio of a contour in a control point. Hydraulic ratio is defined as the ratio of the hydraulic diameter to the subscribing diameter of the X-section. The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def indicate_angle_measurement(message='Please indicate three points for angle measurement.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate points for the angle measurement.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether the message box should be shown or not. If false then all other parameters are ignored
    :type show_message_box: bool
    :param confirm: (optional) If true, it displays the OK button and waits for the user to click it to confirm object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Angle Measurement.
    :rtype: mimics.measure.Angle
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate Angle 1'
    	cnfrm = False
    	tit = 'Point 1'
    	ang = mimics.measure.indicate_angle_measurement(message=msg, confirm=cnfrm, title=tit)

    """
    pass


def indicate_area_measurement(message='Please indicate points for the area measurement.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate points for the area measurement.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether the message box should be shown or not. If false then all other parameters are ignored
    :type show_message_box: bool
    :param confirm: (optional) If true, it displays the OK button and waits for the user to click it to confirm object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Area Measurement object.
    :rtype: mimics.measure.Area
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate Area 1'
    	cnfrm = False
    	tit = 'Point 1'
    	area = mimics.measure.indicate_area_measurement(message=msg, confirm=cnfrm, title=tit)

    """
    pass


def create_maximal_diameter_measurement(centerline, point):
    """
    Creates a diameter of the subscribing circle in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Maximal Diameter measurement on Centerline
    :rtype: mimics.measure.CenterlineMaximalDiameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_maximal_diameter_measurement(centerline=cntrln, point=pnt)

    """
    pass


class Triad(mimics.Object):
    """
    The tangent, normal and binormal vectors in a point that lies on the centerline. Color of the tangent, normal, and binormal vectors is yellow, green, and blue respectively.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def tangent(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def normal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def binormal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass


def create_angle_measurement(point1, point2, point3, part_of_point1=None, part_of_point2=None, part_of_point3=None):
    """
    Creates an angle measurement. Three points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param part_of_point1: (optional) Part of the first point.
    :type part_of_point1: mimics.Part
    :param part_of_point2: (optional) Part of the second point.
    :type part_of_point2: mimics.Part
    :param part_of_point3: (optional) Part of the third point.
    :type part_of_point3: mimics.Part
    
    :returns: Angle Measurement object.
    :rtype: mimics.measure.Angle
    
    :exceptions: ValueError (reason(s): ['Point does not lie on corresponding Part'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,0,0)
    	p2 = (0,0,0)
    	p3 = (0,100,0)
    	
    	ang = mimics.measure.create_angle_measurement(point1=p1, point2=p2, point3=p3) 
    	print(ang)

    """
    pass


def calculate_translation(part1, part2):
    """
    Calculates the translation of the inertial coordinate systems of two geometrically identical Parts.
    
    :param part1: The reference Part.
    :type part1: mimics.Part
    :param part2: The target Part.
    :type part2: mimics.Part
    
    :returns: The translation between two parts.
    :rtype: typing.Tuple[float, float, float]
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = mimics.data.parts[0]
    	p2 = mimics.data.parts[1]
    	
    	dif = mimics.measure.calculate_translation(part1=p1, part2=p2) 
    	print(dif)

    """
    pass


def create_sectional_area_measurement(centerline, point):
    """
    Creates an area of the contour in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Sectional Area measurement on Centerline
    :rtype: mimics.measure.CenterlineSectionalArea
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_sectional_area_measurement(centerline=cntrln, point=pnt)

    """
    pass


def indicate_diameter_measurement(message='Please indicate three points for diameter measurement.', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to indicate points for the diameter measurement.
    
    :param message: (optional) Description of the dialog.
    :type message: str
    :param show_message_box: (optional) Defines whether the message box should be shown or not. If false then all other parameters are ignored
    :type show_message_box: bool
    :param confirm: (optional) If true, it displays the OK button and waits for the user to click it to confirm object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Diameter Measurement.
    :rtype: mimics.measure.Diameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate Diameter 1'
    	cnfrm = False
    	tit = 'Point 1'
    	dm = mimics.measure.indicate_diameter_measurement(message=msg, confirm=cnfrm, title=tit)

    """
    pass


class CenterlineEllipticity(mimics.Object):
    """
    The ellipticity of the best fit ellipse in a contour in a control point. The control point of the measurement lies on the centerline. The center of the ellipse and the control point can be different.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def radius_major(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def radius_minor(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass


class Diameter(mimics.Object):
    """
    Diameter measurement.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def center_point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def normal(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Point cannot be moved too close to other points of Diameter.'])
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Point cannot be moved too close to other points of Diameter.'])
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def point3(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Point cannot be moved too close to other points of Diameter.'])
        """
        pass
    
    @point3.setter
    def point3(self, value):
        """
    
        """
        pass

    @property
    def part_of_point1(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def part_of_point2(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def part_of_point3(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass


class CenterlineMaximalDiameter(mimics.Object):
    """
    The diameter of the subscribing circle in a control point. The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def get_bounding_box(objects, first_axis=[1, 0, 0], second_axis=[0, 1, 0]):
    """
    Calculates a bounding box for the defined object(s).
    
    :param objects: Object(s) for which the common bounding box needs to be calculated.
    :type objects: typing.Union[mimics.Object, GenericObjectIterable]
    :param first_axis: (optional) First axis of the resulting bounding box.
    :type first_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param second_axis: (optional) Second axis of the resulting bounding box.
    :type second_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Bounding box object.
    :rtype: mimics.BoundingBox3d
    
    :exceptions: ValueError (reason(s): ['Input axes should be perpendicular.', 'Cannot calculate bounding box of a non-existing object.', 'Bounding box of an object is invalid'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	obj = mimics.data.parts[0]
    	bbox = mimics.measure.get_bounding_box(obj)
    	print(bbox)

    """
    pass


def _get_bounding_box(objects, first_axis=[1, 0, 0], second_axis=[0, 1, 0]):
    """
    Calculates bounding box for defined object(s).
    
    It calculates bounding box in coordinate system specified by 'first_axis' and 'second_axis' parameters.
    
    Axis that specify coordinate system cannot be parallel. Ideally, they have to be perpendicular.
    
    If axes are not perpendicular, 'second_axis' will be changed to stand in the same plane and make 90 degree angle with 'first_axis'.
    
    For parts it calculate honest bounding box in specified coordinate system.
    
    For other objects it calculate 'object bounding box' in object coordinate system 
    
    and returns the bounding box of 'object bounding box' in specified coordinate system.
    
    Because of this calculation for parts bounding box can lead to performance issue on huge parts.
    
    :param objects: Object(s) which bounding box will be used for zooming.
    :type objects: typing.Union[mimics.Object, GenericObjectIterable]
    :param first_axis: (optional) First axis of the resulting bounding box
    :type first_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param second_axis: (optional) Third axis of the resulting bounding box
    :type second_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Bounding box object
    :rtype: mimics.BoundingBox3d
    
    :exceptions: ValueError (reason(s): ['Input axes should be perpendicular.', 'Cannot calculate bounding box of a non-existing object.', 'Bounding box of an object is invalid'])
    """
    pass


def create_tortuosity_measurement(centerline, point1, point2):
    """
    Creates a tortuosity between two points on the centerline.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Tortuosity measurement on Centerline
    :rtype: mimics.measure.CenterlineTortuosity
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt1 = [27.449587, 9.486663, -27.842714]
    	pnt2 = [33.300992, 13.586411, -30.170290]
    	
    	mimics.measure.create_tortuosity_measurement(centerline=cntrln, point1=pnt1, point2=pnt2)

    """
    pass


def create_area_measurement(points, normal=None, reslice_object=None, snap=True):
    """
    Creates an area measurement. At least three points are required.
    
    :param points: Coordinates of the points.
    :type points: typing.Sequence[TMimicsPoint]
    :param normal: (optional) Normal to project the points on.
    :type normal: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param reslice_object: (optional) Reslice plane that measurement is attached to.
    :type reslice_object: mimics.view.Reslice
    :param snap: (optional) Indicates whether the connecting lines should be snapped to the image gradient.
    :type snap: bool
    
    :returns: Area Measurement object.
    :rtype: mimics.measure.Area
    
    :exceptions: ValueError (reason(s): ['Cannot create Area from less than 3 points.', 'Input points are not on one plane.', 'Input points are on the same line.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,0,0)
    	p2 = (0,0,0)
    	p3 = (0,100,0)
    	p4 = (100,100,0)
    	l = [p1, p2, p3, p4]
    	area = mimics.measure.create_area_measurement(points=l) 
    	print(area)

    """
    pass


def create_hydraulic_diameter_measurement(centerline, point):
    """
    Creates a hydraulic diameter of the contour in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Hydraulic Diameter measurement on Centerline
    :rtype: mimics.measure.CenterlineHydraulicDiameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_hydraulic_diameter_measurement(centerline=cntrln, point=pnt)

    """
    pass


class Area(mimics.Object):
    """
    Area measurement.
    """
    def get_reslice_object(self):
        """
        Reslice plane that measurement is attached to. Only mimics.view.Reslice object is supported at the moment. If the measurement is attached to the reslice object of other types - None will be returned.
        
        
        
        :returns: Referenced reslice plane.
        :rtype: typing.Optional[mimics.view.Reslice]
        """
        pass

    def set_reslice_object(self, reslice_object=None):
        """
        Measurement will be attached to the defined reslice object.
        
        :param reslice_object: (optional) Reslice object for the measurement to be attached.
        :type reslice_object: typing.Optional[typing.Union[mimics.view.Reslice, mimics.view.PanoramicReslice, mimics.view.Fluoroscopy]]
        """
        pass

    @property
    def points(self):
        """
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: True
        :exceptions: ValueError (reason(s): ['Point cannot be moved too close to other control point of the Area.'])
        """
        pass

    @property
    def area(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def perimeter(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def da(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def dp(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centroid(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
        :exceptions: ValueError (reason(s): ['Such value is not defined for this Area.'])
        """
        pass

    @property
    def lmax(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Such value is not defined for this Area.'])
        """
        pass

    @property
    def l_perpendicular(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Such value is not defined for this Area.'])
        """
        pass

    @property
    def l_min(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
        :exceptions: ValueError (reason(s): ['Such value is not defined for this Area.'])
        """
        pass

    @property
    def is_l_max_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_l_max_visible.setter
    def is_l_max_visible(self, value):
        """
    
        """
        pass

    @property
    def is_l_perpendicular_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_l_perpendicular_visible.setter
    def is_l_perpendicular_visible(self, value):
        """
    
        """
        pass

    @property
    def is_l_min_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_l_min_visible.setter
    def is_l_min_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_visible.setter
    def is_label_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_area_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_area_visible.setter
    def is_label_area_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_perimeter_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_perimeter_visible.setter
    def is_label_perimeter_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_da_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_da_visible.setter
    def is_label_da_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_dp_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_dp_visible.setter
    def is_label_dp_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_centroid_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_centroid_visible.setter
    def is_label_centroid_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_l_max_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_l_max_visible.setter
    def is_label_l_max_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_l_min_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_l_min_visible.setter
    def is_label_l_min_visible(self, value):
        """
    
        """
        pass

    @property
    def is_label_l_perpendicular_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_l_perpendicular_visible.setter
    def is_label_l_perpendicular_visible(self, value):
        """
    
        """
        pass

    @property
    def geometry_points(self):
        """
        :type: typing.Sequence[typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: True
    
        """
        pass


def create_diameter_measurement(point1, point2, point3, part_of_point1=None, part_of_point2=None, part_of_point3=None):
    """
    Creates a diameter measurement. Three points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point3: Coordinates of the third point.
    :type point3: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param part_of_point1: (optional) Part of the first point.
    :type part_of_point1: typing.Optional[mimics.Part]
    :param part_of_point2: (optional) Part of the second point.
    :type part_of_point2: typing.Optional[mimics.Part]
    :param part_of_point3: (optional) Part of the third point.
    :type part_of_point3: typing.Optional[mimics.Part]
    
    :returns: Diameter Measurement object.
    :rtype: mimics.measure.Diameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,0,0)
    	p2 = (0,0,0)
    	p3 = (0,100,0)
    	
    	ang = mimics.measure.create_diameter_measurement(point1=p1, point2=p2, point3=p3) 
    	print(ang)

    """
    pass


class CenterlineMinimalDiameter(mimics.Object):
    """
    The diameter of the inscribing circle in a control point. The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


class CenterlineBestFitDiameter(mimics.Object):
    """
    The diameter of the circle that fits the best in a control point. The center of the circle lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def create_circumference_measurement(centerline, point):
    """
    Creates a perimeter of a contour in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Circumference measurement on Centerline
    :rtype: mimics.measure.CenterlineCircumference
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_circumference_measurement(centerline=cntrln, point=pnt)

    """
    pass


def create_distance_measurement(point1, point2, part_of_point1=None, part_of_point2=None):
    """
    Creates a distance measurement. Two points are required.
    
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param part_of_point1: (optional) Part of the first point.
    :type part_of_point1: mimics.Part
    :param part_of_point2: (optional) Part of the second point.
    :type part_of_point2: mimics.Part
    
    :returns: Distance Measurement object.
    :rtype: mimics.measure.Distance
    
    
    :example:
    .. code-block:: python
    
    	 
    	p1 = (100,0,0)
    	p2 = (0,0,0)
    	dis = mimics.measure.create_distance_measurement(point1=p1, point2=p2) 
    	print(dis)

    """
    pass


def create_minimal_diameter_measurement(centerline, point):
    """
    Creates a diameter of the inscribing circle in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Minimal Diameter measurement on Centerline
    :rtype: mimics.measure.CenterlineMinimalDiameter
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_minimal_diameter_measurement(centerline=cntrln, point=pnt)

    """
    pass


class CenterlineCircumference(mimics.Object):
    """
    The perimeter of a contour in a control point. The control point of the measurement lies on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


def create_distance_over_centerline_measurement(centerline, point1, point2):
    """
    Creates a shortest distance between two points along the centerline.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point1: Coordinates of the first point.
    :type point1: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param point2: Coordinates of the second point.
    :type point2: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Distance Over Centerline measurement on Centerline
    :rtype: mimics.measure.DistanceOverCenterline
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt1 = [27.449587, 9.486663, -27.842714]
    	pnt2 = [33.300992, 13.586411, -30.170290]
    	
    	mimics.measure.create_distance_over_centerline_measurement(centerline=cntrln, point1=pnt1, point2=pnt2)

    """
    pass


class CenterlineTortuosity(mimics.Object):
    """
    The tortuosity between two points on the centerline. The tortuosity is defined as: T= 1 - (linear distance / distance along the branch). The control points of the measurement lie on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


class Distance(mimics.Object):
    """
    Distance measurement.
    """
    def get_reslice_object(self):
        """
        Reslice plane that measurement is attached to. Only mimics.view.Reslice object is supported at the moment. If the measurement is attached to the reslice object of other types - None will be returned.
        
        
        
        :returns: Referenced reslice plane.
        :rtype: typing.Optional[mimics.view.Reslice]
        """
        pass

    def set_reslice_object(self, reslice_object=None):
        """
        Measurement will be attached to the defined reslice object.
        
        :param reslice_object: (optional) Reslice object for the measurement to be attached.
        :type reslice_object: typing.Optional[typing.Union[mimics.view.Reslice, mimics.view.PanoramicReslice, mimics.view.Fluoroscopy]]
        """
        pass

    @property
    def precision(self):
        """
        :type: <class 'typing.SupportsInt'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['Precision must be 0, 1 or 2'])
        """
        pass
    
    @precision.setter
    def precision(self, value):
        """
    
        """
        pass

    @property
    def is_label_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_label_visible.setter
    def is_label_visible(self, value):
        """
    
        """
        pass

    @property
    def is_unit_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @is_unit_visible.setter
    def is_unit_visible(self, value):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point1.setter
    def point1(self, value):
        """
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @point2.setter
    def point2(self, value):
        """
    
        """
        pass

    @property
    def part_of_point1(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass

    @property
    def part_of_point2(self):
        """
        :type: typing.Union[mimics.Part, NoneType]
        :read-only: True
    
        """
        pass


def create_curvature_measurement(centerline, point):
    """
    Creates a curvature measurement in a control point.
    
    :param centerline: The Centerline.
    :type centerline: mimics.analyze.Centerline
    :param point: A point of the centerline where the measurement is created.
    :type point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    :returns: Curvature measurement on Centerline
    :rtype: mimics.measure.CenterlineCurvature
    
    
    :example:
    .. code-block:: python
    
    	 
    	cntrln = mimics.data.centerlines[0]
    	pnt = [27.177012, 8.756953, -28.053557]
    	mimics.measure.create_curvature_measurement(centerline=cntrln, point=pnt)

    """
    pass


class DistanceOverCenterline(mimics.Object):
    """
    The shortest distance between two points along the centerline. The control points of the measurement lie on the centerline.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def centerline(self):
        """
        :type: <class 'mimics.analyze.Centerline'>
        :read-only: True
    
        """
        pass

    @property
    def point1(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def point2(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


