class NotSpecifiedType(object):
    """
    Used by some methods as default argument
    """
    pass



class Object(object):
    """
    Object is a general term to describe a structure in Mimics. It contains common properties for all child classes.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def name(self):
        """
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @name.setter
    def name(self, value):
        """
    
        """
        pass

    @property
    def color(self):
        """
        :type: typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Each color component should be in range 0..1', 'Tuple should contain 3 elements(RGB)'])
        """
        pass
    
    @color.setter
    def color(self, value):
        """
    
        """
        pass

    @property
    def visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @visible.setter
    def visible(self, value):
        """
    
        """
        pass

    @property
    def selected(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @selected.setter
    def selected(self, value):
        """
    
        """
        pass

    @property
    def guid(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def metadata(self):
        """
        :type: <class 'mimics.Metadata'>
        :read-only: True
    
        """
        pass

    @property
    def image(self):
        """
        :type: typing.Union[mimics.ImageData, NoneType]
        :read-only: False
    
        """
        pass
    
    @image.setter
    def image(self, value):
        """
    
        """
        pass




import mimics
setattr(mimics, "NOT_SPECIFIED", NotSpecifiedType())
import typing
import mimics

from . import align
from . import analyze
from . import cineloop
from . import dialogs
from . import dicom
from . import events
from . import experimental
from . import fea
from . import file
from . import image
from . import logging
from . import measure
from . import preferences
from . import segment
from . import simulate
from . import tools
from . import utils
from . import view

class UserInterrupted(Exception):
    def __init__(self, message):
        super().__init__(message)


class ProjectNotLoaded(Exception):
    def __init__(self, message):
        super().__init__(message)


class OperationBlocked(Exception):
    def __init__(self, message):
        super().__init__(message)


class NoUIAvailable(Exception):
    def __init__(self, message):
        super().__init__(message)


class LicenseError(Exception):
    def __init__(self, message):
        super().__init__(message)


def is_update_gui_enabled():
    """
    Returns True (by default) if the continuous update of the Mimics UI and events/messages processing after every API call for the current session is on and False otherwise. This behavior can be managed by calling mimics.disable_update_gui() and mimics.enable_update_gui() APIs.
    
    See also: 'mimics.enable_update_gui()', 'mimics.disable_update_gui()', 'mimics.disabled_gui_update()', 'mimics.update_gui()'
    
    :returns: State of continuous UI updates.
    :rtype: bool
    
    
    :example:
    .. code-block:: python
    
    	 
    	# Notes:
    	#  1. Find a more detailed examples in the documentation for mimics.disable_update_gui() API.
    	
    	import mimics
    	
    	
    	name = "with a context manager"
    	print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # True
    	with mimics.disabled_gui_update():
    	    print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # False
    	    print("doing computations...")
    	print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # True
    	
    	
    	name = "using direct APIs"
    	print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # True
    	mimics.disable_update_gui()
    	try:
    	    print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # False
    	    print("doing computations...")
    	finally:
    	    # it is important to enable it back
    	    # otherwise, the updating subsystem will be corrupted.
    	    # for safety reasons, consider using a context manager 'with mimics.disabled_gui_update()'.
    	    mimics.enable_update_gui()
    	print(f"gui update status ({name}): {mimics.is_update_gui_enabled()}")  # True

    """
    pass


def disable_update_gui():
    """
    Turns off the continuous period updates of the Mimics UI and events/messages processing after every API call, for the current session. By default, UI update is on. You can use it to speed up the runtime of scripts in case you don't require visual feedback through the UI, e.g. when running loops or calculation scripts. You can switch the UI update back on in the same session or script by calling 'mimics.enable_update_gui()' or use the context manager 'mimics.disabled_gui_update()' instead of both APIs. Experienced users can manage UI update manually by calling 'mimics.disable_update_gui()' at the start of a script and then explicitly calling 'mimics.update_gui()' only when needed.
    
    See also: 'mimics.enable_update_gui()', 'mimics.disabled_gui_update()', 'mimics.update_gui()', 'mimics.is_update_gui_enabled()'
    
    
    :example:
    .. code-block:: python
    
    	 
    	import mimics
    	import time
    	
    	
    	def demo_updates(force_an_update: bool):
    	    print(f"{'=' * 25}: {force_an_update}")
    	    
    	    mimics.disable_update_gui()
    	    try:
    	        print("Some prints() statements in the outer try.")
    	        time.sleep(1)
    	        
    	        mimics.disable_update_gui()  # recursive call are supported
    	        try:
    	            print("Some prints() statements in the inner try.")
    	            time.sleep(1)
    	            if force_an_update:
    	                print("But we force everything to printed immediately.")
    	                mimics.update_gui()
    	        finally:
    	            mimics.enable_update_gui()
    	    finally:
    	        # it is important to enable it back
    	        # otherwise, the updating subsystem will be corrupted.
    	        # for safety reasons, consider using a context manager 'with mimics.disabled_gui_update()'.
    	        mimics.enable_update_gui()
    	
    	    time.sleep(3)
    	    print("finished.")
    	
    	
    	demo_updates(False)
    	demo_updates(True)

    """
    pass


def enable_update_gui():
    """
    Turns on the continuous periodic updates of the Mimics UI and events/messages processing after every API call in case it was previously turned off, e.g. by calling 'mimics.disable_update_gui()'. By default, UI update is on. The frequency of updates is ~5 timers per second.
    
    See also: 'mimics.disable_update_gui()', 'mimics.disabled_gui_update()', 'mimics.update_gui', 'mimics.is_update_gui_enabled()'
    
    
    :example:
    .. code-block:: python
    
    	 
    	# Notes:
    	#  1. Find a more detailed examples in the documentation for mimics.disable_update_gui() API.
    	
    	import mimics
    	
    	mimics.disable_update_gui()
    	try:
    	    print("doing computations...")
    	finally:
    	    # it is important to enable it back
    	    # otherwise, the updating subsystem will be corrupted.
    	    # for safety reasons, consider using a context manager 'with mimics.disabled_gui_update()'.
    	    mimics.enable_update_gui()

    """
    pass


def disabled_gui_update():
    """
    A context manager that will call 'mimics.disable_update_gui()' before the execution of the context script and will call 'mimics.enable_update_gui()' afterwards. This will turn off the continuous update of the Mimics UI and event\message processing after every API call during script execution and will turn it on (return to default settings) afterwards. You can use this to achieve a speedup in script execution times.
    
    See also: 'mimics.enable_update_gui()', 'mimics.disable_update_gui()', 'mimics.update_gui()', 'mimics.is_update_gui_enabled()'
    
    
    :example:
    .. code-block:: python
    
    	 
    	# This example illustrates effect of different update policies:
    	# 1. default option - enabled PERIODICAL updates (this is a balanced option)
    	# 2. disabling updates - balance is tiled towards the speed (sacrificing updating the user)
    	# 3. forcing (frequent) updates - balance is tiled towards updating the GUI (sacrificing the speed).
    	#    This illustrates that too frequent GUI updates may degrade the performance of the scrip.
    	#    So, it shall be used in situations when the user really needs to be updated frequently,
    	#    otherwise use default option #1 - the default one.
    	
    	import mimics
    	import time
    	
    	
    	NUM_ITERATIONS = 100
    	measurements = {}
    	
    	
    	def process(force_updates: bool, num_iterations: int):
    	    for i in range(num_iterations):
    	        print(f" - iteration: {i} we add some text to make it heavier to handle")
    	        if force_updates:
    	            mimics.update_gui()
    	
    	
    	start = time.perf_counter()
    	process(force_updates=False, num_iterations=NUM_ITERATIONS)
    	measurements["Option.1 - default"] = time.perf_counter() - start
    	
    	start = time.perf_counter()
    	with mimics.disabled_gui_update():
    	    process(force_updates=False, num_iterations=NUM_ITERATIONS)
    	measurements["Option.2 - disabling updates"] = time.perf_counter() - start
    	
    	start = time.perf_counter()
    	factor = 200
    	with mimics.disabled_gui_update():
    	    process(force_updates=True, num_iterations=NUM_ITERATIONS // factor)
    	measurements["Option.3 - forcing frequent updates"] = (time.perf_counter() - start) * factor
    	
    	
    	print(f"Measurement results for {NUM_ITERATIONS} iterations:")
    	for k, v in measurements.items():
    	    print(f" - {k}: {round(v, 1)} seconds")
    	
    	# The output for 10 000 iterations can be like (depends on the performance of the PC):
    	#    Measurement results for 10000 iterations:
    	#    - Option.1 - default: 2.9 seconds
    	#    - Option.2 - disabling updates: 2.0 seconds
    	#    - Option.3 - forcing frequent updates: 1087.1 seconds

    """
    pass


def update_gui():
    """
    Forces the application to repaint (if some repainintg were pending) and to process all pending events/messages until there are no more events/messages to process. You can call this function occasionally when your script is performing a long operation (e.g. copying a file) to keep the application responsive. Available events are events queued before the function call. This means that events that are posted while the script/API runs will be queued until a later round of event processing. 
    
    See also: 'mimics.enable_update_gui()', 'mimics.disable_update_gui()', 'mimics.disabled_gui_update()' , 'mimics.is_update_gui_enabled()'
    
    
    :example:
    .. code-block:: python
    
    	 
    	# This sample illustrates the following approach:
    	# * we have the script runs several extensive computations that update the views a lot,
    	#   by for instance, modifying many objects.
    	#   in the example below, these actions are 'simulated' with sleep() calls.
    	# * the updates take time, so, in order to speed-up, we disable GUI update which
    	#   is done with a context manager Python syntax.
    	# * but, keeping the screen frozen for TOO long, might make a wrong impression on the user,
    	#   thus, to prevent it, we call updates (at specific moments) to entertain the user by
    	#   showing progress
    	
    	import time
    	import mimics
    	
    	
    	def do_heavy_computation(name: str, duration_in_sec: float) -> None:
    	    print("=" * 50)    
    	    i = 0
    	    finish_time = time.perf_counter() + duration_in_sec
    	    while time.perf_counter() < finish_time:
    	        i += 1
    	        print(f"{name}: {i}")
    	        time.sleep(0.2)
    	
    	
    	# Start of a sequence of heavy computation and update the user from time to time.
    	# This will print output in 3 batches. # Note, that removing 'with mimics.disabled_gui_update()'
    	# will result in print more often (see comments for disabled_gui_update()).
    	with mimics.disabled_gui_update():
    	    do_heavy_computation("Section.1", 1)
    	    mimics.update_gui()  # let the user see results of Section.1
    	
    	    do_heavy_computation("Section.2", 2)
    	    mimics.update_gui()  # let the user see results of Section.2
    	
    	    do_heavy_computation("Section.3", 2)
    	    mimics.update_gui()  # let the user see results of Section.3

    """
    pass


class _Transaction(object):
    """
    Object is a general term to describe a structure in Mimics. It contains common properties for all child classes.
    """
    def commit(self):
        """
        Commits transaction
        
    
        """
        pass

    def rollback(self):
        """
        Rollbacks transaction
        
    
        """
        pass

    @property
    def is_open(self):
        """
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass


class _ObjectCoordinateSystem(object):
    """
    Coordinate system of an Object.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def x_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def y_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass

    @property
    def z_axis(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
    
        """
        pass


class BoundingBox2d(object):
    """
    2D bounding box, dedicated for the screen coordinates.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def origin(self):
        """
        :type: typing.Tuple[int, int]
        :read-only: False
    
        """
        pass
    
    @origin.setter
    def origin(self, value):
        """
    
        """
        pass

    @property
    def width(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @width.setter
    def width(self, value):
        """
    
        """
        pass

    @property
    def height(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @height.setter
    def height(self, value):
        """
    
        """
        pass


def create_transformation(matrix):
    """
    Creates a new rigid transformation with corresponding matrix.
    
    :param matrix: Rigid 4x4 transformation matrix.
    :type matrix: typing.Iterable[typing.Iterable[typing.SupportsFloat]]
    
    :returns: New transformation object.
    :rtype: mimics.Transformation
    
    :exceptions: ValueError (reason(s): ['Matrix should contain 4 rows', 'Matrix should contain 4 columns', 'The transformation cannot be created. Only rigid transformations can be created.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	t = [[1.0, 0.0, 0.0, 5.0], [0.0, 0.0, -1.0, 10.5], [0.0, 1.0, 0.0, -20.0], [0.0, 0.0, 0.0, 1.0]]
    	mimics.create_transformation(matrix=t)

    """
    pass


class UserInterrupted(object):
    """
    An exception that is raised when a running script is interrupted by the user, for example by calling the 'mimics.cancel_active_tool()' API.
    """
    pass


class BoundingBox3d(object):
    """
    3D bounding box, dedicated for the spatial coordinates.
    """
    def __init__(self, origin=[0, 0, 0], first_vector=[0, 0, 0], second_vector=[0, 0, 0], third_vector=[0, 0, 0]):
        """
        :param origin: (optional) 
        :type origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :param first_vector: (optional) 
        :type first_vector: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :param second_vector: (optional) 
        :type second_vector: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :param third_vector: (optional) 
        :type third_vector: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        """
        pass

    @property
    def origin(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @origin.setter
    def origin(self, value):
        """
    
        """
        pass

    @property
    def first_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @first_vector.setter
    def first_vector(self, value):
        """
    
        """
        pass

    @property
    def second_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @second_vector.setter
    def second_vector(self, value):
        """
    
        """
        pass

    @property
    def third_vector(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: False
    
        """
        pass
    
    @third_vector.setter
    def third_vector(self, value):
        """
    
        """
        pass


class Transformation(Object):
    """
    Object that represents transformation in patient coordinate system
    """
    def invert(self):
        """
        Invert this transformation
        
        
        
        :exceptions: RuntimeError (reason(s): ['Cannot access the Transformation object. Probably it was removed'])
        """
        pass

    @property
    def rotation(self):
        """
        Rotation angles in degrees around the three axes
        
        :type: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :read-only: True
        :exceptions: RuntimeError (reason(s): ['Cannot access the Transformation object. Probably it was removed'])
        """
        pass

    @property
    def translation(self):
        """
        Translation along the three axes
        
        :type: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        :read-only: True
        :exceptions: RuntimeError (reason(s): ['Cannot access the Transformation object. Probably it was removed'])
        """
        pass

    @property
    def matrix(self):
        """
        Transformation matrix as a matrix 4x4
        
        :type: typing.List[typing.List[typing.SupportsFloat]]
        :read-only: True
        :exceptions: RuntimeError (reason(s): ['Cannot access the Transformation object. Probably it was removed'])
        """
        pass


class Part(Object):
    """
    A Part is a 3D object.
    """
    def get_triangles(self):
        """
        Returns triangles surface - tuple of vertices (3D coordinates) and triangles (combination of vertices that creates it).
        
        
        
        :returns: Tuple of two memoryviews of floats.
        :rtype: typing.Tuple[memoryview, memoryview]
        
        :exceptions: ValueError (reason(s): ['Could not create memoryview - STL contains no vertices/triangles'])
        """
        pass

    def get_vertices(self):
        """
        Returns the list of coordinates of this part's vertices.
        
        
        
        :returns: memoryview of floats
        :rtype: memoryview
        
        :exceptions: ValueError (reason(s): ['Could not create memoryview - STL contains no vertices/triangles'])
        """
        pass

    def get_active_color_mask(self):
        """
        Returns an active color mask - array of colors (rgb values in the range [0 .. 1]), per vertex per triangle (the order is aligned with get_triangles output).
        
        
        
        :returns: memoryview of floats
        :rtype: memoryview
        
        :exceptions: ValueError (reason(s): ['Could not create memoryview - STL has no active color mask', 'Could not create memoryview - the active color mask is empty'])
        """
        pass

    @property
    def type(self):
        """
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @type.setter
    def type(self, value):
        """
    
        """
        pass

    @property
    def transparency(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['The transparency value must be in the range 0.0-1.0.'])
        """
        pass
    
    @transparency.setter
    def transparency(self, value):
        """
    
        """
        pass

    @property
    def contours_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @contours_visible.setter
    def contours_visible(self, value):
        """
    
        """
        pass

    @property
    def triangles_visible(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @triangles_visible.setter
    def triangles_visible(self, value):
        """
    
        """
        pass

    @property
    def quality(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def number_of_triangles(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def number_of_points(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def dimension_min(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
        :exceptions: ValueError (reason(s): ['Could not get min point of bounding box - STL is invalid or empty'])
        """
        pass

    @property
    def dimension_max(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]
        :read-only: True
        :exceptions: ValueError (reason(s): ['Could not get max point of bounding box - STL is invalid or empty'])
        """
        pass

    @property
    def volume(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def surface_area(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def dimension_delta(self):
        """
        :type: typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Line, mimics.analyze.Cylinder]
        :read-only: True
        :exceptions: ValueError (reason(s): ['Could not get delta of bounding box - STL is invalid or empty'])
        """
        pass

    @property
    def visualization(self):
        """
        :type: <class 'str'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['This visualization type is not assigned yet']), RuntimeError (reason(s): ['Setting this visualization option is not permitted'])
        """
        pass
    
    @visualization.setter
    def visualization(self, value):
        """
    
        """
        pass

    @property
    def color_scheme(self):
        """
        Returns color scheme which was used for Vertex color visualization: preset name (string), sensitivity (float in range from 0.0 to 4.0), array of pairs of pixel intensity (integer values) and corresponding color (rgb values in the range [0 .. 1])
        
        :type: typing.Union[typing.Tuple[str, float, typing.Dict[int, typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]]], NoneType]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Sensitivity value should be in range 0..4.0', 'Scheme should contain at least two values', 'Each color component should be in range 0..1', 'Intensity values should be in image data gray value range']), RuntimeError (reason(s): ['Color scheme can be defined for an object assigned to active image stack only', "Editing object's color scheme is not permitted"])
        """
        pass
    
    @color_scheme.setter
    def color_scheme(self, value):
        """
    
        """
        pass


def transform_objects(objects, transformation):
    """
    Transforms provided object(s) with transformation object.
    
    :param objects: Object or container of objects to transform.
    :type objects: typing.Union[typing.Iterable[typing.Union[mimics.Part, mimics.analyze.Point, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Plane, mimics.analyze.Centerline, mimics.Osteotomy]], typing.Union[mimics.Part, mimics.analyze.Point, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Plane, mimics.analyze.Centerline, mimics.Osteotomy]]
    :param transformation: Transformation object.
    :type transformation: mimics.Transformation
    
    :exceptions: ValueError (reason(s): ['Provided transformation cannot be empty'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	p = mimics.data.parts[0]
    	t = mimics.data.transformations[0]
    	mimics.transform_objects(objects=p, transformation=t)

    """
    pass


def _transform_objects(objects, transformation):
    """
    Transforms provided objects with transformation object.
    
    :param objects: Container of objects to transform.
    :type objects: typing.Iterable[typing.Union[mimics.Part, mimics.analyze.Point, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Sphere, mimics.analyze.Cylinder, mimics.analyze.Spline, mimics.analyze.Plane, mimics.analyze.Centerline, mimics.Osteotomy]]
    :param transformation: Transformation object.
    :type transformation: mimics.Transformation
    
    :exceptions: ValueError (reason(s): ['Provided transformation cannot be empty'])
    """
    pass


class LicenseError(object):
    """
    An exception that is raised when calling an API without access to the necessary license module. Consult the specific exception text in the Mimics log for information about the missing license(s).
    """
    pass


class OperationBlocked(object):
    """
    An exception that is raised when the user calls an API that cannot be executed because an underlying functionality is blocked (disabled or unavalable) due to the current application state. For instance, mimics.gui.perform_action() throws this exception if the requested action is disabled
    """
    pass


class ContrastFunctionObject(object):
    """
    Contains the lower and upper contrast points.
    """
    def __init__(self, lower_point=[0, 0.0], upper_point=[0, 0.0]):
        """
        :param lower_point: (optional) 
        :type lower_point: typing.Tuple[int, float]
        :param upper_point: (optional) 
        :type upper_point: typing.Tuple[int, float]
        """
        pass

    @property
    def lower_point(self):
        """
        :type: typing.Tuple[int, float]
        :read-only: False
    
        """
        pass
    
    @lower_point.setter
    def lower_point(self, value):
        """
    
        """
        pass

    @property
    def upper_point(self):
        """
        :type: typing.Tuple[int, float]
        :read-only: False
    
        """
        pass
    
    @upper_point.setter
    def upper_point(self, value):
        """
    
        """
        pass


class Metadata(object):
    """
    Container which contains metadata for specific object.
    """
    def __getitem__(self, key):
        """
        :param key: 
        :type key: typing.Union[int, str]
        
        :returns: Single metadata item which corresponds to the key criteria.
        :rtype: mimics.MetadataItem
        
        :exceptions: KeyError (reason(s): ['There is no metadata item with specified name', 'Metadata item with specified name is found more than once'])
        """
        pass

    def __len__(self):
        """
        
        
        :returns: Number of elements in the container.
        :rtype: int
        """
        pass

    def filter(self, expression, regex=False):
        """
        Filters container`s elements.
        
        :param expression: Expression matching the name of the metadata item
        :type expression: str
        :param regex: (optional) Defines whether expression is a regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: A list of metadata item names of which correspond to the regular expression shall be returned. In case of no object with such name an empty list should be returned.
        :rtype: typing.List[mimics.MetadataItem]
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def find(self, name, regex=False):
        """
        Finds the metadata item by name.
        
        :param name: Metadata item`s name.
        :type name: str
        :param regex: (optional) Defines whether name is regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: If exactly one metadata item in the container has the defined name, the item shall be returned. If more than one metadata item in the container has the defined name, only the first one shall be returned. In case of no metadata item in the container has the defined name, the built-in Python constant None shall be returned.
        :rtype: mimics.MetadataItem
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def create(self, name, value):
        """
        Creates new metadata item with provided name and value.
        
        :param name: Metadata item`s name.
        :type name: str
        :param value: Metadata item`s value.
        :type value: str
        """
        pass

    def delete(self, items):
        """
        Deletes first metadata item with provided name if it exists.
        
        :param items: Metadata items to be deleted.
        :type items: typing.Union[typing.Iterable[mimics.MetadataItem], mimics.Metadata, mimics.MetadataItem, str]
        """
        pass




class ProjectNotLoaded(object):
    """
    When Mimics is launched from the executable, there is no project loaded into Mimics by default. An exception is raised when attempting to access project-dependent functionality without a project loaded in Mimics. Open a project in Mimics to continue.
    """
    pass


class MetadataItem(object):
    """
    Metadata items has name and value.
    """
    def __eq__(self, operand):
        """
        :param operand: 
        :type operand: mimics.MetadataItem
        """
        pass

    @property
    def name(self):
        """
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @name.setter
    def name(self, value):
        """
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @value.setter
    def value(self, value):
        """
    
        """
        pass


class NoUIAvailable(object):
    """
    An exception that is raised when a script running in the background mode attempts to call a UI-dependent API. Such APIs, most likely from mimics.view module, can only be called in the foreground mode. For more information about running scripts in the background mode, please consult section 'Execute Mimics and scripts from Windows Command Prompt' of the Scripting Guide.
    """
    pass


class Osteotomy(Object):
    """
    Osteotomy - object that used for bone cut in CMF workflow.
    """
    def get_representation(self):
        """
        Returns triangles surface - tuple of vertices (3D coordinates), triangles (vertices indices for triangle) and labels.
        
        
        
        :returns: Tuple of three memoryviews (point coordinates, triangle points indices, triangle labels).
        :rtype: typing.Optional[typing.Tuple[memoryview, memoryview, memoryview]]
        
        :exceptions: ValueError (reason(s): ['Could not create memoryview - STL contains no vertices/triangles.'])
        """
        pass

    def set_pending_thickness(self, thickness):
        """
        Update the osteotomy pending thickness. Force object to be recomputed. If corresponding recompute is not possible - the object will became "dirty" and osteotomy geometry will not change.
        
        :param thickness: New osteotomy thickness.
        :type thickness: typing.SupportsFloat
        
        :exceptions: ValueError (reason(s): ['Invalid thickness value. The thickness value must be greater than or equal to 0.001.'])
        """
        pass

    def set_pending_handler(self, handler_id, coordinate):
        """
        Moves osteotomy handler with handler_id to new coordinate. Force object to be recomputed. If corresponding recompute is not possible - the object will became "dirty" and osteotomy geometry will not change.
        
        :param handler_id: Identifier of the osteotomy handler to be updated.
        :type handler_id: str
        :param coordinate: New coordinate of the osteotomy handler to be updated.
        :type coordinate: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :exceptions: KeyError (reason(s): ['The handler does not exist.']), ValueError (reason(s): ['The osteotomy object already has a pending handler, and the new pending handler cannot be applied until the object is updated.'])
        """
        pass

    def update(self, vertices, triangles, surfaces, handlers=None, thickness=None):
        """
        Updates internal representation of osteotomy with provided data.
        
        :param vertices: Memoryview of floats with the stored vertices coordinates data inside.
        :type vertices: memoryview
        :param triangles: Memoryview with the stored triangles (combination of 3 vertices that creates triangle).
        :type triangles: memoryview
        :param surfaces: Memoryview that tells which surface triangle belongs to.
        :type surfaces: memoryview
        :param handlers: (optional) Updated handlers coordinates for osteotomty.
        :type handlers: typing.Optional[typing.Dict[str, TMimicsPoint]]
        :param thickness: (optional) Osteotomy thickness.
        :type thickness: typing.Optional[typing.SupportsFloat]
        """
        pass

    @property
    def contours_visible(self):
        """
        The visibility of osteotomy object contours on 2D views
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @contours_visible.setter
    def contours_visible(self, value):
        """
    
        """
        pass

    @property
    def handler_coordinates(self):
        """
        The osteotomy object handlers in patient coordinate system.
        
        :type: typing.Dict[str, typing.Union[typing.Iterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat], mimics.analyze.Point, mimics.analyze.Sphere]]
        :read-only: True
    
        """
        pass

    @property
    def has_pending_changes(self):
        """
        Returns true if object has pending thickness or handler changes and the STL representation should be updated.
        
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass

    @property
    def osteotomy_type(self):
        """
        The osteotomy object type.
        
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def thickness(self):
        """
        The osteotomy object thickness.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def transparency(self):
        """
        The osteotomy object transparency.
        
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
        :exceptions: ValueError (reason(s): ['The transparency value must be in the range 0.0-1.0.'])
        """
        pass
    
    @transparency.setter
    def transparency(self, value):
        """
    
        """
        pass

    @property
    def triangles_visible(self):
        """
        The highlighting of triangles on 3D views.
        
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @triangles_visible.setter
    def triangles_visible(self, value):
        """
    
        """
        pass

    @property
    def _pending_thickness(self):
        """
        The osteotomy object pending thickness.
        
        :type: typing.Union[typing.SupportsFloat, NoneType]
        :read-only: False
        :exceptions: ValueError (reason(s): ['Invalid thickness value. The thickness value must be greater than or equal to 0.001.'])
        """
        pass
    
    @_pending_thickness.setter
    def _pending_thickness(self, value):
        """
    
        """
        pass


class DataContainer(object):
    """
    Flat container which contains all application objects.
    """
    def __getitem__(self, key):
        """
        .
        
        :param key: 
        :type key: typing.Union[int, str]
        
        :returns: Single object which corresponds to the key criteria.
        :rtype: mimics.Object
        
        :exceptions: KeyError (reason(s): ['There is no object with specified name', 'Object with specified name is found more than once'])
        """
        pass

    def __len__(self):
        """
        .
        
        
        
        :returns: Number of elements in the container.
        :rtype: int
        """
        pass

    def filter(self, expression, regex=False):
        """
        Filters container`s elements.
        
        :param expression: Expression matching the name of the object.
        :type expression: str
        :param regex: (optional) Defines whether expression is a regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: A list of objects names of which correspond to the regular expression shall be returned. In case of no object with such name an empty list should be returned.
        :rtype: typing.List[mimics.Object]
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def find(self, name, regex=False):
        """
        Finds the object by name.
        
        :param name: Object's name.
        :type name: str
        :param regex: (optional) Defines whether name is regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: If exactly one object in the container has the defined name, the object shall be returned. If more than one object in the container has the defined name, only the first of these objects shall be returned. In case of no object in the container has the defined name, the built-in Python constant None shall be returned.
        :rtype: mimics.Object
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def move_objects(self, target_index_position, objects):
        """
        Changes native objects order.
        
        :param target_index_position: New container position for the first of the provided objects.
        :type target_index_position: int
        :param objects: Objects to be reordered.
        :type objects: typing.Union[typing.Iterable[mimics.Object], mimics.Object, mimics.DataContainer]
        """
        pass

    def delete(self, objects):
        """
        Removes the object.
        
        :param objects: Objects to be deleted.
        :type objects: typing.Union[typing.Iterable[mimics.Object], mimics.Object, mimics.DataContainer]
        """
        pass

    def __delitem__(self, key):
        """
        Removes the object by name or index.
        
        :param key: Name or index of the object.
        :type key: typing.Union[int, str]
        
        :exceptions: ValueError (reason(s): ['There is no object with specified name', 'Object with specified name is found more than once'])
        """
        pass

    def duplicate(self, object):
        """
        Duplicates the object.
        
        :param object: Object to be duplicated.
        :type object: mimics.Object
        
        :returns: A copy of the defined object.
        :rtype: mimics.Object
        
        :exceptions: RuntimeError (reason(s): ['Could not duplicate this object. It may be due to the fact that object is non-copiable (e.g. mimics.ImageData).'])
        """
        pass




class ViewsContainer(object):
    """
    Flat container which contains all views.
    """
    def __getitem__(self, key):
        """
        .
        
        :param key: Can be: index[0], string['Axial'], pair['Axial', image_data], tuple['Axial', image_data, reslice_plane]
        :type key: typing.Union[int, str, typing.Tuple[typing.Union[str, mimics.NotSpecifiedType], typing.Union[mimics.ImageData, None, mimics.NotSpecifiedType]], typing.Tuple[typing.Union[str, mimics.NotSpecifiedType], typing.Union[mimics.ImageData, None, mimics.NotSpecifiedType], typing.Union[mimics.view.Reslice, None,mimics.NotSpecifiedType]]]
        
        :returns: Single view which corresponds to the key criteria.
        :rtype: mimics.view.View
        
        :exceptions: KeyError (reason(s): ['Wrong key. Few strings', "Wrong key. Few ImageData's", "Wrong key. Few ReslicePlane's", 'There is no object with specified name', 'Key is out of range', 'Object with specified name is found more than once']), TypeError (reason(s): ['Object cannot be converted to a required type'])
        """
        pass

    def __len__(self):
        """
        .
        
        
        
        :returns: Number of elements in the container.
        :rtype: int
        """
        pass

    def filter(self, expression=None, image_data=mimics.NOT_SPECIFIED, reslice_plane=mimics.NOT_SPECIFIED, regex=False):
        """
        Filters container`s elements.
        
        :param expression: (optional) Expression matching the name of the view.
        :type expression: typing.Union[str, mimics.NotSpecifiedType]
        :param image_data: (optional) Image data related to the view.
        :type image_data: typing.Union[mimics.ImageData, None, mimics.NotSpecifiedType]
        :param reslice_plane: (optional) Reslice plane related to the view.
        :type reslice_plane: typing.Union[mimics.view.Reslice, None, mimics.NotSpecifiedType]
        :param regex: (optional) Defines whether expression is a regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: A list of objects names of which correspond to the regular expression shall be returned. In case of no object with such name an empty list should be returned.
        :rtype: typing.List[mimics.view.View]
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid']), KeyError (reason(s): ['Wrong key. Few strings', "Wrong key. Few ImageData's", "Wrong key. Few ReslicePlane's"])
        """
        pass

    def find(self, name=mimics.NOT_SPECIFIED, image_data=mimics.NOT_SPECIFIED, reslice_plane=mimics.NOT_SPECIFIED, regex=False):
        """
        Finds the object by name.
        
        :param name: (optional) View`s name.
        :type name: typing.Union[str, mimics.NotSpecifiedType]
        :param image_data: (optional) Image data related to the view.
        :type image_data: typing.Union[mimics.ImageData, None, mimics.NotSpecifiedType]
        :param reslice_plane: (optional) Reslice plane related to the view.
        :type reslice_plane: typing.Union[mimics.view.Reslice, None, mimics.NotSpecifiedType]
        :param regex: (optional) Defines whether name is regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: If exactly one object in the container has the defined name, the object shall be returned. If more than one object in the container has the defined name, only the first of these objects shall be returned. In case of no object in the container has the defined name, the built-in Python constant None shall be returned.
        :rtype: mimics.view.View
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid']), KeyError (reason(s): ['Wrong key. Few strings', "Wrong key. Few ImageData's", "Wrong key. Few ReslicePlane's"])
        """
        pass




class ImagesContainer(object):
    """
    Flat container which contains all image data objects.
    """
    def __getitem__(self, key):
        """
        .
        
        :param key: 
        :type key: typing.Union[int, str]
        
        :returns: Single object which corresponds to the key criteria.
        :rtype: mimics.Object
        
        :exceptions: KeyError (reason(s): ['There is no object with specified name', 'Object with specified name is found more than once'])
        """
        pass

    def __len__(self):
        """
        .
        
        
        
        :returns: Number of elements in the container.
        :rtype: int
        """
        pass

    def filter(self, expression, regex=False):
        """
        Filters container`s elements.
        
        :param expression: Expression matching the name of the object.
        :type expression: str
        :param regex: (optional) Defines whether expression is a regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: A list of objects names of which correspond to the regular expression shall be returned. In case of no object with such name an empty list should be returned.
        :rtype: typing.List[mimics.Object]
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def find(self, name, regex=False):
        """
        Finds the object by name.
        
        :param name: Object's name.
        :type name: str
        :param regex: (optional) Defines whether name is regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: If exactly one object in the container has the defined name, the object shall be returned. If more than one object in the container has the defined name, only the first of these objects shall be returned. In case of no object in the container has the defined name, the built-in Python constant None shall be returned.
        :rtype: mimics.Object
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def move_objects(self, target_index_position, objects):
        """
        Changes native objects order.
        
        :param target_index_position: New container position for the first of the provided objects.
        :type target_index_position: int
        :param objects: Objects to be reordered.
        :type objects: typing.Union[typing.Iterable[mimics.Object], mimics.Object, mimics.DataContainer]
        """
        pass

    def reset_sorting(self):
        """
        Restore the original order of images within each study. 
        
        
        
        :exceptions: TypeError (reason(s): ['Object cannot be converted to a required type'])
        """
        pass

    def delete(self, objects):
        """
        Removes the object.
        
        :param objects: Objects to be deleted.
        :type objects: typing.Union[typing.Iterable[mimics.Object], mimics.Object, mimics.DataContainer]
        """
        pass

    def __delitem__(self, key):
        """
        Removes the object by name or index.
        
        :param key: Name or index of the object.
        :type key: typing.Union[int, str]
        
        :exceptions: ValueError (reason(s): ['There is no object with specified name', 'Object with specified name is found more than once'])
        """
        pass

    def duplicate(self, object):
        """
        mimics.ImageData objects cannot be duplicated via API. To produce a copy of a certain mimics.ImageData object, you can (export and) re-import DICOM images of the mimics.ImageData object in question.
        
        :param object: Object to be duplicated.
        :type object: mimics.Object
        
        :returns: A copy of the defined object.
        :rtype: mimics.Object
        
        :exceptions: RuntimeError (reason(s): ['Could not duplicate this object. It may be due to the fact that object is non-copiable (e.g. mimics.ImageData).'])
        """
        pass

    def get_active(self):
        """
        Returns Active Image Data.
        
        
        
        :returns: mimics.ImageData
        :rtype: mimics.ImageData
        """
        pass

    def set_active(self, image):
        """
        Changes Active Image Data.
        
        :param image: Image that will be set as active one
        :type image: mimics.ImageData
        
        :returns: Returns true if the operation was successful.
        :rtype: bool
        
        :exceptions: TypeError (reason(s): ['Object cannot be converted to a required type'])
        """
        pass




class DataContainerBase(object):
    """
    Flat container which contains all application objects.
    """
    def __getitem__(self, key):
        """
        :param key: 
        :type key: typing.Union[int, str]
        
        :returns: Single object which corresponds to the key criteria.
        :rtype: mimics.Object
        
        :exceptions: KeyError (reason(s): ['There is no object with specified name', 'Object with specified name is found more than once'])
        """
        pass

    def __len__(self):
        """
        
        
        :returns: Number of elements in the container.
        :rtype: int
        """
        pass

    def __iter__(self):
        """
        
        
        :returns: Iterator for the given container.
        :rtype: mimics.DataContainerBaseIterator
        """
        pass

    def filter(self, expression, regex=False):
        """
        Filters container`s element.
        
        :param expression: Expression matching the name of the object
        :type expression: str
        :param regex: (optional) Defines whether expression is a regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: A list of objects names of which correspond to the regular expression shall be returned. In case of no object with such name an empty list should be returned.
        :rtype: typing.List[mimics.Object]
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass

    def find(self, name, regex=False):
        """
        Finds the object by name.
        
        :param name: Object`s name.
        :type name: str
        :param regex: (optional) Defines whether name is regular expression or not. Default value is false.
        :type regex: bool
        
        :returns: If exactly one object in the container has the defined name, the object shall be returned. If more than one object in the container has the defined name, only the first of these objects shall be returned. In case of no object in the container has the defined name, the built-in Python constant None shall be returned.
        :rtype: mimics.Object
        
        :exceptions: ValueError (reason(s): ['Specified regular expression is not valid'])
        """
        pass




class DataContainerBaseIterator(object):
    """
    Iterator for mimics.DataContainerBase class
    """
    def __next__(self):
        """
        
        
        :returns: Next object in the corresponding DataContainerBase container.
        :rtype: mimics.Object
        
        :exceptions: StopIteration (reason(s): ['There is no next item in the container.'])
        """
        pass

    def __iter__(self):
        """
        
        
        :returns: Method that is called for the initialization of an iterator. This returns an iterator object
        :rtype: mimics.DataContainerBaseIterator
        """
        pass




def activate_crash_sending_dialog(files=()):
    """
    Creates an error report and attaches files which are given as parameters.
    
    :param files: (optional) List of the paths to the files to attach to the error report.
    :type files: typing.Iterable[TFilenameToRead]
    
    :exceptions: ValueError (reason(s): ['Error reporting is not available']), RuntimeError (reason(s): ['Cannot generate error report']), OSError (reason(s): ['Cannot attach file(s)']), FileNotFoundError (reason(s): ['Cannot find file(s)'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	extra_files_to_be_attached =[r"C:\MedData\DemoFiles\DICOM_Airway\J_50230713_0.dcm", r"C:\MedData\DemoFiles\DICOM_Airway\J_50230713_1.dcm"]
    	mimics.activate_crash_sending_dialog(files=extra_files_to_be_attached)

    """
    pass


def not_reloading_modules():
    """
    Provides access to the list of user-defined modules that should not be reloaded. If any user-defined module that is imported to a script should not be reloaded while the script is running then its name (same as in the 'import' statement) should be appended to the given list. By default, all user-defined modules will be reloaded and the returned list is empty. In case you don't want any of the user-defined modules to be reloaded, disable this functionality completely by calling 'mimics.disable_modules_reload()'
    
    See also: 'mimics.enable_modules_reload()', 'mimics.disable_modules_reload()'
    
    :returns: The list of names of the user-defined modules that should not be reloaded automatically.
    :rtype: typing.Iterable[str]
    """
    pass


class Transaction(object):
    """
    Transaction is a context manager, that allows to unite separate operations into the one transaction.
    
    The constructor of the class accepts two parameters:
        * transaction_name: str - name of the transaction which will be shown on the undo/redo GUI.
        * delay_opening: bool = False - if True, the underlying transaction of the host application is is not created util the use does some action. This allows to use transaction GUI interactive scripts that need to have undo/redo button enabled, which can be achieved by specifying delay_opening=True.
    """
    def commit(self):
        """
        Commits all included operations.
        
    
        """
        pass

    def rollback(self):
        """
        Rollbacks all included operations.
        
    
        """
        pass

    @property
    def is_open(self):
        """
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass


class LayoutsContainer(object):
    """
    List of available layouts.
    """
    pass


def get_dicom_tags():
    """
    Returns the DICOM tags dictionary of the study except from the tags of the image pixels information. In order to get the pixel information of images mimics.ImageData.get_voxel_buffer API can be used. Each time a new instance of dictionary is returned, consequently to achieve better performance of API assign it first to a variable (cached). Note that tags are returned in decimal format, you can convert it to hexadecimal format.
    
    :returns: DICOM tags of the currently opened project for active image data
    :rtype: typing.Dict[typing.Tuple[int, int], mimics.DicomTag]
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.file.import_images(r"C:\MedData\DemoFiles\DICOM_Airway")
    	# Getting dicom tags in order to cache them in a variable (for speed)
    	tags = mimics.get_dicom_tags()
    	
    	# Getting tag value by its group and id
    	t = tags[0x0028, 0x0010]
    	print("{}: {}".format(t.description, t.value))
    	
    	# If you want to iterate over all tags (not accessing their child tags) you can use
    	# standard Python dict iteration
    	for k, v in tags.items():
    	    print(hex(k[0]), hex(k[1]), ":", v.value)
    	
    	# Getting tags in different formats: hex, dec
    	for  key, tag in tags.items():
    	    print('({0},{1}) = ({0:04X},{1:04X}) | {2} | {3}'.format(*key, tag.description, tag.value))
    	
    	# If a tag contains a list of values you can iterate it like a list
    	lst = tags[0x0012, 0x0064]
    	for elem in lst:
    	    print(len(elem), type(elem), elem)
    	
    	# As you will notice, some DICOM tag element are just plain tag/value pairs.
    	# Others though can contain nested tags, so in general DICOM is a tree-like structure.
    	# E.g. patients name usually lies in a single tag `(0x10, 0x10)`.
    	# Per-frame Functional Groups Sequence `(0x5200, 0x9230)`, on the other hand
    	# contains a sequence of nested DICOM Tag elements.
    	# To access them please use `.children` on the tag object
    	# (`.children` is set to `None` in case no nested tags are present)
    	
    	child_tags = tags[0x0012, 0x0064].children[0]
    	for k, v in child_tags.items():
    	    print(hex(k[0]), hex(k[1]), ":", v.value)
    	
    	# To get tags from particular image
    	tags = mimics.data.images[0].get_dicom_tags(0)
    	print(tags[0x0008, 0x0018].value)

    """
    pass


class ImageData(Object):
    """
    Image data is a matrix of voxels.
    
    
    
    
    
    Properties:
        * is_dicom_data_modified: Indicates if the DICOM related data (e.g. Pixel Data or values of the DICOM tags) of images has been modified by the application after the project was created through importing original DICOM image files. The 'True' value is assigned to the property after certain operations with the project, e.g., reslice of images, cropping the images or scatter removal. The property is set to 'False' for projects created on Mimics platform version 24 or older.
        * storage_type: Specifies how the DICOM tags and imagedata are stored (see also: mimics.file.ImageDataStorageType).
    """
    def get_voxel_buffer(self):
        """
        Returns a 3D image copy as 16-bit 3D array of grey value.
        
        
        
        :returns: 16-bit 3D array of grey value.
        :rtype: memoryview
        """
        pass

    def _get_logical_voxel_buffer(self):
        """
        Returns a 3D logical image copy as 16-bit 3D array of grey value.
        
        
        
        :returns: 16-bit 3D array of grey value.
        :rtype: memoryview
        """
        pass

    def get_voxel_center(self, index_of_voxel):
        """
        Calculates coordinates of the voxel center.
        
        :param index_of_voxel: Voxel index in the image data.
        :type index_of_voxel: ThreeItemsIterable[int, int, int]
        
        :returns: Voxel center's coordinates.
        :rtype: typing.Tuple[float, float, float]
        """
        pass

    def _get_logical_voxel_center(self, index_of_voxel):
        """
        Calculates coordinates of the logical voxel center.
        
        :param index_of_voxel: Logical voxel index in the image data.
        :type index_of_voxel: ThreeItemsIterable[int, int, int]
        
        :returns: Logical voxel center's coordinates.
        :rtype: typing.Tuple[float, float, float]
        """
        pass

    def get_voxel_indexes(self, point_coordinates):
        """
        Calculates voxel indexes in image data.
        
        :param point_coordinates: Point inside of voxel.
        :type point_coordinates: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :returns: Voxel coordinates.
        :rtype: typing.Tuple[int, int, int]
        """
        pass

    def _get_logical_voxel_indexes(self, point_coordinates):
        """
        Calculates logical voxel indexes in image data.
        
        :param point_coordinates: Point inside of the logical voxel.
        :type point_coordinates: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :returns: Logical voxel coordinates.
        :rtype: typing.Tuple[int, int, int]
        """
        pass

    def get_grey_value(self, point_coordinates):
        """
        Calculates grey value in the defined coordinates in image data.
        
        :param point_coordinates: Point coordinates in project units.
        :type point_coordinates: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        
        :returns: Grey value of image
        :rtype: int
        """
        pass

    def get_dicom_tags(self, image_index=None):
        """
        Returns the DICOM tags dictionary of this image data except from the tags of the image pixels information. It is recommended to cache the dictionary into a variable if your script needs to refer to the DICOM dictionary several times. In order to get the pixel information of images mimics.ImageData.get_voxel_buffer API can be used. Each time a new instance of dictionary is returned, consequently to achieve better performance of API assign it first to a variable (cached).  Note that tags are returned in decimal format, you can convert it to hexadecimal format.
        
        :param image_index: (optional) Index of image in image set
        :type image_index: int
        
        :returns: DICOM tags for this image data
        :rtype: typing.Dict[typing.Tuple[int, int], mimics.DicomTag]
        """
        pass

    def get_dicom_frame_indices(self):
        """
        Returns a list of indices of all (selected and not selected) image frames of an image stack created from a multiframe DICOM file. Elements of the list may contain 'None' if specific frames were not imported from a multiframe DICOM in some cases. 'None' is returned if all the slices are created by importing single frame DICOM files.
        
        
        
        :returns: Tuple of integral frame indices or None
        :rtype: typing.Optional[typing.List[typing.Optional[int]]]
        """
        pass

    def get_image_information(self):
        """
        Returns information about this image data.
        
        
        
        :returns: Image information for this image data
        :rtype: mimics.ImageInformation
        """
        pass

    def _get_contrast(self):
        """
        Returns a contrast object.
        
        
        
        :returns: Contrast object
        :rtype: mimics.ContrastFunctionObject
        """
        pass

    def _set_contrast(self, lower_point=None, upper_point=None):
        """
        Contrast object is set.
        
        :param lower_point: (optional) Lower contrast point.
        :type lower_point: typing.Tuple[typing.SupportsInt, typing.SupportsFloat]
        :param upper_point: (optional) Upper contrast point.
        :type upper_point: typing.Tuple[typing.SupportsInt, typing.SupportsFloat]
        """
        pass

    @property
    def active(self):
        """
        :type: <class 'bool'>
        :read-only: False
    
        """
        pass
    
    @active.setter
    def active(self, value):
        """
    
        """
        pass

    @property
    def pixel_size(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def storage_type(self):
        """
        :type: <enum 'ImageDataStorageType'>
        :read-only: True
    
        """
        pass

    @property
    def is_dicom_data_modified(self):
        """
        :type: <class 'bool'>
        :read-only: True
    
        """
        pass

    @property
    def _dicom_percentage(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def user_dicom_percentage(self):
        """
        :type: <class 'str'>
        :read-only: False
    
        """
        pass
    
    @user_dicom_percentage.setter
    def user_dicom_percentage(self, value):
        """
    
        """
        pass

    @property
    def logical_slice_distance(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: True
    
        """
        pass

    @property
    def logical_dimensions(self):
        """
        :type: typing.Sequence[typing.SupportsInt]
        :read-only: True
    
        """
        pass

    @property
    def physical_dimensions(self):
        """
        :type: typing.Sequence[typing.SupportsInt]
        :read-only: True
    
        """
        pass

    @property
    def linked_objects(self):
        """
        :type: typing.List[mimics.Object]
        :read-only: True
    
        """
        pass

    @property
    def registration_transformation(self):
        """
        :type: typing.Union[mimics.Transformation, NoneType]
        :read-only: False
    
        """
        pass
    
    @registration_transformation.setter
    def registration_transformation(self, value):
        """
    
        """
        pass


def enable_modules_reload():
    """
    Turns on automatic reloading of all previously loaded user-defined modules before executing a script for the current session in case it was previously turned off, e.g. by calling 'mimics.disable_modules_reload()'. By default, modules reload is on. This is useful if you have edited the imported module source file (e.g. using an external editor) and want to try out the new version without restarting the application.  Since it is not officially recommended to reload built-in or dynamically loaded modules, only python modules located in the current working folder and subfolders will be reloaded.
    
    See also: 'mimics.disable_modules_reload()', 'mimics.not_reloading_modules()'
    """
    pass


def get_registry_path():
    """
    Returns the root path to the settings of the current instance of Mimics in the Windows Registry.
    
    Note that  the name of the registry hive (such as 'HKEY_CURRENT_USER', see details at  https://docs.microsoft.com/en-us/windows/win32/sysinfo/registry-hives) is not included into the returned string.
    
    See also: mimics.logging.get_logs_path().
    
    :returns: path to the Registry key, e.g. SOFTWARE\Materialise\Materialise Mimics Medical\24.0 Beta'
    :rtype: str
    
    
    :example:
    .. code-block:: python
    
    	 
    	# The example enumerates and prints list of key at the root level.
    	# of the registry of the give application session.
    	# It also asserts presence of sub-keys when preference serialization is enabled.
    	import winreg
    	import logging
    	import mimics
    	
    	reg_key_path = mimics.get_registry_path()
    	print(f"Reading the keys from path: '{reg_key_path}':")
    	
    	num_of_subkeys = 0
    	
    	try:
    	    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, reg_key_path) as key:
    	        for i in range(1000):
    	            sub_key = winreg.EnumKey(key, i)
    	            print(f" * sub-key at {i}: {sub_key}';")
    	            num_of_subkeys += 1
    	except OSError as ex:
    	    # this is expected if more then 1000 sub-keys present or registry is not created yet
    	    mimics.logging.log_system_message(logging.INFO, "Error while reading registry", {"exception": ex})
    	
    	print(f"Total: {num_of_subkeys} sub-key(ss) found.")
    	
    	if mimics.preferences.is_saving_enabled():
    	    assert num_of_subkeys > 0, "There must be sub-keys present preference saving enabled."

    """
    pass


def cancel_active_tool():
    """
    Immediately closes the currently active tool or measurement. All progress in the closed tool or measurement is lost.
    """
    pass


def _disable_python_ui():
    """
    Disables any possibility to access Python from Mimics UI for current instance of Mimics
    """
    pass


class ImageInformation(object):
    """
    Information about specific image data.
    """
    pass


class segmentation_box(object):
    """
    3D bounding box dependent on image data.
    """
    pass


class DicomTag(object):
    """
    The DICOM tag class.
    """
    def __len__(self):
        """
    
        """
        pass

    def __getitem__(self, index):
        """
        :param index: 
        :type index: int
        """
        pass

    @property
    def description(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def vr(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def length(self):
        """
        :type: <class 'int'>
        :read-only: True
    
        """
        pass

    @property
    def value(self):
        """
        :type: <class 'str'>
        :read-only: True
    
        """
        pass

    @property
    def children(self):
        """
        :type: typing.Union[typing.Tuple[typing.Dict[typing.Tuple[int, int], mimics.DicomTag]], NoneType]
        :read-only: True
    
        """
        pass


def rotate_object_around_views(entity, angles, rotation_origin):
    """
    Rotates an object with the defined angles.
    
    :param entity: The object to rotate.
    :type entity: typing.Union[mimics.Part, mimics.Osteotomy, mimics.analyze.Sphere, mimics.analyze.Point, mimics.analyze.Spline, mimics.analyze.Cylinder, mimics.analyze.Plane, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Centerline]
    :param angles: An (x,y,z) tuple or list with values representing the angles along each major axis (in degrees)
    :type angles: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param rotation_origin: Center of the rotation.
    :type rotation_origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	obj = mimics.data.parts[0]
    	ang_deg = 90
    	origin = (0,0,0)
    	mimics.rotate_object_around_views(entity=obj, angles=(0,0,ang_deg), rotation_origin=origin)

    """
    pass


def _check_license(license_id):
    """
    Checks and grabs the license.
    
    :param license_id: license_id to check
    :type license_id: int
    
    :returns: Check if the license us present.
    :rtype: bool
    """
    pass


def get_version():
    """
    Returns current full Mimics version. The version includes:
    
     * application name (may include company name);
    
     * flavor (e.g. 'Medical');
    
     * A.B.C.D version number (e.g 24.0.0.427);
    
     * Stage (e.g. Alpha, Beta)
    
    Example: Materialise Mimics Medical 24.0.0.427.
    
    :returns: full Mimics version
    :rtype: str
    """
    pass


def move_object(entity, offset):
    """
    Translates an object along x,y,z direction.
    
    :param entity: The object to be moved.
    :type entity: typing.Union[mimics.Part, mimics.Osteotomy, mimics.analyze.Sphere, mimics.analyze.Point, mimics.analyze.Spline, mimics.analyze.Cylinder, mimics.analyze.Plane, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Centerline]
    :param offset: Offset from the original position in x, y, z direction.
    :type offset: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	obj = mimics.data.parts[0]
    	vec = (0,0,10)
    	mimics.move_object(entity=obj ,offset=vec)

    """
    pass


def rotate_object_around_inertia_axis(entity, angles, rotation_origin):
    """
    Rotates a part around its inertia axis.
    
    :param entity: The Part to rotate.
    :type entity: mimics.Part
    :param angles: An (x,y,z) tuple or list with values representing the angles along each major axis (in degrees)
    :type angles: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param rotation_origin: Center of the rotation.
    :type rotation_origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	obj = mimics.data.parts[0]
    	ang_deg = 10
    	origin = (0,0,0)
    	mimics.rotate_object_around_inertia_axis(entity = obj, angles = (0,0,ang_deg), rotation_origin=origin)

    """
    pass


def indicate_coordinate(message='Please indicate coordinate', show_message_box=True, confirm=True, title=None):
    """
    Displays a dialog which asks the user to create a point.
    
    :param message: (optional) Dialog description.
    :type message: str
    :param show_message_box: (optional) Defines whether message box should be shown or not. If false then all other parameters are ignored.
    :type show_message_box: bool
    :param confirm: (optional) If true, it displays the OK button and waits for the user to click it to confirm the object placement.
    :type confirm: bool
    :param title: (optional) Title of the dialog.
    :type title: str
    
    :returns: Coordinates that can be used for point creation.
    :rtype: typing.Tuple[float, float, float]
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = 'Please indicate coordinates of Point 1'
    	tit = 'Point 1'
    	coords = mimics.indicate_coordinate(message=msg, title=tit)

    """
    pass


def rotate_object_around_axis(entity, axis, angle, rotation_origin):
    """
    Rotates an object around X, Y or Z axis.
    
    :param entity: The object to rotate.
    :type entity: typing.Union[mimics.Part, mimics.analyze.Sphere, mimics.analyze.Point, mimics.analyze.Spline, mimics.analyze.Cylinder, mimics.analyze.Plane, mimics.analyze.Line, mimics.analyze.Circle, mimics.analyze.Centerline]
    :param axis: Direction of the axis of the rotation.
    :type axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param angle: Angle of the rotation (in degrees)
    :type angle: typing.SupportsFloat
    :param rotation_origin: Center of the rotation.
    :type rotation_origin: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    
    
    :example:
    .. code-block:: python
    
    	 
    	obj = mimics.data.parts[0]
    	vec = (0,0,1)
    	ang_deg = 180
    	origin = (0,0,0)
    	mimics.rotate_object_around_axis(entity = obj, axis = vec, angle = ang_deg , rotation_origin=origin)

    """
    pass


def disable_modules_reload():
    """
    Turns off automatic reloading of all previously loaded user-defined modules before executing a script for the current session. By default, modules reload is on. Any changes to the source code of previously imported modules will not be reflected in the current session of Mimics.
    
    See also: 'mimics.enable_modules_reload()', 'mimics.not_reloading_modules()'
    """
    pass


def toggle_script_listener():
    """
    Toggles the 'Script Listener', which allows running and debugging of scripts via an external IDE. For more information, please consult section 'External IDE' of the Scripting Guide.
    
    :exceptions: RuntimeError (reason(s): ['Listener is already activated in other instance of Mimics.'])
    """
    pass


def _set_app_state(app_state, tool_name, confirm=True):
    """
    Sets defined application state.
    
    :param app_state: Application state that is about to be set.
    :type app_state: object
    :param tool_name: Name of the tool to be shown.
    :type tool_name: str
    :param confirm: (optional) If True, it displays the OK button and waits for user to click it to confirm object placement.
    :type confirm: bool
    """
    pass


def _track_api_use(api_name):
    """
    Tracks the fact of python API usage.
    
    :param api_name: API name
    :type api_name: str
    """
    pass



class Layouts(object):
    """
    `Container <./mimics.html#mimics.LayoutsContainer>`_ with string attributes that can be used as an input for `mimics.view.set_layout <./mimics.view.html#mimics.view.set_layout>`_ API.
    """
    pass


class DataObject:
    analytical_primitives = None
    angle_measurements = None
    area_measurements = None
    centerline_measurements = None
    centerlines = None
    circles = None
    cylinders = None
    diameter_measurements = None
    distance_measurements = None
    fluoroscopy_views = None
    images = None
    lines = None
    masks = None
    measurements = None
    meshes = None
    metadata = None
    objects = None
    parts = None
    planes = None
    points = None
    position_difference_measurements = None
    reslice_planes = None
    spheres = None
    splines = None
    typing = None
    views = None


    def __init__(self):
        self.analytical_primitives = DataContainer()
        self.angle_measurements = DataContainer()
        self.area_measurements = DataContainer()
        self.centerline_measurements = DataContainer()
        self.centerlines = DataContainer()
        self.circles = DataContainer()
        self.cylinders = DataContainer()
        self.diameter_measurements = DataContainer()
        self.distance_measurements = DataContainer()
        self.fluoroscopy_views = DataContainer()
        self.images = DataContainer()
        self.lines = DataContainer()
        self.masks = DataContainer()
        self.measurements = DataContainer()
        self.meshes = DataContainer()
        self.metadata = DataContainer()
        self.objects = DataContainer()
        self.parts = DataContainer()
        self.planes = DataContainer()
        self.points = DataContainer()
        self.position_difference_measurements = DataContainer()
        self.reslice_planes = DataContainer()
        self.spheres = DataContainer()
        self.splines = DataContainer()
        self.typing = DataContainer()
        self.views = DataContainer()

data = DataObject()


from . import connmim
from . import wrap_api
wrap_api.patch_module()
wrap_api.patch_data_object()
