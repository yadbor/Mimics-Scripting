import typing
import mimics


def get_value(preference_id):
    """
    This API returns the current preference value for the current application instance. The value is taken from the memory (important if saving preferences is disabled for the Mimics instance via the API enable_saving).
    
    A list of fully specified preference IDs for the application can be received via the API mimics.preferences.get_registered_ids().
    
    See also: mimics.preferences.get_registered_ids(), mimics.preferences.set_value(), mimics.preferences.is_saving_enabled(), mimics.preferences.enable_saving().
    
    :param preference_id: The fully qualified preference name (ID).
    :type preference_id: str
    
    :returns: The value and type of the preference parameter.
    :rtype: mimics.preferences.ValueTypes
    
    :exceptions: KeyError (reason(s): ['The preference named "[PREFERENCE_NAME]" is not found in the group "[GROUP_NAME]".', 'The group of preferences named "[GROUP_NAME]" was is not found in the group "[GROUP]".'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	import mimics
    	
    	# Example #1 - getting integer setting
    	preference_id = "General.Segmentation.ThresholdRegionGrow.LowerThreshold"
    	val = mimics.preferences.get_value(preference_id)
    	assert isinstance(val, int)
    	print(f"Preference '{preference_id}' == '{val}'.")
    	
    	# Example #2 - getting a string preference
    	preference_id = "General.RemeshTool"
    	val = mimics.preferences.get_value(preference_id)
    	assert isinstance(val, str)
    	print(f"Preference '{preference_id}' == '{val}'.")
    	
    	# Example #3 - getting an enumeration preference
    	preference_id = "General.PixelUnits"
    	val = mimics.preferences.get_value(preference_id)
    	assert isinstance(val, mimics.preferences.PixelUnits)
    	print(f"Preference '{preference_id}' == '{val}'.")

    """
    pass


def set_value(preference_id, value):
    """
    This API allows setting value for a given preference for the current instance of Mimics. 
    
    Warning: Be careful to avoid setting conflicting preference values. Modifying preference settings may sometimes result in inconsistent behavior or application crashes. If the application fails to launch after making changes, run Mimics Reset Settings from the Windows Start menu to restore all preferences to its defaults.
    
    The value will be saved or not saved in the operating system storage, depending on the current save preferences mode. The mode can be specified via the API enable_saving. A list of fully specified preference IDs for the application can be received via the API mimics.preferences.get_registered_ids().
    
    For preferences of string types, the 'value' paramater will get its string representation if it's value is not a native Python string.
    
    For enumerators, the type of a preference can be specified both as the member of a native enumeration type or a string value of the name. For example, all the options listed below are valid to set up the ImageStorageType preference:
        * mimics.preferences.set_value("General.ImageStorageType", mimics.preferences.ImageStorageType.Uncompressed)   # by enumeration type, the preferred way
        * mimics.preferences.set_value("General.ImageStorageType", "mimics.preferences.ImageStorageType.Uncompressed")
        * mimics.preferences.set_value("General.ImageStorageType", "ImageStorageType.Uncompressed")
        * mimics.preferences.set_value("General.ImageStorageType", "Uncompressed")
    
    The first method (by Python's native enumeration type) is the most preferred because it provides the strongest type checks, whereas the string-based methods are provided for to support use case when Python native enums are not possible for cases, such as, when values is stored in text/init files.
    
    See also: mimics.preferences.get_registered_ids(), mimics.preferences.get_value(), mimics.preferences.is_saving_enabled(), mimics.preferences.enable_saving().
    
    :param preference_id: The fully qualified preference name (ID).
    :type preference_id: str
    :param value: The value and type of the preference parameter.
    :type value: mimics.preferences.ValueTypes
    
    :exceptions: KeyError (reason(s): ['The preference named "[PREFERENCE_NAME]" is not found in the group "[GROUP_NAME]".', 'The group of preferences named "[GROUP_NAME]" was is not found in the group "[GROUP]".']), TypeError (reason(s): ['The value "[RECEIVED_VALUE]" of type "[RECEIVED_TYPE]" does not match the expected type "[EXPECTED_TYPE]" of preference "[PREFERENCE_NAME]".']), ValueError (reason(s): ['The value "[RECEIVED_VALUE]" of type "[RECEIVED_TYPE]" cannot be set to preference "[PREFERENCE_NAME]": [TECHNICAL DETAILS].'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	import mimics
    	
    	# Note:
    	#   the following line with enable_saving() is to avoid 
    	#   saving the changes caused by running this examples
    	mimics.preferences.enable_saving(False)
    	
    	# Example #1 - setting integer setting
    	preference_id = "General.Segmentation.ThresholdRegionGrow.LowerThreshold"
    	mimics.preferences.set_value(preference_id, 3)
    	
    	# Example #2 - setting a string preference
    	preference_id = "General.RemeshTool"
    	mimics.preferences.set_value(preference_id, r"C:\path\to\remesh\tool.exe")
    	
    	# Example #3 - setting an enumeration preference
    	preference_id = "General.PixelUnits"
    	mimics.preferences.set_value(preference_id, mimics.preferences.PixelUnits.Hounsfield)

    """
    pass


def reset_value(preference_id):
    """
    The API restores the default preference setting for the current application instance.
    
    Warning: Be careful to avoid setting conflicting preference values. Modifying preference settings may sometimes result in inconsistent behavior or application crashes. If the application fails to launch after making changes, run Mimics Reset Settings from the Windows Start menu to restore all preferences to its defaults.
    
    The restored default value will be saved or not saved in the operating system storage (e.g. Windows Registry) depending on the current mode for saving preferences (it can be specified via the API enable_saving ). A list of fully specified preference IDs for the application can be received via the API mimics.preferences.get_registered_ids().
    
    See also: mimics.preferences.get_registered_ids(), mimics.preferences.is_saving_enabled(), mimics.preferences.enable_saving().
    
    :param preference_id: The fully qualified preference name (ID).
    :type preference_id: str
    
    :exceptions: KeyError (reason(s): ['The preference named "[PREFERENCE_NAME]" is not found in the group "[GROUP_NAME]".', 'The group of preferences named "[GROUP_NAME]" was is not found in the group "[GROUP]".'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	pref_id = '3DSettings.UseDynamicBuffersForSmallObjects'
    	mimics.preferences.reset_value(preference_id=pref_id)
    	
    	assert mimics.preferences.get_value(pref_id) == mimics.preferences.get_default_value(pref_id)

    """
    pass


def get_registered_ids(preference_filter=None):
    """
    The API provides a dictionary of fully qualified preference names (IDs) mapped to the preference type description for the current instance of Mimics.
    
    A preference type is a structure consisting of preference type in the Python type notation and possible parameter values for enumerations (optionally).
    
    Optionally, you can search for preferences with IDs containing a certain fragment of the preference ID.
    
    The returned preference IDs can be used to set preference values via the API mimics.preferences.set_value().
    
    See also: mimics.preferences.set_value(), mimics.preferences.get_value(), mimics.preferences.get_default_value().
    
    :param preference_filter: (optional) Any fragment of the fully qualified preference name (ID).
    :type preference_filter: str
    
    :returns: A dictionary of fully qualified preference names (IDs) mapped to preference type descriptions.
    :rtype: typing.Dict[str, object]
    
    
    :example:
    .. code-block:: python
    
    	 
    	# this extracts all preference info [name, type]
    	mimics.preferences.get_registered_ids()
    	
    	# this extracts preferences info for ones that contain 'name_filter' substring in path
    	name_filter = 'ExportLandmarkPoints'
    	mimics.preferences.get_registered_ids(name_filter)

    """
    pass


def is_saving_enabled():
    """
    The API checks if the saving of preference settings to the operating system storage is currently enabled. See documentation of 'mimics.preferences.enable_saving()' for more details.'
    
    See also: mimics.preferences.enable_saving(), mimics.preferences.set_value().
    
    :returns: The current mode (ON/OFF) of saving preferences in the operating system storage. If False, the preferences are not saved but kept in memory until the application is restarted or the save mode is changed.
    :rtype: bool
    
    
    :example:
    .. code-block:: python
    
    	 
    	import logging
    	import mimics.logging
    	
    	if mimics.preferences.is_saving_enabled():
    	    mimics.logging.log_user_message(logging.INFO, "Saving the preferences is enabled now, so that "
    	                                                  "they will saved to the OS's persistent "
    	                                                  "preference storage of registry (on Windows).")
    	else:
    	    mimics.logging.log_user_message(logging.INFO, "Saving the preferences is disable enabled now,"
    	                                                  "so that they will only persit for the "
    	                                                  "given session of the host application.")

    """
    pass


def reset_all_values():
    """
    The API restores the default settings for all preference parameters for the current application instance.
    
    The restored default value will be saved or not saved in the operating system storage (e.g. Windows Registry) depending on the current mode for saving preferences (it can be specified via the API enable_saving).
    
    See also: mimics.preferences.get_registered_ids(), mimics.preferences.is_saving_enabled(), mimics.preferences.enable_saving().
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.preferences.reset_all_values()
    	
    	# here we just check one preference to be in the default state
    	pref_id = '3DSettings.UseDynamicBuffersForSmallObjects'
    	assert mimics.preferences.get_default_value(pref_id) == mimics.preferences.get_value(pref_id)

    """
    pass


def enable_saving(enable):
    """
    The API allows you to control whether the preferences are saved in the operating system (OS) storage (e.g. Windows Registry or the AppData folder of a given user account). The preferences values (regardless if they are set with API or wit GUI) are not lost after mimics.preferences.enable_saving(False) but are accumulated in operational memory. The values will be written into persistent storage (e.g. Windows Registry) when the script calls mimics.preferences.enable_saving(True). Note that the preference values which are accumulated while sabing is disable are lost if mimics.preferences.enable_saving(True) is not NOT called before the application terminates.
    
    You can disable saving preferences to isolate the current instance of the application from the other ones. This is important in case of batch file processing, massive data preparation, or running multiple instances of the application in parallel on the same PC.
    
    The API configures the save preferences mode ONLY for the current instance of the application, so after the restart, saving to OS storage will be enabled by default.
    
    If you repeat invoking the API with the same argument, it will not affect performance and will not result in performance degradation. However, if you invoke the API repeatedly changing the save preferences mode, it might cause time-consuming input/output operations in the file system and the Registry. Therefore, it is recommended to avoid switching saving mode ON/OFF unnecessarily.
    
    See also: mimics.preferences.is_saving_enabled(), mimics.preferences.set_value().
    
    :param enable: If False, the preferences are not saved in operating system storage until this API is called with the value True, or the host application is restarted.
    :type enable: bool
    
    
    :example:
    .. code-block:: python
    
    	 
    	mimics.preferences.enable_saving(False)
    	# Since this call the preferences will not be stored in 
    	# Windows registry, however they will persists within the
    	# current session of the host applciation.
    	assert not mimics.preferences.is_saving_enabled()

    """
    pass


def get_default_value(preference_id):
    """
    This API returns the default value for the preference for the current application instance.
    
    A list of fully specified preference IDs for the application can be received via the API mimics.preferences.get_registered_ids().
    
    See also: mimics.preferences.get_registered_ids(), mimics.preferences.set_value(), mimics.preferences.is_saving_enabled(), mimics.preferences.enable_saving().
    
    :param preference_id: The fully qualified preference name (ID).
    :type preference_id: str
    
    :returns: The default value and type of the preference parameter.
    :rtype: mimics.preferences.ValueTypes
    
    :exceptions: KeyError (reason(s): ['The preference named "[PREFERENCE_NAME]" is not found in the group "[GROUP_NAME]".', 'The group of preferences named "[GROUP_NAME]" was is not found in the group "[GROUP]".'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# Example #1 - getting a boolean preference and displaying its value and type
    	preference_id = "3DSettings.UseDynamicBuffersForSmallObjects"
    	val = mimics.preferences.get_default_value(preference_id)
    	print(f"Preference '{preference_id}' == '{val}', type == '{type(val)}'.")

    """
    pass


