import typing
import mimics


def initialize_pyqt(throw_exception_on_error):
    """
    Initializes PyQt5 and checks compatibility between the application and PyQt5 and produces warning and logs messages if potential incompatibilities are found (such as version mismatch). 
    
    The API initializes PyQt5 in a step-by-step manner checking compatibility after each step. That makes it a preferred method initialize PyQt Python packages.
    
    The recommended pattern is the following: before the first time import statements are executed:
    
     > import PyQt5
    
     > from PyQt5 import QtWidgets
    
    It is recommended to check initialize and check compatibility between the application and PyQt5 packages by calling to:
    
     > mimics.utils.initialize_pyqt(True)
    
    or
    
     > error_text = mimics.utils.initialize_pyqt(False)
    
     > if error_text
    
     >     logging.error(error_text)
    
     >         return
    
    The reasons it is recommended are the following: if there are mismatches in versions, or a debuggable version (so-called: debug build) of PyQt5 is installed on your PC whereas the application is non-debuggable mode (so-called: release build), or the other way around, then calling mimics.utils.initialize_pyqt() first gives more chances to capture the error before the native binary crash takes place due to above-mentioned incompatibilities.
    
    Also, mimics.utils.initialize_pyqt() will introduce throwing exceptions into PyQt5 API's which are not allowed be called when PyQt5 is embedded into another native host application. Example of such PyQt5 APIs are creation of new instance of:
    
     > QApplication()
    
     > QGuiApplication()
    
    :param throw_exception_on_error: If True, then this API will raise a Python exception on initialization error, otherwise error text will be returned or None for successful initialization.
    
    Note, this argument does not have default to promote explicit decision making in every case about error handling strategy. The API allows for these two patterns in error handling: exceptions and error codes. See the examples for details.
    :type throw_exception_on_error: bool
    
    :returns: None or error description
    :rtype: typing.Optional[str]
    
    :exceptions: ImportError (reason(s): ['PyQt library is either not installed, mis-configured or its version mis-matches version of Qt in the host application.'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	
    	#Example 1
    	# use this approach if you need to show a less technical message text
    	
    	# Attention: this will load core PyQt5 binaries (can take time -> in real life code,
    	#             delay it as much as possible and convenient.
    	error_text = mimics.utils.initialize_pyqt(False)
    	if error_text:
    	    print(error_text)
    	    # exit or initialization of an alternative GUI or continuing gui-less
    	else:
    	    import PyQt5
    	    import PyQt5.QtCore
    	
    	    print(f"PyQt5 package (v. {PyQt5.QtCore.qVersion()}) has been successfully initialized.")
    	    # continue normal execution...
    	
    	
    	#Example 2
    	# use this approach to simplify error handling, and where it is OK to show
    	# full blown Python error text
    	
    	# Attention: this will load core PyQt5 binaries (can take time -> in real life code,
    	#             delay it as much as possible and convenient.
    	mimics.utils.initialize_pyqt(True)
    	
    	import PyQt5
    	import PyQt5.QtCore
    	
    	print(f"PyQt5 package (v. {PyQt5.QtCore.qVersion()}) has been successfully initialized.")
    	# continue normal execution...
    	
    	
    	#Example 3
    	# This example illustrate the following:
    	#   1. using mimics.utils.initialize_pyqt() API.
    	#   2. illustrating the correct (safe) way to obtain the instance of the QApplication
    	import mimics
    	import sys
    	
    	caps = mimics.gui.get_capabilities()
    	if caps.background_mode:
    	    print("This example is not supported in the background mode.\n"
    	          "Switch to the foreground (normal) mode (see the command line --help for extra details).")
    	else:
    	    # Attention: this will load core PyQt5 binaries (can take time -> in real life code,
    	    #             delay it as much as possible and convenient.
    	    error_text = mimics.utils.initialize_pyqt(False)
    	    if error_text:
    	        print(f"Install PyQt5 first, technical info: {error_text}")
    	    else:
    	        from PyQt5.QtWidgets import QApplication
    	
    	        try:
    	            qapp = QApplication([sys.argv])
    	        except TypeError:
    	            print("This is expected behaviour: the constructor is disabled after mimics.utils.initialize_pyqt().")
    	        else:
    	            assert False, "Shall never get here"
    	
    	        # Important note:
    	        #   1. obtaining, or rather creating, an instance of QApplication via
    	        #       > qapp = QApplication([sys.argv])
    	        #      is not supported and results in undefined behaviour. This is because
    	        #      an instance of QApplication is already created by C++ code of the
    	        #      host application.
    	        #   2. The QApplication([sys.argv]) method is valid (and mandatory) for
    	        #      standalone PyQt/PySide applications, but for the embedded ones
    	        #      (e.g. into Mimics), it is not supported and disabled (see the try/except above)
    	        #      after mimics.utils.initialize_pyqt() has been called.
    	        #   3. The correct way is not to create it, but to obtain it
    	        qapp = QApplication.instance()
    	        print(f"Type: {type(qapp)}, object: {qapp}")  # for debug purposes
    	
    	        # print out some properties
    	        print(f"Organization: {qapp.organizationName()}")
    	        print(f"Version: {qapp.applicationVersion ()}")

    """
    pass


