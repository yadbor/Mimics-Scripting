import typing

def measurements():
    """
    Container for all the measurements objects (e.g, mimics.measure.Area, mimics.measure.Distance, etc).
    """
    pass

def images():
    """
    Container for the mimics.ImageData objects.
    """
    pass

def position_difference_measurements():
    """
    Container for the mimics.measure.PositionDifference objects.
    """
    pass

def spheres():
    """
    Container for the mimics.analyze.Sphere objects.
    """
    pass

def splines():
    """
    Container for the mimics.analyze.Spline objects.
    """
    pass
	
def views():
    """
    Container for the active mimics.view.View objects.
    """
    pass

def fluoroscopy_views():
    """
    Container for the mimics.view.Fluoroscopy objects.
    """
    pass

def area_measurements():
    """
    Container for mimics.measure.Area objects.
    """
    pass

def parts():
    """
    Container for the mimics.Part objects.
    """
    pass

def angle_measurements():
    """
    Container for the mimics.measure.Angle objects.
    """
    pass

def points():
    """
    Container for the mimics.analyze.Point objects.
    """
    pass

def reslice_planes():
    """
    Container for the mimics.view.Reslice objects.
    """
    pass

def planes():
    """
    Container for the mimics.analyze.Plane objects.
    """
    pass

def lines():
    """
    Container for the mimics.analyze.Line objects.
    """
    pass

def analytical_primitives():
    """
    Container for all the analytical primitives (e.g: mimics.analyze.Point, mimics.analyze.Sphere, mimics.analyze.Line, etc).
    """
    pass

def centerline_measurements():
    """
    Container for all the centerline measurements (e.g:mimics.measure.CenterlineBestFitDiameter, mimics.measure.CenterlineCircumference, mimics.measure.CenterlineMaximalDiameter).
    """
    pass

def objects():
    """
    Container for all the mimics.Object objects including images, parts, measurements, analytical primitives, fluoroscopy and respliced planes, etc.
    """
    pass

def diameter_measurements():
    """
    Container for the mimics.measure.Diameter objects.
    """
    pass

def cylinders():
    """
    Container for the mimics.analyze.Cylinder objects.
    """
    pass

def circles():
    """
    Container for the mimics.analyze.Circle objects.
    """
    pass

def masks():
    """
    Container for the mimics.segment.Mask objects.
    """
    pass

def centerlines():
    """
    Container for the mimics.analyze.Centerline objects.
    """
    pass

def meshes():
    """
    Container for the mimics.fea.SubvolumeMesh and mimics.fea.VolumeMesh objects.
    """
    pass

def metadata():
    """
    Container for the mimics.MetadataItem objects.
    """
    pass

def distance_measurements():
    """
    Container for the mimics.measure.Distance objects.
    """
    pass