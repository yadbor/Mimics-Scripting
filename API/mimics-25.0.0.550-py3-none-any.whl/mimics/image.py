class Filter(object):
    """
    Filter is a general object for the image filters.
    """
    pass



import typing
import mimics


def reduce_scatter(image_data, mask, strength):
    """
    Removes or (partially) filters out metal artifacts, which are the result of metal in the FOV, on CT/CBCT images by providing a prior-made metal mask and filtering the specified image stack with a defined tolerance.
    
    :param image_data: Image stack with metal artifacts that you want to be filtered.
    :type image_data: mimics.ImageData
    :param mask: Mask to be used by the filtering algorithm. You need to create this mask before launching the tool. This mask should indicate exactly where the metal is located in the images. It should contain all metal structures in the FOV but not the artifacts themselves (including the artifacts in   this mask will greatly diminish the effects of the tool). Pay attention to include as much metal in the mask as possible. If you are faced with a choice, preference should be given to a mask that includes some non-metal pixels over a mask not encompassing all of the metal.
    :type mask: mimics.segment.Mask
    :param strength: Tolerance value that determines how strongly the metal artifacts will be reduced. Higher values result in more filtering but increase the risk of 'overfiltering' and blurring certain anatomical features. The filtering strength parameter should be a value between 0.01 and 1.
    :type strength: typing.SupportsFloat
    
    :returns: A new image stack containing the filtered images is created and added to the project. The new image stack will be named as follows: 'Reduce Scatter [filtering strength] � [original name]'
    :rtype: mimics.ImageData
    
    :exceptions: ValueError (reason(s): ['Parameters are somehow incorrect from algorithm point of view'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	# CT project with no metal mask
    	f = r"C:\MedData\DemoFiles\Mandible.mcs"
    	mimics.file.open_project(f)
    	
    	m = mimics.segment.create_mask()
    	
    	# some metal detection intensities range
    	mimics.segment.threshold(mask=m, threshold_min=3000, threshold_max=4095)
    	
    	# strength value should be in range [0.0, 1.0]
    	mimics.image.reduce_scatter(mimics.data.images.get_active(), m, 0.9)

    """
    pass


class MeanFilter(Filter):
    """
    The mean filter is commonly used for simple image noise reduction. Each output pixel is computed by finding the statistical mean of the gray-level values surrounding the corresponding input pixel. Note that this filter is sensitive to the presence of outliers in the neighborhood and does not preserve the image edges.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def radius(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @radius.setter
    def radius(self, value):
        """
    
        """
        pass


class BinomialBlurFilter(Filter):
    """
    Blurring filters are traditionally used to remove noise from images, by attenuating high spatial frequencies. The Binomial blur filter computes a nearest neighbor average along each dimension.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def number_of_iterations(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @number_of_iterations.setter
    def number_of_iterations(self, value):
        """
    
        """
        pass


class MedianFilter(Filter):
    """
    The median filter is particularly useful to reduce speckle noise and salt and pepper noise. Its edge-preserve nature makes it useful in cases where edge blurring is undesirable. This filter computes the value of each output pixel as the statistical median of the neighborhood of values around the corresponding input pixel.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def radius(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @radius.setter
    def radius(self, value):
        """
    
        """
        pass


def hide_filtered_images():
    """
    Turns off filtered images visualization.
    """
    pass


def apply_filters(filters):
    """
    Applies the filters to the image set and turns on the visualization of the filtered images .
    
    :param filters: List of filters which should be applied to the image set.
    :type filters: typing.List[mimics.image.Filter]
    
    
    :example:
    .. code-block:: python
    
    	 
    	f1 = mimics.image.BinomialBlurFilter()
    	f2 = mimics.image.MedianFilter()
    	mimics.image.apply_filters([f1,f2])

    """
    pass


class GradientMagnitudeFilter(Filter):
    """
    The magnitude of the image gradient is extensively used in image analysis, mainly to help in the determination of object contours and the separation of homogenous regions. The gradient magnitude filter computes the magnitude of the image gradient at each pixel location. This filter does not apply any smoothing to the image before computing the gradients. The results can, therefore, be sensitive to noise.
    """
    def __init__(self):
        """
    
        """
        pass




class CurvatureFlowFilter(Filter):
    """
    The Curvature flow filter performs an edge-preserving smoothing on the images. The iso-contours of the images are viewed as level sets, where the pixels with a particular gray value form one level set. The diffusion speed is proportional to the curvature of the contours. Therefore, areas of high curvature will diffuse faster than areas with low curvature. Hence, small jagged noise artifacts disappear quickly, while large scale artifacts evolve slowly, thereby preserving sharp boundaries between objects.
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def time_step(self):
        """
        :type: <class 'float'>
        :read-only: False
    
        """
        pass
    
    @time_step.setter
    def time_step(self, value):
        """
    
        """
        pass

    @property
    def number_of_iterations(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @number_of_iterations.setter
    def number_of_iterations(self, value):
        """
    
        """
        pass


class DiscreteGaussianFilter(object):
    """
    The Discrete Gaussian filter computes the convolution of the image with a Gaussian kernel for calculating the transformation to apply to each voxel. This filter is used typically to smooth and reduce the image detail, preserving the edges for low variances..
    """
    def __init__(self):
        """
    
        """
        pass

    @property
    def gaussian_variance(self):
        """
        :type: <class 'typing.SupportsFloat'>
        :read-only: False
    
        """
        pass
    
    @gaussian_variance.setter
    def gaussian_variance(self, value):
        """
    
        """
        pass

    @property
    def max_kernel_width(self):
        """
        :type: <class 'int'>
        :read-only: False
    
        """
        pass
    
    @max_kernel_width.setter
    def max_kernel_width(self, value):
        """
    
        """
        pass


def show_filtered_images():
    """
    Turns on filtered images visualization. Filters will be reapplied to the image set so this operation may take a few minutes.
    """
    pass


def calculate_automatic_registration(image_fixed, image_moving, translation=None, region_of_interest=None):
    """
    Executes automatic Image Registration.
    
    :param image_fixed: The fixed image.
    :type image_fixed: mimics.ImageData
    :param image_moving: The moving image.
    :type image_moving: mimics.ImageData
    :param translation: (optional) Initial translation (prealignment) in the patient coordinate system.
    :type translation: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param region_of_interest: (optional) Region of interest on the fixed image.
    :type region_of_interest: mimics.segment.Mask
    
    :returns: Registration transformation.
    :rtype: mimics.Transformation
    
    
    :example:
    .. code-block:: python
    
    	 
    	fixed_image = mimics.data.images[0]
    	moving_image = mimics.data.images[1]
    	transformation = mimics.image.calculate_automatic_registration(fixed_image, moving_image)
    	print(transformation.matrix)

    """
    pass


class _ImageRegistrationController(object):
    """
    Controller for Image Registration tool
    """
    def set_fixed_image(self, image):
        """
        Fixed image
        
        :param image: 
        :type image: mimics.ImageData
        """
        pass

    def set_moving_image(self, image):
        """
        Moving image
        
        :param image: 
        :type image: mimics.ImageData
        """
        pass

    def set_fixed_roi_mask(self, mask):
        """
        Fixed ROI mask
        
        :param mask: 
        :type mask: mimics.segment.Mask
        """
        pass

    def set_moving_roi_mask(self, mask):
        """
        Moving ROI mask
        
        :param mask: 
        :type mask: mimics.segment.Mask
        """
        pass

    def append_prealignment(self, prealignment):
        """
        Prealignment in patient coordinate system
        
        :param prealignment: 
        :type prealignment: ThreeItemsIterable[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
        """
        pass

    def calculate_transform_for_registration(self):
        """
        Calculates the transformation required for image registration
        
        
        
        :returns: True if the transformation stored inside this controller has become ready to be used for creating a new registered image
        :rtype: bool
        """
        pass

    def create_registration_transformation(self):
        """
        Creates and returns the transformation object which is the result of a registration performed by this controller
        
        
        
        :returns: Registration transformation.
        :rtype: mimics.Transformation
        """
        pass

    def finalize(self):
        """
        Finalize controller
        
    
        """
        pass




def reslice_project(start_point, end_point, rotation_angle, image_width, image_height, slice_distance, pixel_size, update_image_data_coordinate_system):
    """
    Exports a resliced version of the current project.
    
    :param start_point: Start point of the reslicing.
    :type start_point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param end_point: End point of the reslicing.
    :type end_point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param rotation_angle: Rotation angle of the bounding box around the axis defined by the start and end points.
    :type rotation_angle: int
    :param image_width: The width of the images in the resliced project.
    :type image_width: typing.SupportsFloat
    :param image_height: The height of the images in the resliced project.
    :type image_height: typing.SupportsFloat
    :param slice_distance: The slice increment of the resliced project.
    :type slice_distance: typing.SupportsFloat
    :param pixel_size: The pixel size of the resliced project.
    :type pixel_size: typing.SupportsFloat
    :param update_image_data_coordinate_system:  If true, the origin of the coordinate system will be updated to the upper left corner of the first image in the stack, with the axes along the main directions of the image stack.
    :type update_image_data_coordinate_system: bool
    
    :exceptions: ValueError (reason(s): ['Width out of appropriate range', 'Height out of appropriate range', 'Slice distance out of appropriate range', 'Pixel size out of appropriate range'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	sp = (1,1,1)
    	ep = (20,20,20)
    	ang = 90
    	i_w = 50
    	i_h = 50
    	sd = 0.5
    	ps = 0.1
    	mimics.image.reslice_project(start_point=sp,
    	                                  end_point=ep,
    	                                  rotation_angle=ang,
    	                                  image_width=i_w,
    	                                  image_height=i_h,
    	                                  slice_distance=sd,
    	                                  pixel_size=ps,
    	                                  update_image_data_coordinate_system=False
    	                                 )

    """
    pass


def reslice_project_bbox(corner_point, x_axis, y_axis, z_axis, slice_distance, pixel_size, update_image_data_coordinate_system):
    """
    Exports a resliced version of the current project using the given bounding box.
    
    :param corner_point: Corner point of the bounding box.
    :type corner_point: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param x_axis: Vector that defines the length and the direction of the cropping box in x-axis. E.g (5,0,0).
    :type x_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param y_axis: Vector that defines the length and the direction of the cropping box in y-axis. E.g (0,3.2,0).
    :type y_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param z_axis: Vector that defines the length and the direction of the cropping box in z-axis. E.g (0,0,7).
    :type z_axis: typing.Tuple[typing.SupportsFloat, typing.SupportsFloat, typing.SupportsFloat]
    :param slice_distance: The slice increment of the resliced project.
    :type slice_distance: typing.SupportsFloat
    :param pixel_size: The pixel size of the resliced project.
    :type pixel_size: typing.SupportsFloat
    :param update_image_data_coordinate_system: If true, the origin of the coordinate system will be updated to the upper left corner of the first image in the stack, with the axes along the main directions of the image stack.
    :type update_image_data_coordinate_system: bool
    
    :exceptions: ValueError (reason(s): ['Slice distance out of appropriate range', 'Pixel size out of appropriate range', 'Axis vector length is 0', 'Axes are parallel'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	cp = (1,1,1)
    	x = (5,0,0)
    	y = (0,3.2,0)
    	z = (0,0,1)
    	sd = 0.5
    	ps = 0.1
    	mimics.image.reslice_project_bbox(corner_point=cp,
    	                                  x_axis=x,
    	                                  y_axis=y,
    	                                  z_axis=z,
    	                                  slice_distance=sd,
    	                                  pixel_size=ps,
    	                                  update_image_data_coordinate_system=False
    	                                 )

    """
    pass


