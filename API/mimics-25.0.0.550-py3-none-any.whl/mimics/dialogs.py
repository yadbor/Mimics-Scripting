
class ConstObject:
    CANNOT_CONVERT_PROJECT = "CannotConvertProject"
    CHANGE_ORIENTATION = "ChangeOrientation"
    CONTINUEWITHOUTDATEDPROJECT = "ContinueWithOutdatedProject"
    CONTINUE_WITH_OUTDATED_DATA_MODEL = "ContinueWithOutdatedDataModel"
    DELETE_CPR_DEPENDENT_OBJECTS = "DeleteCprDependentObjects"
    ENABLE_PROMPT_USER_ABOUT_POTENTIAL_LOSSES = "EnablePromptUserAboutPotentialLosses"
    EXCLUDED_IMAGES_WARNING = "ExcludedImagesWarning"
    FIX_IMAGE_POSITIONING = "FixImagesPositioning"
    INCOMPATIBLE_VERSION = "IncompatibleVersion"
    LICENSE_LOST_INFORMATION_DIALOG = "LicenseLostInformationDialog"
    INCORRECT_VOXELS_DIMENSIONS_WARNING = "IncorrectVoxelsDimensionsWarning"
    LOADING_ERROR_WARNING = "LoadingErrorWarning"
    MGX_PASSWORD = "MGXPassword"
    NOT_VALID_CS_IN_PROJECT = "ProjectHasNotValidCS"
    OPEN_AUTOSAVED_DOCUMENT = "OpenAutosavedDocument"
    RENDERER_SWITCH_WARNING = "RendererSwitchWarning"
    RESLICE_PROJECT_WHEN_GANTRY_TILT = "ChangeGantryTilt.ResliceProject"
    SAVE_CHANGED_PROJECT_WHEN_LICENSE_LOST = "SaveChangedProjectWhenLicenseLost"
    SAVE_CHANGES_WHEN_CLOSE_PROJECT = "SaveChangedProject"
    SAVE_DOCUMENT_BEFORE_RESLICE = "SaveDocumentBeforeReslice"
    SELECT_PIXEL_SIZE = "SelectPixelSize"
    SWITCH_ORIENTATION_WHEN_GANTRY_TILT = "ChangeGantryTilt.SwitchOrientation"


dialog_id = ConstObject()



import typing
import mimics


def _set_predefined_answer_str(dialog_id, answer):
    """
    :param dialog_id: Defines the dialog id.
    :type dialog_id: str
    :param answer: Defines the string answer to the dialog.
    :type answer: str
    
    :exceptions: ValueError (reason(s): ['No predefined answer allowed for dialog with ID', 'This kind of answer for dialog with ID is not allowed'])
    """
    pass


def question_box(message, buttons='Yes; No', title=None, ui_blocking=True):
    """
    Displays a customized dialog box.
    
    :param message: Question text in the box.
    :type message: str
    :param buttons: (optional) Name of the buttons.
    :type buttons: str
    :param title: (optional) Title of the dialog.
    :type title: str
    :param ui_blocking: (optional) True if the question box should block UI or false otherwise.
    :type ui_blocking: bool
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = "Do you want to proceed?"
    	btns = "Yes;No"
    	ttl = "Question Box"
    	ans = mimics.dialogs.question_box(message=msg, buttons=btns, title=ttl)

    """
    pass


def message_box(message, title=None, ui_blocking=True):
    """
    Displays a plain message box.
    
    :param message: Message text in the box.
    :type message: str
    :param title: (optional) Title of the dialog.
    :type title: str
    :param ui_blocking: (optional) True if the message box should block UI or false otherwise.
    :type ui_blocking: bool
    
    
    :example:
    .. code-block:: python
    
    	 
    	msg = "This is an example."
    	mimics.dialogs.message_box(msg, ui_blocking=True)

    """
    pass


def has_predefined_answer(dialog_id):
    """
    Checks if there exists a predefined answer for pop up dialog.
    
    For the complete list of dialog IDs and possible answers see the help for the mimics.dialog.set_predefined_answer function.
    
    :param dialog_id: Defines the dialog id.
    :type dialog_id: str
    
    :returns: Returns true if there is a predefined answer to the specified dialog or false otherwise.
    :rtype: bool
    
    :exceptions: ValueError (reason(s): ['No predefined answer allowed for dialog with ID'])
    """
    pass


def set_predefined_answer(dialog_id, answer):
    """
    Sets predefined answers to pop up dialogs. The following dialog_id and answer combinations are possible:
        * dialog_id: ChangeGantryTilt.SwitchOrientation, answers: Yes, No. Switch orientation when Gantry tilt.
        * dialog_id: ChangeGantryTilt.ResliceProject, answers: Yes, No. reslice project when Gantry tilt.
        * dialog_id: ReduceImages, answers: Current, Proposed, Cancel, 1, 2, 3, 4, 5. A data set with a small voxel size and a large amount of images will be loaded. To maintain proper performance a higher reduction is proposed. If no reduction is wanted value 1 should be chosen.
        * dialog_id: OpenAutosavedDocument, answers: Yes, No. A backup of the project was found on disk. Would you like to load this project?. Note, that this predefined answer is ignored when running the application in the background mode.
        * dialog_id: ProjectHasNotValidCS, answers: Yes, No. The project was created in an older version of Mimics. The coordinate system does not relate to the DICOM patient position. Do you want to continue?
        * dialog_id: CannotConvertProject, answers: Yes, No. The project was created in an older version of Mimics. The project cannot be converted to the DICOM patient coordinate system, the objects will remain in the Mimics DICOM coordinate system. Do you want to continue?
        * dialog_id: FixImagesPositioning, answers: Yes, No. The project was created in a version of Mimics that exports objects in the Mimics Coordinate System. Do you want to convert the project to work into the DICOM patient coordinate system?; The DICOM patient coordinate has been updated in Mimics 16.0. Do you want to convert the project accordingly?
        * dialog_id: DeleteCprDependentObjects, answers: Yes, No. While modifying the properties of the resliced object, the depending objects will be invalidated. Do you want to delete them?
        * dialog_id: RendererSwitchWarning, answers: Ok. Mimics could not switch to the selected 3D renderer. As a safety measure Mimics has switched to software rendering.
        * dialog_id: ChangeOrientation, answers: 'default', 'RAT', 'RAB', etc. Set the orientation of the imported project.
        * dialog_id: ExcludedImagesWarning, answers: Ok. The following image files will be excluded from the active image set because they collide with other image files on the same position or for another reason stated in the list. You can go to File / Organize Images to select the correct image file for the given positions.
        * dialog_id: SaveDocumentBeforeReslice, answers: Yes, No. The document has been modified. Should it be saved before reslicing?
        * dialog_id: SelectPixelSize, answers: 'X', 'Y'. The imported project contains rectangular pixels. Only projects with square pixels are supported. Please specify the correct side.
        * dialog_id: ContinueWithOutdatedDataModel, answers: Yes, No. The open project was created or modified in a version of Mimics which is no longer supported. Do you want to continue?
        * dialog_id: SaveChangedProjectWhenLicenseLost, answers: Yes, No. It seems that the license is lost. The application will be closed. Do you want to save the project first?
        * dialog_id: LicenseLostInformationDialog, answers: Ok. It seems that the license is lost. The application will be closed.
        * dialog_id: TryRecoverBaseLicenseWhenLost, answers: Yes, No. It seems you lost your license. Do you want to try to recapture your license.
        * dialog_id: EnablePromptUserAboutPotentialLosses, answers: Yes, No. This change might remove some objects from the project. Are you sure you want to continue?
        * dialog_id: SaveChangedProject, answers: Yes, No. Do you want to save the project before exit?
        * dialog_id: LoadingErrorWarning, answers: Ok. An exception was handled while loading.
        * dialog_id: IncompatibleVersion, answers: Ok. The file was written with an incompatible version of the software.
        * dialog_id: MGXPassword, answer: <str>. Provide the password for the MGX encrypted file.
        * dialog_id: ContinueWithOutdatedProject, answers: Yes, No
        * dialog_id: PBS.ProceedWithVariableSliceDistance, answers: Yes, No. The project has variable spacing between slices. PBS may take long to run and need more memory than in other projects. It is recommended to reslice your project. Do you want to proceed with PBS?
        * dialog_id: PreferencesGPUMissingWarning, answers: Ok. Renderer from preferences is missing, optimal renderer will be selected automatically.
    
    :param dialog_id: Defines the dialog id.
    :type dialog_id: str
    :param answer: Defines the string answer to the dialog.
    :type answer: typing.Union[str, int]
    
    :exceptions: ValueError (reason(s): ['No predefined answer for dialog with ID', 'This kind of answer for dialog with ID is not allowed'])
    
    
    :example:
    .. code-block:: python
    
    	 
    	d_id = "ProjectHasNotValidCS"
    	ans = "Yes"
    	mimics.dialogs.set_predefined_answer(dialog_id=d_id, answer=ans)
    	
    	################################################################
    	d_id = mimics.dialogs.dialog_id.NOT_VALID_CS_IN_PROJECT
    	ans = mimics.dialogs.answer.Yes
    	mimics.dialogs.set_predefined_answer(dialog_id=d_id, answer=ans)

    """
    pass


def reset_predefined_answer(dialog_id):
    """
    Reset predefined answers to pop up dialogs.
    
    For the complete list of dialog IDs see the help for the mimics.dialog.set_predefined_answer function.
    
    :param dialog_id: Defines the dialog id.
    :type dialog_id: str
    
    :exceptions: ValueError (reason(s): ['No predefined answer allowed for dialog with ID'])
    """
    pass


def _set_predefined_answer_int(dialog_id, answer):
    """
    :param dialog_id: Defines the dialog id.
    :type dialog_id: str
    :param answer: Defines the int answer to the dialog.
    :type answer: int
    
    :exceptions: ValueError (reason(s): ['No predefined answer allowed for dialog with ID', 'This kind of answer for dialog with ID is not allowed'])
    """
    pass


